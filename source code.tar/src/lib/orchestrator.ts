// OceanTech AI — Coordinator / Reasoning Engine (server-side)
// Flow: parse → resolve → agents (concurrent) → risk engine → explanation → persist → respond
import { randomUUID } from 'crypto'
import { db } from '@/lib/db'
import { parseQuery, setLocationIndex, type ParseOptions } from '@/lib/parser'
import { getLocations, getLocation, getWeather, getOcean, getSeries } from '@/lib/data/providers'
import { weatherAgent } from '@/lib/agents/weatherAgent'
import { oceanAgent, seaState } from '@/lib/agents/oceanAgent'
import { fishingAgent } from '@/lib/agents/fishingAgent'
import { ecosystemAgent } from '@/lib/agents/ecosystemAgent'
import { gisAgent } from '@/lib/agents/gisAgent'
import { alertAgent } from '@/lib/agents/alertAgent'
import { maritimeAgent } from '@/lib/agents/maritimeAgent'
import { riskAgent } from '@/lib/agents/riskAgent'
import { tf } from '@/lib/i18n/translations'
import type { DictKey } from '@/lib/i18n/translations'
import { aiConverse } from '@/lib/ai/aiService'
import type {
  AgentRunInfo, ConditionItem, LangCode, OrchestratorResult, ParsedQuery,
  RiskResult, AssessmentAnswer,
} from '@/types/marine'

let indexLoaded = false
async function ensureLocationIndex() {
  if (indexLoaded) return
  const locs = await getLocations()
  setLocationIndex(locs.map((l) => ({
    name: l.name, slug: l.slug, state: l.state, latitude: l.latitude, longitude: l.longitude,
    aliases: l.slug === 'visakhapatnam' ? ['vizag', 'visakhapatnam port'] :
      l.slug === 'kochi' ? ['cochin'] :
      l.slug === 'mumbai' ? ['bombay'] :
      l.slug === 'goa' ? ['panaji', 'panjim'] :
      l.slug === 'chennai' ? ['madras'] : [],
  })))
  indexLoaded = true
}

function addHours(isoDate: string, time: string): Date {
  const [y, m, d] = isoDate.split('-').map(Number)
  const [hh, mm] = time.split(':').map(Number)
  // Interpret as local server time (Asia/Kolkata for this deployment)
  return new Date(y, m - 1, d, hh, mm ?? 0, 0)
}

function timePartKey(t: string | null): 'morning' | 'afternoon' | 'evening' | 'night' | null {
  if (!t) return null
  const h = parseInt(t.split(':')[0], 10)
  if (h < 11) return 'morning'
  if (h < 16) return 'afternoon'
  if (h < 20) return 'evening'
  return 'night'
}

function whenPhrase(lang: LangCode, datePhrase: string | null, time: string | null): string {
  const day = datePhrase ? tf(lang, `time.${datePhrase}` as DictKey) : ''
  const part = timePartKey(time)
  const partS = part ? tf(lang, `time.${part}` as DictKey) : ''
  if (day && partS) return `${day} ${partS}`
  if (day) return day
  if (partS) return partS
  return tf(lang, 'time.tomorrow')
}

function buildConditions(
  lang: LangCode,
  weather: Awaited<ReturnType<typeof weatherAgent>>,
  ocean: Awaited<ReturnType<typeof oceanAgent>>,
  alerts: Awaited<ReturnType<typeof alertAgent>>,
  fishing: Awaited<ReturnType<typeof fishingAgent>>,
): Record<string, ConditionItem> {
  const w = weather.data, o = ocean.data
  const maxSev = alerts.data?.max ?? 'none'
  const zone = fishing.data?.nearest
  const conditions: Record<string, ConditionItem> = {
    wind: { value: w ? `${Math.round(w.windSpeed)} km/h` : '—', detail: w?.windDirection },
    waves: { value: o ? `${o.waveHeight.toFixed(1)} m` : '—', detail: o ? tf(lang, `sea.${seaState(o.waveHeight)}` as DictKey) : undefined },
    weather: { value: w ? tf(lang, `wx.${w.condition}` as DictKey) : '—' },
    marineAlert: { value: maxSev === 'none' ? tf(lang, 'cond.noAlert') : tf(lang, `sev.${maxSev}` as DictKey), key: maxSev === 'none' ? undefined : maxSev },
    fishingZone: { value: zone ? (zone.advisoryStatus === 'Available' ? tf(lang, 'st.Available') : tf(lang, 'st.Restricted')) : tf(lang, 'cond.none'), detail: zone ? `${zone.code} · ${zone.distanceKm} km` : undefined },
  }
  if (w) {
    conditions.temperature = { value: `${w.temperature}°C` }
    conditions.rainfall = { value: `${w.rainfallMm} mm` }
    conditions.stormRisk = { value: `${Math.round(w.stormProbability)}%` }
  }
  if (o) {
    conditions.current = { value: `${o.currentSpeed.toFixed(2)} m/s`, detail: o.currentDirection }
    conditions.seaTemp = { value: `${o.seaTemp}°C` }
    conditions.visibility = { value: `${o.visibilityKm} km` }
    conditions.wavePeriod = { value: `${o.wavePeriod} s` }
  }
  return conditions
}

function explanationText(lang: LangCode, risk: RiskResult, conditions: Record<string, ConditionItem>, locationName: string): string {
  const levelWord = tf(lang, `risk.${risk.level.toLowerCase()}` as DictKey)
  const top = risk.factors.filter((f) => f.contribution >= 1).slice(0, 4)
  const parts: string[] = []
  parts.push(tf(lang, 'answer.explain', { level: levelWord }))
  for (const f of top) {
    const label = tf(lang, f.labelKey as DictKey)
    parts.push(`${label}: ${f.detail} → +${f.contribution}`)
  }
  const alertItem = conditions.marineAlert
  if (alertItem && alertItem.key) {
    parts.push(`${tf(lang, 'cond.marineAlert')}: ${tf(lang, `sev.${alertItem.key}` as DictKey)} (${locationName})`)
  }
  return parts.join(' · ')
}

function buildAnswer(
  lang: LangCode, risk: RiskResult, conditions: Record<string, ConditionItem>,
  locationName: string, activityKey: string, whenP: string,
): AssessmentAnswer {
  const oneLiner =
    risk.level === 'SAFE' ? tf(lang, 'answer.safe', { location: locationName, when: whenP, activity: activityKey }) :
    risk.level === 'MODERATE' ? tf(lang, 'answer.moderate', { location: locationName, when: whenP, activity: activityKey }) :
    tf(lang, 'answer.high', { location: locationName, when: whenP, activity: activityKey })
  return {
    oneLiner,
    explanation: explanationText(lang, risk, conditions, locationName),
    recommendation: tf(lang, `risk.rec.${risk.level.toLowerCase()}` as DictKey),
  }
}

function agentRunsInfo(runs: { output: { name: string; labelKey: string; status: 'completed' | 'degraded' | 'failed'; confidence: number; executionTimeMs: number; summary: string; source: string; dataStatus: 'SAMPLE' | 'LIVE'; updatedAt: string } }[]): AgentRunInfo[] {
  return runs.map((r) => ({ ...r.output }))
}

function minutesAgo(iso: string, now: Date): number {
  return Math.max(0, Math.round((now.getTime() - new Date(iso).getTime()) / 60000))
}

export interface OrchestratorOptions {
  query: string
  language: LangCode
  userId: string
  homeLocation?: string | null
  pendingField?: 'location' | 'time' | null
  previousActivity?: 'fishing' | 'boating' | 'sailing' | 'swimming' | 'marine_operations'
}

export async function runQuery(opts: OrchestratorOptions): Promise<OrchestratorResult> {
  const { query, language: lang, userId } = opts
  const now = new Date()
  await ensureLocationIndex()

  const parseOpts: ParseOptions = { now, pendingField: opts.pendingField ?? null, previousActivity: opts.previousActivity }
  const parsed = parseQuery(query, parseOpts)
  const base: OrchestratorResult = {
    queryId: null, type: 'info', language: lang, question: query, parsed,
    followUp: null, answer: null, risk: null, conditions: null, agents: [], dataFreshness: [],
    alerts: [], fishingZones: [], gisZones: [], mapFocus: null, locationName: null,
    requestedWhen: null, createdAt: now.toISOString(),
  }

  // ── Greeting / capability / general ──────────────────────────────────────
  if (parsed.intent === 'greeting' || parsed.intent === 'capability') {
    base.type = 'info'
    base.answer = { oneLiner: '', explanation: tf(lang, parsed.intent === 'greeting' ? 'answer.greeting' : 'answer.capability'), recommendation: '' }
    const saved = await persist(base, userId, parsed)
    base.queryId = saved
    return base
  }

  // ── Risk explain: use latest stored assessment ───────────────────────────
  if (parsed.intent === 'risk_explain') {
    const last = await db.userQuery.findFirst({
      where: { userId, responseType: 'assessment', assessment: { isNot: null } },
      orderBy: { createdAt: 'desc' },
      include: { assessment: true },
    })
    if (!last?.assessment) {
      base.type = 'info'
      base.answer = { oneLiner: '', explanation: tf(lang, 'answer.lastAssessmentNone'), recommendation: '' }
      base.queryId = await persist(base, userId, parsed)
      return base
    }
    const risk: RiskResult = JSON.parse(last.assessment.factorsJson) && {
      level: last.assessment.riskLevel as RiskResult['level'],
      score: last.assessment.riskScore,
      confidence: last.assessment.confidence,
      factors: JSON.parse(last.assessment.factorsJson),
    }
    const answerJson = JSON.parse(last.assessment.answerJson) as AssessmentAnswer
    base.type = 'info'
    base.locationName = last.location
    base.risk = risk
    base.answer = {
      oneLiner: answerJson.oneLiner,
      explanation: `${tf(lang, 'assistant.whyTitle')} ${answerJson.explanation}`,
      recommendation: answerJson.recommendation,
    }
    base.parsed = { ...parsed, location: last.location, locationSlug: last.locationSlug, latitude: last.latitude, longitude: last.longitude, activity: (last.activity ?? 'fishing') as ParsedQuery['activity'] }
    base.queryId = await persist(base, userId, parsed)
    return base
  }

  // ── Location-dependent intents ───────────────────────────────────────────
  let slug = parsed.locationSlug
  if (!slug && parsed.location) {
    const loc = await getLocation(parsed.location.toLowerCase().replace(/\s+/g, '-'))
    slug = loc?.slug ?? null
  }
  // Info intents fall back to the user's home port; only trip assessments ask a follow-up.
  const infoIntent = parsed.intent === 'fishing_zones' || parsed.intent === 'alerts' || parsed.intent === 'ocean_conditions'
  if (!slug && infoIntent && opts.homeLocation) {
    const homeLoc = await getLocation(opts.homeLocation.toLowerCase().replace(/\s+/g, '-'))
    if (!homeLoc) {
      const byName = (await getLocations()).find((l) => l.name.toLowerCase() === opts.homeLocation!.toLowerCase())
      slug = byName?.slug ?? null
    } else {
      slug = homeLoc.slug
    }
  }
  if (!slug) {
    base.type = 'follow_up'
    base.followUp = tf(lang, 'followup.location')
    base.queryId = await persist(base, userId, parsed)
    return base
  }

  const loc = await getLocation(slug!)
  if (!loc) {
    base.type = 'follow_up'
    base.followUp = tf(lang, 'followup.location')
    base.queryId = await persist(base, userId, parsed)
    return base
  }
  base.locationName = loc.name
  base.mapFocus = { lat: loc.latitude, lon: loc.longitude, zoom: 9 }

  // follow-up for time on assessment intents without a date/time
  if (parsed.intent === 'marine_safety_assessment' && !parsed.time && !parsed.datePhrase && !opts.pendingField) {
    base.type = 'follow_up'
    base.followUp = tf(lang, 'followup.time')
    base.parsed = { ...parsed, location: loc.name, locationSlug: loc.slug, latitude: loc.latitude, longitude: loc.longitude }
    base.queryId = await persist(base, userId, base.parsed)
    return base
  }

  const dateISO = parsed.dateISO ?? new Date(now.getTime() + 86_400_000).toISOString().slice(0, 10)
  const time = parsed.time ?? '06:00'
  const requestedAt = addHours(dateISO, time)
  base.requestedWhen = `${dateISO} ${time}`

  // ── Info intents: ocean conditions ──────────────────────────────────────
  if (parsed.intent === 'ocean_conditions') {
    const [ocean, weather] = await Promise.all([getOcean(loc.slug), getWeather(loc.slug)])
    base.type = 'info'
    base.answer = {
      oneLiner: tf(lang, 'answer.waves', { location: loc.name, wave: ocean.waveHeight.toFixed(1), wind: `${Math.round(weather.windSpeed)} km/h` }),
      explanation: `${tf(lang, 'ocean.wavePeriod')}: ${ocean.wavePeriod} s · ${tf(lang, 'cond.current')}: ${ocean.currentSpeed.toFixed(2)} m/s · ${tf(lang, 'cond.seaTemp')}: ${ocean.seaTemp}°C · ${tf(lang, 'ocean.seaState')}: ${tf(lang, `sea.${seaState(ocean.waveHeight)}` as DictKey)}`,
      recommendation: '',
    }
    base.conditions = {
      waves: { value: `${ocean.waveHeight.toFixed(1)} m` }, wavePeriod: { value: `${ocean.wavePeriod} s` },
      current: { value: `${ocean.currentSpeed.toFixed(2)} m/s` }, seaTemp: { value: `${ocean.seaTemp}°C` },
      wind: { value: `${Math.round(weather.windSpeed)} km/h` }, weather: { value: tf(lang, `wx.${weather.condition}` as DictKey) },
    }
    base.agents = [agentRunStub('ocean', 'agents.ocean', `${ocean.waveHeight.toFixed(1)} m waves`, ocean.updatedAt, ocean.source)]
    base.dataFreshness = [{ agent: 'ocean', updatedAt: ocean.updatedAt, minutesAgo: minutesAgo(ocean.updatedAt, now) }]
    base.queryId = await persist(base, userId, parsed)
    return base
  }

  // ── Info intents: alerts ─────────────────────────────────────────────────
  if (parsed.intent === 'alerts') {
    const alertAgentOut = await alertAgent({ location: loc, requestedAt: now, now })
    const alerts = alertAgentOut.data?.alerts ?? []
    base.type = 'info'
    base.alerts = alerts
    base.answer = {
      oneLiner: alerts.length ? tf(lang, 'answer.alerts', { n: alerts.length, location: loc.name }) : tf(lang, 'answer.alertsNone', { location: loc.name }),
      explanation: alerts.map((a) => `${tf(lang, `sev.${a.severity}` as DictKey)} — ${a.title}`).join(' · ') || '',
      recommendation: alerts.some((a) => a.severity === 'Warning' || a.severity === 'Severe') ? tf(lang, 'risk.rec.high') : tf(lang, 'risk.rec.moderate'),
    }
    base.agents = [agentRunStub('alerts', 'agents.alerts', `${alerts.length} alert(s)`, now.toISOString(), 'OceanTech Structured Alert Feed')]
    base.dataFreshness = [{ agent: 'alerts', updatedAt: now.toISOString(), minutesAgo: 0 }]
    base.queryId = await persist(base, userId, parsed)
    return base
  }

  // ── Info intents: fishing zones ──────────────────────────────────────────
  if (parsed.intent === 'fishing_zones') {
    const fOut = await fishingAgent({ location: loc, requestedAt: now, now })
    const zones = fOut.data?.zones ?? []
    const nearest = fOut.data?.nearest ?? null
    base.type = 'info'
    base.fishingZones = zones.slice(0, 4)
    base.answer = {
      oneLiner: nearest ? tf(lang, 'answer.zones', { name: `${nearest.code} — ${nearest.name}`, distance: `${nearest.distanceKm} km`, suitability: tf(lang, `suit.${nearest.suitability}` as DictKey) }) : tf(lang, 'fishing.empty'),
      explanation: zones.slice(0, 3).map((z) => `${z.code}: ${z.distanceKm} km · ${tf(lang, `suit.${z.suitability}` as DictKey)} · SST ${z.sst}°C · chl ${z.chlorophyll} mg/m³`).join(' · '),
      recommendation: '',
    }
    base.mapFocus = nearest ? { lat: nearest.centerLat, lon: nearest.centerLon, zoom: 9, layer: 'fishing', id: nearest.id, title: nearest.code } : base.mapFocus
    base.agents = [agentRunStub('fishing', 'agents.fishing', `${zones.length} zone(s)`, now.toISOString(), 'OceanTech Structured PFZ Feed')]
    base.queryId = await persist(base, userId, parsed)
    return base
  }

  // ── Full safety assessment: run ALL agents concurrently ─────────────────
  const ctx = { location: loc, requestedAt, now }
  const [weather, ocean, fishing, ecosystem, gis, alerts, maritime] = await Promise.all([
    weatherAgent(ctx), oceanAgent(ctx), fishingAgent(ctx), ecosystemAgent(ctx), gisAgent(ctx), alertAgent(ctx), maritimeAgent(ctx),
  ])
  const { result: risk, missing } = riskAgent(weather, ocean, alerts, fishing, gis)

  const conditions = buildConditions(lang, weather, ocean, alerts, fishing)
  const activityLabel = tf(lang, `activity.${parsed.activity}` as DictKey)
  const whenP = whenPhrase(lang, parsed.datePhrase, parsed.time)
  const answer = buildAnswer(lang, risk, conditions, loc.name, activityLabel, whenP)

  // enrich explanation with maritime/ecosystem notes (deterministic first)
  const extraNotes: string[] = []
  if (maritime.data?.notes?.length) extraNotes.push(...maritime.data.notes)
  if (ecosystem.data?.anomalies?.length) extraNotes.push(`Ecosystem anomaly: ${ecosystem.data.anomalies[0]}`)
  if (extraNotes.length) answer.explanation += ' · ' + extraNotes.join(' · ')

  base.type = 'assessment'
  base.risk = risk
  base.conditions = conditions
  base.answer = answer
  base.agents = agentRunsInfo([weather, ocean, fishing, ecosystem, gis, alerts, maritime].map((o) => ({ output: o })))
  base.alerts = alerts.data?.alerts ?? []
  base.fishingZones = fishing.data?.zones.slice(0, 5) ?? []
  base.gisZones = gis.data ? [...gis.data.conflicts, ...gis.data.restricted.slice(0, 2), ...gis.data.protected.slice(0, 3)] : []
  base.dataFreshness = [weather, ocean, fishing, alerts].map((a) => ({
    agent: a.name, updatedAt: a.updatedAt, minutesAgo: minutesAgo(a.updatedAt, now),
  }))

  // LLM is optional: refine the explanation tone when available; deterministic text already set.
  const refined = await aiConverse(
    [
      { role: 'user', content: `Marine assessment for ${loc.name}: risk ${risk.level} (${risk.score}/100). Factors: ${risk.factors.map((f) => `${f.labelKey} ${f.detail} (+${f.contribution})`).join(', ')}. Alerts: ${base.alerts.map((a) => a.severity).join(',') || 'none'}. Rewrite this explanation warmly and simply, keeping all numbers: "${answer.explanation}"` },
    ],
    lang,
  )
  if (refined) answer.explanation = refined

  base.queryId = await persist(base, userId, parsed, risk, conditions, answer, base.agents)
  return base
}

function agentRunStub(name: string, labelKey: string, summary: string, updatedAt: string, source: string): AgentRunInfo {
  return { name, labelKey, status: 'completed', confidence: 0.9, executionTimeMs: 45, summary, source, dataStatus: 'SAMPLE', updatedAt }
}

async function persist(
  base: OrchestratorResult, userId: string, parsed: ParsedQuery,
  risk?: RiskResult, conditions?: Record<string, ConditionItem>, answer?: AssessmentAnswer, agents?: AgentRunInfo[],
): Promise<string> {
  try {
    const q = await db.userQuery.create({
      data: {
        userId, query: base.question.slice(0, 500), language: base.language,
        location: base.locationName, locationSlug: parsed.locationSlug,
        latitude: parsed.latitude, longitude: parsed.longitude,
        requestedDate: base.requestedWhen ? base.requestedWhen.split(' ')[0] : parsed.dateISO,
        requestedTime: base.requestedWhen ? base.requestedWhen.split(' ')[1] : parsed.time,
        activity: parsed.activity, intent: parsed.intent, responseType: base.type,
      },
    })
    if (base.type === 'assessment' && risk && conditions && answer) {
      await db.riskAssessment.create({
        data: {
          queryId: q.id, riskLevel: risk.level, riskScore: risk.score, confidence: risk.confidence,
          factorsJson: JSON.stringify(risk.factors), conditionsJson: JSON.stringify(conditions), answerJson: JSON.stringify(answer),
        },
      })
    }
    if (agents?.length) {
      await db.agentRun.createMany({
        data: agents.map((a) => ({
          queryId: q.id, agentName: a.name, status: a.status, confidence: a.confidence,
          executionTimeMs: a.executionTimeMs, inputDataJson: '{}', outputDataJson: JSON.stringify({ summary: a.summary, source: a.source, dataStatus: a.dataStatus, updatedAt: a.updatedAt }),
        })),
      })
    }
    return q.id
  } catch (e) {
    console.error('persist failed', e)
    return randomUUID()
  }
}
