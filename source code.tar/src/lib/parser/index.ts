// OceanTech AI — natural language understanding (deterministic, multilingual-aware)
import type { Activity, Intent, ParsedQuery } from '@/types/marine'

export interface LocationIndexEntry {
  name: string; slug: string; state: string; latitude: number; longitude: number
  aliases: string[]
}

/** Populated from DB at runtime (setLocations). Case-insensitive matching incl. aliases. */
let LOCATIONS: LocationIndexEntry[] = []

export function setLocationIndex(entries: LocationIndexEntry[]) { LOCATIONS = entries }
export function getLocationIndex() { return LOCATIONS }

const norm = (s: string) => s.toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, ' ').replace(/\s+/g, ' ').trim()

export function matchLocation(text: string): LocationIndexEntry | null {
  const t = ` ${norm(text)} `
  // longest name/alias match wins
  let best: { entry: LocationIndexEntry; len: number } | null = null
  for (const entry of LOCATIONS) {
    const cands = [entry.name, ...entry.aliases].map(norm)
    for (const c of cands) {
      if (c.length < 3) continue
      if (t.includes(` ${c} `) || t.includes(`${c} coast`) || t.startsWith(`${c} `)) {
        if (!best || c.length > best.len) best = { entry, len: c.length }
      }
    }
  }
  return best?.entry ?? null
}

const TIME_RE = /(\d{1,2})\s*(am|pm|a\.m|p\.m)/i
const HOUR24_RE = /\b(\d{1,2})\s*(:\d{2})?\s*(?:hours|hrs|o'?clock)?\b/i

function detectTime(text: string): { time: string | null; partOfDay: string | null } {
  const t = norm(text)
  const m = t.match(TIME_RE)
  if (m) {
    let h = parseInt(m[1], 10) % 12
    if (/pm/i.test(m[2])) h += 12
    return { time: `${String(h).padStart(2, '0')}:00`, partOfDay: null }
  }
  if (/(morning|sunrise|dawn|early)/i.test(t)) return { time: '06:00', partOfDay: 'morning' }
  if (/(afternoon|noon|midday)/i.test(t)) return { time: '13:00', partOfDay: 'afternoon' }
  if (/(evening|sunset|dusk)/i.test(t)) return { time: '17:30', partOfDay: 'evening' }
  if (/(night|midnight|late)/i.test(t)) return { time: '21:00', partOfDay: 'night' }
  return { time: null, partOfDay: null }
}

function detectDate(text: string, now: Date): { dateISO: string | null; datePhrase: string | null } {
  const t = norm(text)
  if (/\b(today|now|current|right now|abhi|aaj|ఈరోజు|இன்று|ಇಂದು|आज|আজ|ഇന്ന്)\b/.test(t)) {
    return { dateISO: iso(now), datePhrase: 'today' }
  }
  if (/\b(day after tomorrow|parso|parava)\b/.test(t)) {
    return { dateISO: iso(addDays(now, 2)), datePhrase: 'dayAfter' }
  }
  if (/\b(tomorrow|tommorow|tmrw|kal|రేపు|நாளை|ನಾಳೆ|उद्या|আগামীকাল|നാളെ)\b/.test(t)) {
    return { dateISO: iso(addDays(now, 1)), datePhrase: 'tomorrow' }
  }
  const weekdays = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday']
  for (let i = 0; i < weekdays.length; i++) {
    if (t.includes(weekdays[i])) {
      const diff = ((i - now.getDay()) + 7) % 7 || 7
      return { dateISO: iso(addDays(now, diff)), datePhrase: weekdays[i] }
    }
  }
  return { dateISO: null, datePhrase: null }
}

const iso = (d: Date) => d.toISOString().slice(0, 10)
const addDays = (d: Date, n: number) => new Date(d.getTime() + n * 86_400_000)

function detectActivity(text: string): Activity {
  const t = norm(text)
  if (/(fish|fishing|meen|matsya|machhli|மீன்|ಮೀನು|مچھلی|मछली|മീൻ)/i.test(t)) return 'fishing'
  if (/(boat|boating|donga|naav|নৌকা)/i.test(t)) return 'boating'
  if (/(sail|sailing|yacht)/i.test(t)) return 'sailing'
  if (/(swim|swimming)/i.test(t)) return 'swimming'
  return 'fishing' // primary product user; safest conversational default
}

function detectIntent(text: string, hasActivity: boolean): Intent {
  const t = norm(text)
  if (/^(hi|hello|hey|namaste|namaskaram|vanakkam|nomoshkar)\b/.test(t)) return 'greeting'
  if (/(what can you|who are you|help me|how do i|tum kya|మీరు ఏమి)/.test(t)) return 'capability'
  if (/(why|risk|score|moderate|assessment|explain)/.test(t) && /(risk|moderate|safe|high|score)/.test(t)) return 'risk_explain'
  if (/(fishing zone|pfz|zones|nearest|dhani|மண்டல)/.test(t)) return 'fishing_zones'
  if (/(warning|alert|cyclone|storm warning|gale|హెచ్చరిక|எச்சரிக்கை|সতর্কতা)/.test(t)) return 'alerts'
  if (/(wave|swell|current|tide|ocean condition|sea condition|ala|লহর)/.test(t)) return 'ocean_conditions'
  if (/(go|venture|plan|can i|safe|kya|out to sea|departure|leaving)/.test(t) && hasActivity) return 'marine_safety_assessment'
  if (hasActivity) return 'marine_safety_assessment'
  return 'general'
}

export interface ParseOptions {
  now?: Date
  /** conversation continuation: previous turn is known to be missing location/time */
  pendingField?: 'location' | 'time' | null
  previousActivity?: Activity
}

export function parseQuery(raw: string, opts: ParseOptions = {}): ParsedQuery {
  const now = opts.now ?? new Date()
  const text = raw

  // continuation flows: treat the reply as the missing field
  if (opts.pendingField === 'location') {
    const loc = matchLocation(text)
    if (loc) {
      return { location: loc.name, locationSlug: loc.slug, latitude: loc.latitude, longitude: loc.longitude, activity: opts.previousActivity ?? 'fishing', datePhrase: 'tomorrow', dateISO: iso(addDays(now, 1)), time: '06:00', intent: 'marine_safety_assessment', raw }
    }
  }
  if (opts.pendingField === 'time') {
    const { time } = detectTime(text)
    const d = detectDate(text, now)
    return { location: null, locationSlug: null, latitude: null, longitude: null, activity: opts.previousActivity ?? 'fishing', datePhrase: d.datePhrase ?? 'tomorrow', dateISO: d.dateISO ?? iso(addDays(now, 1)), time: time ?? '06:00', intent: 'marine_safety_assessment', raw }
  }

  const loc = matchLocation(text)
  const activity = detectActivity(text)
  const { time, partOfDay } = detectTime(text)
  const d = detectDate(text, now)
  const intent = detectIntent(text, activity !== 'marine_operations')

  // If a time-of-day was given but no explicit date, assume tomorrow for planned trips
  let dateISO = d.dateISO
  const datePhrase = d.datePhrase
  if (!dateISO && (time || partOfDay) && intent === 'marine_safety_assessment') {
    dateISO = iso(addDays(now, 1))
  }

  return {
    location: loc?.name ?? null,
    locationSlug: loc?.slug ?? null,
    latitude: loc?.latitude ?? null,
    longitude: loc?.longitude ?? null,
    activity,
    datePhrase,
    dateISO,
    time: time ?? (partOfDay ? { morning: '06:00', afternoon: '13:00', evening: '17:30', night: '21:00' }[partOfDay] ?? null : null),
    intent,
    raw,
  }
}

/** Build the canonical natural-language query used by voice when fields were captured step-by-step */
export function composeQuery(locationName: string, activity: Activity, datePhrase: string | null, time: string | null): string {
  const part = time ? `at ${time.replace(':00', ' ' + (parseInt(time, 10) >= 12 ? 'PM' : 'AM'))}` : ''
  return `Can I go ${activity} ${datePhrase ?? 'tomorrow'} ${part} from ${locationName}?`
}
