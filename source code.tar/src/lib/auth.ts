// OceanTech AI — session authentication (email/password, httpOnly cookie sessions)
// Supabase-Auth-equivalent behaviour implemented on the project's standard stack.
import { NextRequest, NextResponse } from 'next/server'
import { randomBytes, scryptSync, timingSafeEqual } from 'crypto'
import { db } from '@/lib/db'
import type { AppUser, LangCode } from '@/types/marine'

export const SESSION_COOKIE = 'ot_session'
const SESSION_DAYS = 30

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex')
  return `${salt}:${scryptSync(password, salt, 64).toString('hex')}`
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [salt, key] = stored.split(':')
    const derived = scryptSync(password, salt, 64)
    return timingSafeEqual(derived, Buffer.from(key, 'hex'))
  } catch { return false }
}

export async function createSession(userId: string): Promise<{ token: string; expiresAt: Date }> {
  const token = randomBytes(32).toString('hex')
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86_400_000)
  await db.session.create({ data: { id: token, userId, expiresAt } })
  return { token, expiresAt }
}

export function sessionCookie(token: string, expiresAt: Date) {
  return { name: SESSION_COOKIE, value: token, httpOnly: true, sameSite: 'lax' as const, path: '/', expires: expiresAt, secure: process.env.NODE_ENV === 'production' }
}

export function clearSessionCookie() {
  return { name: SESSION_COOKIE, value: '', httpOnly: true, sameSite: 'lax' as const, path: '/', maxAge: 0 }
}

export async function destroySession(req: NextRequest) {
  const token = req.cookies.get(SESSION_COOKIE)?.value
  if (token) await db.session.deleteMany({ where: { id: token } })
}

/** Resolve the authenticated user from the request cookie (RLS-equivalent scoping). */
export async function getSessionUser(req: NextRequest): Promise<AppUser | null> {
  const token = req.cookies.get(SESSION_COOKIE)?.value
  if (!token) return null
  const session = await db.session.findUnique({ where: { id: token }, include: { user: { include: { role: true } } } })
  if (!session || session.expiresAt < new Date()) return null
  const u = session.user
  return {
    id: u.id, email: u.email, fullName: u.fullName, phone: u.phone,
    preferredLanguage: (u.preferredLanguage ?? 'en') as LangCode, themePreference: u.themePreference,
    homeLocation: u.homeLocation, role: u.role?.role ?? 'fisherman',
  }
}

/** Guard helper — throws a Response when unauthenticated. */
export function unauthorized() {
  return NextResponse.json({ error: 'unauthenticated' }, { status: 401 })
}

export function publicUser(u: {
  id: string; email: string; fullName: string; phone: string | null
  preferredLanguage: string; themePreference: string; homeLocation: string; role?: { role: string } | null
}): AppUser {
  return {
    id: u.id, email: u.email, fullName: u.fullName, phone: u.phone,
    preferredLanguage: (u.preferredLanguage ?? 'en') as LangCode, themePreference: u.themePreference,
    homeLocation: u.homeLocation, role: u.role?.role ?? 'fisherman',
  }
}
