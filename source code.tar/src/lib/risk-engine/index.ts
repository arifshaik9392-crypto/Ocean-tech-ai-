// OceanTech AI — deterministic risk engine
// The LLM NEVER decides safety. This module does, with configurable weights.
import type { RiskFactor, RiskLevel, RiskResult } from '@/types/marine'

export interface RiskWeights {
  wind: number; waves: number; weather: number; alerts: number; ocean: number; gis: number; fishing: number
}

/** Default weighting (percent) — configurable via engine config */
export const DEFAULT_WEIGHTS: RiskWeights = {
  wind: 20, waves: 25, weather: 15, alerts: 20, ocean: 10, gis: 5, fishing: 5,
}

export interface RiskInputs {
  windKmh: number
  waveHeightM: number
  weatherCondition: string      // clear | partly_cloudy | cloudy | rain | heavy_rain | thunderstorm
  stormProbability: number      // 0-100
  maxAlertSeverity: 'none' | 'Information' | 'Advisory' | 'Warning' | 'Severe'
  currentSpeedMs: number
  gisConflicts: number          // number of restricted/protected geofence conflicts
  fishingStatus: 'available' | 'restricted' | 'none'
  missing?: string[]            // agent names with no data → lowers confidence
}

const clamp01 = (v: number) => Math.max(0, Math.min(100, v))

export function windScore(kmh: number): number {
  if (kmh < 10) return 10
  if (kmh < 15) return 25
  if (kmh < 20) return 40
  if (kmh < 25) return 55
  if (kmh < 30) return 75
  return 92
}

export function waveScore(m: number): number {
  if (m < 1) return 10
  if (m < 1.5) return 25
  if (m < 2) return 45
  if (m < 2.5) return 65
  if (m < 3) return 82
  return 95
}

export function weatherScore(condition: string, stormProbability: number): number {
  const base =
    condition === 'clear' ? 10 :
    condition === 'partly_cloudy' ? 22 :
    condition === 'cloudy' ? 35 :
    condition === 'rain' ? 55 :
    condition === 'heavy_rain' ? 78 : 92
  return clamp01(base * 0.75 + stormProbability * 0.45)
}

export function alertScore(sev: RiskInputs['maxAlertSeverity']): number {
  switch (sev) {
    case 'Severe': return 95
    case 'Warning': return 75
    case 'Advisory': return 45
    case 'Information': return 20
    default: return 5
  }
}

export function oceanScore(currentMs: number): number {
  if (currentMs < 0.5) return 15
  if (currentMs < 1) return 35
  if (currentMs < 1.5) return 60
  return 80
}

export function gisScore(conflicts: number): number {
  if (conflicts <= 0) return 5
  if (conflicts === 1) return 50
  return 80
}

export function fishingScore(status: RiskInputs['fishingStatus']): number {
  if (status === 'available') return 15
  if (status === 'restricted') return 30
  return 55
}

export function levelFor(score: number): RiskLevel {
  if (score <= 35) return 'SAFE'
  if (score <= 65) return 'MODERATE'
  return 'HIGH'
}

export function assessRisk(inputs: RiskInputs, weights: RiskWeights = DEFAULT_WEIGHTS): RiskResult {
  const defs: { key: keyof RiskWeights; labelKey: string; score: number; detail: string }[] = [
    { key: 'wind', labelKey: 'cond.wind', score: windScore(inputs.windKmh), detail: `${Math.round(inputs.windKmh)} km/h` },
    { key: 'waves', labelKey: 'cond.waves', score: waveScore(inputs.waveHeightM), detail: `${inputs.waveHeightM.toFixed(1)} m` },
    { key: 'weather', labelKey: 'cond.weather', score: weatherScore(inputs.weatherCondition, inputs.stormProbability), detail: `p(storm) ${Math.round(inputs.stormProbability)}%` },
    { key: 'alerts', labelKey: 'cond.marineAlert', score: alertScore(inputs.maxAlertSeverity), detail: inputs.maxAlertSeverity === 'none' ? 'none' : inputs.maxAlertSeverity },
    { key: 'ocean', labelKey: 'cond.current', score: oceanScore(inputs.currentSpeedMs), detail: `${inputs.currentSpeedMs.toFixed(2)} m/s` },
    { key: 'gis', labelKey: 'map.layerRestricted', score: gisScore(inputs.gisConflicts), detail: `${inputs.gisConflicts} conflict(s)` },
    { key: 'fishing', labelKey: 'cond.fishingZone', score: fishingScore(inputs.fishingStatus), detail: inputs.fishingStatus },
  ]
  const wTotal = Object.values(weights).reduce((a, b) => a + b, 0) || 100
  const factors: RiskFactor[] = defs.map((d) => {
    const weight = weights[d.key] ?? 0
    return {
      key: d.key as string,
      labelKey: d.labelKey,
      score: Math.round(d.score),
      weight,
      contribution: Math.round(((d.score * weight) / 100 / wTotal) * 100 * 10) / 10,
      detail: d.detail,
    }
  })
  const score = Math.round(factors.reduce((a, f) => a + f.contribution, 0))
  const missingPenalty = Math.min(0.25, (inputs.missing?.length ?? 0) * 0.07)
  const confidence = Math.round((0.92 - missingPenalty) * 100) / 100
  return { level: levelFor(score), score, confidence, factors: factors.sort((a, b) => b.contribution - a.contribution) }
}
