// OceanTech AI — AIService abstraction
// Uses an LLM when available (server-side only) with STRICT timeout + guardrails.
// Every consumer must have a deterministic fallback; the platform never depends on the LLM.
import type { LangCode } from '@/types/marine'

export interface ChatMessage { role: 'system' | 'user' | 'assistant'; content: string }

interface ZaiLike {
  chat: { completions: { create: (args: unknown) => Promise<{ choices: { message?: { content?: string } }[] }> } }
}

const TIMEOUT_MS = 7000

/**
 * Attempts a conversational LLM completion. Returns null when the LLM is
 * unavailable, slow, or errors — callers then use deterministic templates.
 */
export async function aiConverse(messages: ChatMessage[], lang: LangCode = 'en'): Promise<string | null> {
  try {
    const mod = await import('z-ai-web-dev-sdk')
    const ZAI = (mod as unknown as { default?: unknown }).default ?? mod
    const zai = (await (ZAI as unknown as () => Promise<ZaiLike>)()) as ZaiLike
    const SYSTEM_GUARD = [
      'You are OceanTech AI, a marine decision-support assistant for fishermen on the Indian coast.',
      'NEVER state that conditions are definitely safe. Never invent numeric weather values.',
      'Speak in this language code: ' + lang + '. Keep replies under 80 words, warm and simple.',
      'If asked about emergencies, tell the user to contact official emergency services immediately.',
    ].join(' ')
    const completion = await Promise.race([
      zai.chat.completions.create({ messages: [{ role: 'system', content: SYSTEM_GUARD }, ...messages], temperature: 0.4 }),
      new Promise<null>((resolve) => setTimeout(() => resolve(null), TIMEOUT_MS)),
    ])
    const text = completion?.choices?.[0]?.message?.content?.trim()
    return text && text.length > 0 ? text : null
  } catch {
    return null
  }
}
