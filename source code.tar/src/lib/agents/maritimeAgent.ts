// Maritime Intelligence Agent — shipping lanes, port traffic, navigation notes
import { getGisZones, haversineKm } from '@/lib/data/providers'
import { timed, type AgentContext, type AgentOutput } from './types'

export interface MaritimeData {
  shippingLaneProximityKm: number | null
  trafficLevel: 'low' | 'moderate' | 'high'
  notes: string[]
}

export async function maritimeAgent(ctx: AgentContext): Promise<AgentOutput<MaritimeData>> {
  return timed('maritime', 'agents.maritime', async () => {
    const zones = (await getGisZones()).filter((z) => z.zoneType === 'shipping_lane')
    let nearestKm: number | null = null
    for (const z of zones) {
      const d = haversineKm(ctx.location.latitude, ctx.location.longitude, z.centerLat, z.centerLon)
      if (nearestKm === null || d < nearestKm) nearestKm = Math.round(d * 10) / 10
    }
    const trafficLevel: MaritimeData['trafficLevel'] = nearestKm === null ? 'low' : nearestKm < 12 ? 'high' : nearestKm < 30 ? 'moderate' : 'low'
    const notes: string[] = []
    if (trafficLevel === 'high') notes.push('Active shipping corridor nearby — keep VHF channel 16 watch and avoid crossing convoys.')
    else if (trafficLevel === 'moderate') notes.push('Moderate vessel traffic expected along the fairway.')
    return {
      status: 'completed', confidence: 0.85,
      summary: nearestKm !== null ? `shipping lane ${nearestKm} km, ${trafficLevel} traffic` : 'no shipping lanes nearby',
      source: 'OceanTech Structured Maritime Feed', dataStatus: 'SAMPLE', updatedAt: ctx.now.toISOString(),
      data: { shippingLaneProximityKm: nearestKm, trafficLevel, notes },
    }
  })
}
