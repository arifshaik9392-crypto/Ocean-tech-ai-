// Alert Agent — active marine alerts near the location
import { getAlerts, maxSeverity } from '@/lib/data/providers'
import type { MarineAlertInfo } from '@/types/marine'
import { timed, type AgentContext, type AgentOutput } from './types'

export interface AlertAgentData {
  alerts: MarineAlertInfo[]
  max: ReturnType<typeof maxSeverity>
}

export async function alertAgent(ctx: AgentContext): Promise<AgentOutput<AlertAgentData>> {
  return timed('alerts', 'agents.alerts', async () => {
    const alerts = await getAlerts(ctx.location.slug)
    const max = maxSeverity(alerts)
    return {
      status: 'completed', confidence: 0.93,
      summary: max === 'none' ? 'no active alerts' : `${alerts.length} active, max ${max}`,
      source: 'OceanTech Structured Alert Feed', dataStatus: 'SAMPLE', updatedAt: ctx.now.toISOString(),
      data: { alerts, max },
    }
  })
}
