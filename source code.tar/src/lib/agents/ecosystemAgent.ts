// Ecosystem Agent — SST, chlorophyll, anomalies
import { getEcosystem } from '@/lib/data/providers'
import type { EcosystemData } from '@/types/marine'
import { timed, type AgentContext, type AgentOutput } from './types'

export async function ecosystemAgent(ctx: AgentContext): Promise<AgentOutput<EcosystemData>> {
  return timed('ecosystem', 'agents.ecosystem', async () => {
    const d = await getEcosystem(ctx.location.slug)
    return {
      status: 'completed', confidence: d.confidence,
      summary: `SST ${d.sst}°C, chl ${d.chlorophyll} mg/m³${d.anomalies.length ? ', anomaly: ' + d.anomalies[0] : ''}`,
      source: d.source, dataStatus: d.dataStatus, updatedAt: d.updatedAt, data: d,
    }
  })
}
