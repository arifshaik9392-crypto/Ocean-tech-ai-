// Weather Agent — temperature, wind, rainfall, condition, storm probability
import { getWeather } from '@/lib/data/providers'
import type { WeatherData } from '@/types/marine'
import { timed, type AgentContext, type AgentOutput } from './types'

export async function weatherAgent(ctx: AgentContext): Promise<AgentOutput<WeatherData>> {
  return timed('weather', 'agents.weather', async () => {
    const d = await getWeather(ctx.location.slug, ctx.requestedAt)
    return {
      status: 'completed', confidence: d.confidence,
      summary: `${Math.round(d.windSpeed)} km/h wind, ${d.condition.replace('_', ' ')}`,
      source: d.source, dataStatus: d.dataStatus, updatedAt: d.updatedAt, data: d,
    }
  })
}
