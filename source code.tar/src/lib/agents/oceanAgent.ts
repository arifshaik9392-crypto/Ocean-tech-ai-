// Ocean Agent — waves, currents, sea state
import { getOcean } from '@/lib/data/providers'
import type { OceanData } from '@/types/marine'
import { timed, type AgentContext, type AgentOutput } from './types'

export function seaState(waveHeight: number): 'calm' | 'slight' | 'moderate' | 'rough' | 'very_rough' {
  if (waveHeight < 0.5) return 'calm'
  if (waveHeight < 1.25) return 'slight'
  if (waveHeight < 2.5) return 'moderate'
  if (waveHeight < 4) return 'rough'
  return 'very_rough'
}

export async function oceanAgent(ctx: AgentContext): Promise<AgentOutput<OceanData>> {
  return timed('ocean', 'agents.ocean', async () => {
    const d = await getOcean(ctx.location.slug, ctx.requestedAt)
    return {
      status: 'completed', confidence: d.confidence,
      summary: `${d.waveHeight.toFixed(1)} m waves, ${d.currentSpeed.toFixed(2)} m/s current`,
      source: d.source, dataStatus: d.dataStatus, updatedAt: d.updatedAt, data: d,
    }
  })
}
