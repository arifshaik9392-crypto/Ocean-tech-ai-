// OceanTech AI — agent framework types
import type { MarinePoint, WeatherData, OceanData, FishingZoneInfo, GisZoneInfo, MarineAlertInfo, EcosystemData } from '@/types/marine'

export interface AgentContext {
  location: MarinePoint
  requestedAt: Date   // the target datetime of the planned activity
  now: Date
}

export interface AgentOutput<T = unknown> {
  name: string
  labelKey: string
  status: 'completed' | 'degraded' | 'failed'
  confidence: number
  executionTimeMs: number
  summary: string
  source: string
  dataStatus: 'SAMPLE' | 'LIVE'
  updatedAt: string
  data: T | null
}

export async function timed<T>(name: string, labelKey: string, fn: () => Promise<Omit<AgentOutput<T>, 'name' | 'labelKey' | 'executionTimeMs'>>): Promise<AgentOutput<T>> {
  const started = Date.now()
  try {
    const rest = await fn()
    return { name, labelKey, executionTimeMs: Date.now() - started, ...rest }
  } catch (e) {
    return {
      name, labelKey, executionTimeMs: Date.now() - started, status: 'failed', confidence: 0,
      summary: 'data unavailable', source: '—', dataStatus: 'SAMPLE', updatedAt: new Date().toISOString(), data: null,
    }
  }
}
