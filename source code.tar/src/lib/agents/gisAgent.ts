// GIS Agent — restricted zones, protected areas, geofence conflicts
import { getGeofenceConflicts, getGisZones, haversineKm } from '@/lib/data/providers'
import type { GisZoneInfo } from '@/types/marine'
import { timed, type AgentContext, type AgentOutput } from './types'

export interface GisAgentData {
  conflicts: GisZoneInfo[]
  restricted: GisZoneInfo[]
  protected: GisZoneInfo[]
  routeConflict: GisZoneInfo | null
}

export async function gisAgent(ctx: AgentContext): Promise<AgentOutput<GisAgentData>> {
  return timed('gis', 'agents.gis', async () => {
    const [zones, conflicts] = await Promise.all([getGisZones(), getGeofenceConflicts(ctx.location.latitude, ctx.location.longitude)])
    const restricted = zones.filter((z) => z.zoneType === 'restricted')
    const protected_ = zones.filter((z) => z.zoneType === 'protected' || z.zoneType === 'shipping_lane')
    // check whether a short outbound route toward open sea would cross a geofence
    const seaward = { lat: ctx.location.latitude + 0.18, lon: ctx.location.longitude + 0.18 }
    const routeConflict = conflicts[0] ?? zones.find((z) => (z.zoneType === 'restricted' || z.zoneType === 'protected') && haversineKm(seawardedLat(seaward.lat), seawardedLon(seaward.lon), z.centerLat, z.centerLon) <= z.radiusKm) ?? null
    return {
      status: 'completed', confidence: 0.9,
      summary: conflicts.length ? `${conflicts.length} geofence conflict(s): ${conflicts[0].name}` : 'no geofence conflicts',
      source: 'OceanTech Structured GIS Feed', dataStatus: 'SAMPLE', updatedAt: ctx.now.toISOString(),
      data: { conflicts, restricted, protected: protected_, routeConflict },
    }
  })
}

const seawardedLat = (v: number) => v
const seawardedLon = (v: number) => v
