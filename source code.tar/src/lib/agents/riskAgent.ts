// Risk Agent — wraps the deterministic risk engine with agent outputs
import { assessRisk, type RiskInputs } from '@/lib/risk-engine'
import type { WeatherData, OceanData } from '@/types/marine'
import type { AgentOutput } from './types'
import type { AlertAgentData } from './alertAgent'
import type { FishingAgentData } from './fishingAgent'
import type { GisAgentData } from './gisAgent'

export function buildRiskInputs(
  weather: AgentOutput<WeatherData> | null,
  ocean: AgentOutput<OceanData> | null,
  alerts: AgentOutput<AlertAgentData> | null,
  fishing: AgentOutput<FishingAgentData> | null,
  gis: AgentOutput<GisAgentData> | null,
): { inputs: RiskInputs; missing: string[] } {
  const missing: string[] = []
  const w = weather?.data
  const o = ocean?.data
  if (!w) missing.push('weather')
  if (!o) missing.push('ocean')
  const inputs: RiskInputs = {
    windKmh: w?.windSpeed ?? 18,
    waveHeightM: o?.waveHeight ?? 1.6,
    weatherCondition: w?.condition ?? 'cloudy',
    stormProbability: w?.stormProbability ?? 20,
    maxAlertSeverity: alerts?.data?.max ?? 'none',
    currentSpeedMs: o?.currentSpeed ?? 0.6,
    gisConflicts: gis?.data?.conflicts.length ?? 0,
    fishingStatus: !fishing?.data || fishing.data.availableCount === 0 ? 'none' : fishing.data.zones.some((z) => z.advisoryStatus === 'Restricted' && z.distanceKm < 25) ? 'restricted' : 'available',
    missing,
  }
  return { inputs, missing }
}

export function riskAgent(
  weather: AgentOutput<WeatherData> | null,
  ocean: AgentOutput<OceanData> | null,
  alerts: AgentOutput<AlertAgentData> | null,
  fishing: AgentOutput<FishingAgentData> | null,
  gis: AgentOutput<GisAgentData> | null,
) {
  const { inputs, missing } = buildRiskInputs(weather, ocean, alerts, fishing, gis)
  const result = assessRisk(inputs)
  return { result, inputs, missing }
}
