// Fishing Agent — potential fishing zones, suitability, SST, chlorophyll
import { getFishingZones } from '@/lib/data/providers'
import type { FishingZoneInfo } from '@/types/marine'
import { timed, type AgentContext, type AgentOutput } from './types'

export interface FishingAgentData {
  zones: FishingZoneInfo[]
  availableCount: number
  nearest: FishingZoneInfo | null
}

export async function fishingAgent(ctx: AgentContext): Promise<AgentOutput<FishingAgentData>> {
  return timed('fishing', 'agents.fishing', async () => {
    const zones = await getFishingZones(ctx.location.latitude, ctx.location.longitude)
    const usable = zones.filter((z) => z.advisoryStatus === 'Available')
    const nearest = usable[0] ?? zones[0] ?? null
    return {
      status: zones.length ? 'completed' : 'degraded', confidence: zones.length ? 0.88 : 0.4,
      summary: nearest ? `${usable.length} zone(s) available, nearest ${nearest.code} ${nearest.distanceKm} km` : 'no zones',
      source: 'OceanTech Structured PFZ Feed', dataStatus: 'SAMPLE',
      updatedAt: nearest?.updatedAt ?? new Date().toISOString(),
      data: { zones, availableCount: usable.length, nearest },
    }
  })
}
