'use client'
// OceanTech AI — client app state
import { create } from 'zustand'
import type { AppUser, MapFocusPoint, OrchestratorResult, ViewKey } from '@/types/marine'

interface AppState {
  view: ViewKey
  setView: (v: ViewKey) => void
  user: AppUser | null
  setUser: (u: AppUser | null) => void
  homeLocation: string
  setHomeLocation: (s: string) => void
  mapFocus: MapFocusPoint | null
  setMapFocus: (f: MapFocusPoint | null) => void
  /** hand an assessment/result to another view (assistant ↔ voice ↔ reports) */
  sharedResult: OrchestratorResult | null
  setSharedResult: (r: OrchestratorResult | null) => void
  /** when true, assistant view should prefill with shared result */
  consumeShared: boolean
  markConsumed: () => void
  sidebarOpen: boolean
  setSidebarOpen: (b: boolean) => void
}

export const useApp = create<AppState>((set) => ({
  view: 'overview',
  setView: (view) => set({ view, sidebarOpen: false }),
  user: null,
  setUser: (user) => set(user ? { user, homeLocation: user.homeLocation || 'Kakinada' } : { user }),
  homeLocation: 'Kakinada',
  setHomeLocation: (homeLocation) => set({ homeLocation }),
  mapFocus: null,
  setMapFocus: (mapFocus) => set({ mapFocus }),
  sharedResult: null,
  setSharedResult: (sharedResult) => set({ sharedResult, consumeShared: true }),
  consumeShared: false,
  markConsumed: () => set({ consumeShared: false }),
  sidebarOpen: false,
  setSidebarOpen: (sidebarOpen) => set({ sidebarOpen }),
}))

/** Convenience: focus the marine map on a point */
export function focusMap(f: MapFocusPoint) {
  useApp.getState().setMapFocus(f)
  useApp.getState().setView('map')
}
