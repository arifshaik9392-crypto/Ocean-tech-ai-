// OceanTech AI — MarineDataProvider abstraction
// Structured provider (DB-backed, deterministic forecast synthesis) with the same
// interface a live provider would implement. Components never hardcode marine values.
import { db } from '@/lib/db'
import type { EcosystemData, FishingZoneInfo, GisZoneInfo, MarineAlertInfo, MarinePoint, OceanData, WeatherData } from '@/types/marine'

const SAMPLE = 'SAMPLE' as const
const weatherSource = 'OceanTech Structured Weather Feed'
const oceanSource = 'OceanTech Structured Ocean Feed'
const ecoSource = 'OceanTech Structured Satellite Feed'
const forecastSource = 'OceanTech Structured Forecast'

function hash(s: string): number {
  let h = 2166136261
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) }
  return h >>> 0
}
function rng(seed: string) {
  let a = hash(seed)
  return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296 }
}
const round = (v: number, d = 1) => Math.round(v * 10 ** d) / 10 ** d

const BASELINES: Record<string, { temp: number; wind: number; wave: number; current: number; seaT: number }> = {
  kakinada: { temp: 29.5, wind: 16, wave: 1.5, current: 0.6, seaT: 28.2 },
  visakhapatnam: { temp: 30, wind: 17, wave: 1.6, current: 0.65, seaT: 28.4 },
  chennai: { temp: 30.5, wind: 15, wave: 1.4, current: 0.55, seaT: 28.6 },
  tuticorin: { temp: 29, wind: 14, wave: 1.1, current: 0.5, seaT: 28.0 },
  kochi: { temp: 28.5, wind: 13, wave: 1.2, current: 0.5, seaT: 28.1 },
  mangaluru: { temp: 29, wind: 14, wave: 1.3, current: 0.55, seaT: 28.2 },
  mumbai: { temp: 29.5, wind: 15, wave: 1.4, current: 0.55, seaT: 28.3 },
  goa: { temp: 29.5, wind: 12, wave: 1.2, current: 0.5, seaT: 28.3 },
  paradip: { temp: 29, wind: 18, wave: 1.7, current: 0.7, seaT: 28.5 },
  sagar: { temp: 28.5, wind: 19, wave: 1.8, current: 0.75, seaT: 28.4 },
}
const DEFAULT_BASE = { temp: 29, wind: 15, wave: 1.4, current: 0.6, seaT: 28.2 }
const WIND_DIRS = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW']

export function haversineKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371, dLat = ((lat2 - lat1) * Math.PI) / 180, dLon = ((lon2 - lon1) * Math.PI) / 180
  const a = Math.sin(dLat / 2) ** 2 + Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2
  return Math.round(R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)) * 10) / 10
}

// ── Locations ───────────────────────────────────────────────────────────────

export async function getLocations(): Promise<MarinePoint[]> {
  const rows = await db.marineLocation.findMany({ orderBy: { name: 'asc' } })
  return rows.map((r) => ({ name: r.name, slug: r.slug, state: r.state, latitude: r.latitude, longitude: r.longitude, type: r.type }))
}

export async function getLocation(slug: string): Promise<MarinePoint | null> {
  const r = await db.marineLocation.findUnique({ where: { slug } })
  return r ? { name: r.name, slug: r.slug, state: r.state, latitude: r.latitude, longitude: r.longitude, type: r.type } : null
}

// ── Weather provider ────────────────────────────────────────────────────────

function synthWeather(slug: string, at: Date): WeatherData {
  const b = BASELINES[slug] ?? DEFAULT_BASE
  const hourKey = at.toISOString().slice(0, 13)
  const r = rng(`wf:${slug}:${hourKey}`)
  const hour = at.getHours()
  const diurnal = Math.sin(((hour - 6) / 24) * Math.PI * 2)
  const windSpeed = round(Math.max(4, b.wind + diurnal * 4 + (r() - 0.5) * 9), 1)
  const c = r()
  const condition = c < 0.42 ? 'clear' : c < 0.72 ? 'partly_cloudy' : c < 0.9 ? 'cloudy' : 'rain'
  return {
    temperature: round(b.temp + diurnal * 2.2 + (r() - 0.5) * 1.6, 1),
    humidity: round(62 + r() * 26, 0),
    windSpeed, windDirection: WIND_DIRS[Math.floor(r() * 16)],
    windGust: round(windSpeed * (1.3 + r() * 0.35), 1),
    rainfallMm: condition === 'rain' ? round(r() * 6, 1) : 0,
    condition,
    stormProbability: condition === 'rain' ? round(8 + r() * 22, 0) : round(r() * 6, 0),
    updatedAt: at.toISOString(), source: forecastSource, dataStatus: SAMPLE, confidence: 0.9,
  }
}

export async function getWeather(slug: string, at: Date = new Date()): Promise<WeatherData> {
  // For near-now requests, prefer the freshest stored observation (feels "live")
  const horizon = new Date(at.getTime() - 2 * 3600_000)
  const latest = await db.weatherObservation.findFirst({ where: { locationSlug: slug, recordedAt: { gte: horizon } }, orderBy: { recordedAt: 'desc' } })
  if (latest) {
    return {
      temperature: latest.temperature, humidity: latest.humidity, windSpeed: latest.windSpeed,
      windDirection: latest.windDirection, windGust: latest.windGust, rainfallMm: latest.rainfallMm,
      condition: latest.condition, stormProbability: latest.stormProbability,
      updatedAt: latest.recordedAt.toISOString(), source: weatherSource, dataStatus: SAMPLE, confidence: 0.92,
    }
  }
  return synthWeather(slug, at)
}

// ── Ocean provider ──────────────────────────────────────────────────────────

function synthOcean(slug: string, at: Date): OceanData {
  const b = BASELINES[slug] ?? DEFAULT_BASE
  const r = rng(`of:${slug}:${at.toISOString().slice(0, 13)}`)
  const hour = at.getHours()
  const tide = Math.sin((hour / 24) * Math.PI * 2 * 2)
  const waveHeight = round(Math.max(0.4, b.wave + tide * 0.25 + (r() - 0.5) * 0.7), 1)
  return {
    waveHeight, wavePeriod: round(5.5 + waveHeight * 1.6 + r() * 1.5, 1),
    waveDirection: WIND_DIRS[Math.floor(r() * 16)],
    currentSpeed: round(Math.max(0.15, b.current + tide * 0.15 + (r() - 0.5) * 0.25), 2),
    currentDirection: WIND_DIRS[Math.floor(r() * 16)],
    seaTemp: round(b.seaT + (r() - 0.5) * 0.5, 1),
    visibilityKm: round(6 + r() * 8, 1),
    updatedAt: at.toISOString(), source: forecastSource, dataStatus: SAMPLE, confidence: 0.88,
  }
}

export async function getOcean(slug: string, at: Date = new Date()): Promise<OceanData> {
  const horizon = new Date(at.getTime() - 2 * 3600_000)
  const latest = await db.oceanObservation.findFirst({ where: { locationSlug: slug, recordedAt: { gte: horizon } }, orderBy: { recordedAt: 'desc' } })
  if (latest) {
    return {
      waveHeight: latest.waveHeight, wavePeriod: latest.wavePeriod, waveDirection: latest.waveDirection,
      currentSpeed: latest.currentSpeed, currentDirection: latest.currentDirection,
      seaTemp: latest.seaTemp, visibilityKm: latest.visibilityKm,
      updatedAt: latest.recordedAt.toISOString(), source: oceanSource, dataStatus: SAMPLE, confidence: 0.9,
    }
  }
  return synthOcean(slug, at)
}

// ── Series (charts) ─────────────────────────────────────────────────────────

export async function getSeries(slug: string, hours = 24) {
  const since = new Date(Date.now() - hours * 3600_000)
  const [w, o] = await Promise.all([
    db.weatherObservation.findMany({ where: { locationSlug: slug, recordedAt: { gte: since } }, orderBy: { recordedAt: 'asc' } }),
    db.oceanObservation.findMany({ where: { locationSlug: slug, recordedAt: { gte: since } }, orderBy: { recordedAt: 'asc' } }),
  ])
  return {
    weather: w.map((x) => ({ t: x.recordedAt.toISOString(), wind: x.windSpeed, temp: x.temperature, rain: x.rainfallMm })),
    ocean: o.map((x) => ({ t: x.recordedAt.toISOString(), wave: x.waveHeight, period: x.wavePeriod, current: x.currentSpeed, seaTemp: x.seaTemp })),
  }
}

// ── Ecosystem provider ──────────────────────────────────────────────────────

export async function getEcosystem(slug: string): Promise<EcosystemData> {
  const latest = await db.ecosystemObservation.findFirst({ where: { locationSlug: slug }, orderBy: { recordedAt: 'desc' } })
  const anomalies: string[] = []
  if (latest?.anomaly) anomalies.push(latest.anomaly)
  return {
    sst: latest?.sst ?? 28.2, chlorophyll: latest?.chlorophyll ?? 1.0, anomalies,
    updatedAt: (latest?.recordedAt ?? new Date()).toISOString(), source: ecoSource, dataStatus: SAMPLE, confidence: 0.87,
  }
}

// ── Fishing provider ────────────────────────────────────────────────────────

export async function getFishingZones(nearLat?: number, nearLon?: number): Promise<FishingZoneInfo[]> {
  const rows = await db.fishingZone.findMany({ orderBy: { distanceKm: 'asc' } })
  const zones: FishingZoneInfo[] = rows.map((z) => ({
    id: z.id, code: z.code, name: z.name, centerLat: z.centerLat, centerLon: z.centerLon,
    distanceKm: z.distanceKm, nearestPort: z.nearestPort, suitability: z.suitability,
    sst: z.sst, chlorophyll: z.chlorophyll, advisoryStatus: z.advisoryStatus, species: z.species,
    updatedAt: z.updatedAt.toISOString(),
  }))
  if (nearLat != null && nearLon != null) {
    for (const z of zones) z.distanceKm = haversineKm(nearLat, nearLon, z.centerLat, z.centerLon)
    zones.sort((a, b) => a.distanceKm - b.distanceKm)
  }
  return zones
}

// ── Alert provider ──────────────────────────────────────────────────────────

const SEV_RANK: Record<string, number> = { Information: 1, Advisory: 2, Warning: 3, Severe: 4 }

export async function getAlerts(regionSlug?: string): Promise<MarineAlertInfo[]> {
  const rows = await db.marineAlert.findMany({ where: { status: 'active' }, orderBy: { issuedAt: 'desc' } })
  let alerts: MarineAlertInfo[] = rows.map((a) => ({
    id: a.id, severity: a.severity as MarineAlertInfo['severity'], title: a.title, description: a.description,
    region: a.region, lat: a.lat, lon: a.lon, radiusKm: a.radiusKm, source: a.source, status: a.status,
    issuedAt: a.issuedAt.toISOString(), expiresAt: a.expiresAt?.toISOString() ?? null,
  }))
  if (regionSlug) {
    const loc = await getLocation(regionSlug)
    if (loc) {
      alerts = alerts.filter((a) => a.lat != null && a.lon != null && haversineKm(loc.latitude, loc.longitude, a.lat, a.lon) <= (a.radiusKm ?? 120) + 60)
        .concat(alerts.filter((a) => a.lat == null || a.lon == null))
    }
  }
  return alerts
}

export function maxSeverity(alerts: MarineAlertInfo[]): 'none' | 'Information' | 'Advisory' | 'Warning' | 'Severe' {
  let max: 'none' | 'Information' | 'Advisory' | 'Warning' | 'Severe' = 'none'
  for (const a of alerts) if (SEV_RANK[a.severity] > (SEV_RANK[max] ?? 0)) max = a.severity
  return max
}

// ── GIS provider ────────────────────────────────────────────────────────────

export async function getGisZones(): Promise<GisZoneInfo[]> {
  const rows = await db.gisZone.findMany()
  return rows.map((g) => ({ id: g.id, name: g.name, zoneType: g.zoneType, centerLat: g.centerLat, centerLon: g.centerLon, radiusKm: g.radiusKm, description: g.description }))
}

export async function getGeofenceConflicts(lat: number, lon: number): Promise<GisZoneInfo[]> {
  const zones = await getGisZones()
  return zones.filter((z) => (z.zoneType === 'restricted' || z.zoneType === 'protected') && haversineKm(lat, lon, z.centerLat, z.centerLon) <= z.radiusKm)
}
