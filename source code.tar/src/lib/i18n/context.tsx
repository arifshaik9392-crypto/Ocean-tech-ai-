'use client'
// OceanTech AI — language context (working top-right language switcher)
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import type { LangCode } from '@/types/marine'
import { LANGUAGES, tf, type DictKey } from './translations'

interface LangCtx {
  lang: LangCode
  setLang: (l: LangCode) => void
  t: (key: DictKey, params?: Record<string, string | number>) => string
  speechLang: string
}

const Ctx = createContext<LangCtx | null>(null)
const STORAGE_KEY = 'oceantech.lang'

export function LanguageProvider({ children, initialLang = 'en', userId }: { children: React.ReactNode; initialLang?: LangCode; userId?: string | null }) {
  const [lang, setLangState] = useState<LangCode>(() => {
    // client preference wins; falls back to the user's profile language
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(STORAGE_KEY) as LangCode | null
        if (saved && LANGUAGES.some((l) => l.code === saved)) return saved
      } catch { /* ignore */ }
    }
    return initialLang
  })

  const setLang = useCallback((l: LangCode) => {
    setLangState(l)
    try { localStorage.setItem(STORAGE_KEY, l) } catch { /* ignore */ }
    document.documentElement.lang = l
    if (userId) {
      // sync to profile (fire and forget)
      fetch('/api/user/preferences', {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ preferredLanguage: l }),
      }).catch(() => undefined)
    }
  }, [userId])

  useEffect(() => { document.documentElement.lang = lang }, [lang])

  const t = useCallback((key: DictKey, params?: Record<string, string | number>) => tf(lang, key, params), [lang])
  const speechLang = useMemo(() => LANGUAGES.find((l) => l.code === lang)?.speech ?? 'en-IN', [lang])

  const value = useMemo(() => ({ lang, setLang, t, speechLang }), [lang, setLang, t, speechLang])
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

export function useLang(): LangCtx {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error('useLang must be used within LanguageProvider')
  return ctx
}
