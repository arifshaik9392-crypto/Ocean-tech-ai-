// OceanTech AI — shared marine types

export type LangCode = 'en' | 'te' | 'hi' | 'ta' | 'ml' | 'kn' | 'mr' | 'bn'

export type ViewKey =
  | 'overview' | 'voice' | 'assistant' | 'map' | 'risk'
  | 'fishing' | 'alerts' | 'ocean' | 'reports' | 'settings'

export type RiskLevel = 'SAFE' | 'MODERATE' | 'HIGH'
export type AlertSeverity = 'Information' | 'Advisory' | 'Warning' | 'Severe'
export type Activity = 'fishing' | 'boating' | 'sailing' | 'swimming' | 'marine_operations'

export interface ParsedQuery {
  location: string | null
  locationSlug: string | null
  latitude: number | null
  longitude: number | null
  activity: Activity
  datePhrase: string | null   // raw phrase e.g. "tomorrow"
  dateISO: string | null      // resolved YYYY-MM-DD
  time: string | null         // "06:00"
  intent: Intent
  raw: string
}

export type Intent =
  | 'marine_safety_assessment'
  | 'fishing_zones'
  | 'alerts'
  | 'ocean_conditions'
  | 'risk_explain'
  | 'greeting'
  | 'capability'
  | 'general'

export interface MarinePoint {
  name: string; slug: string; state: string; latitude: number; longitude: number; type: string
}

export interface WeatherData {
  temperature: number; humidity: number; windSpeed: number; windDirection: string
  windGust: number; rainfallMm: number; condition: string; stormProbability: number
  updatedAt: string; source: string; dataStatus: 'SAMPLE' | 'LIVE'; confidence: number
}

export interface OceanData {
  waveHeight: number; wavePeriod: number; waveDirection: string
  currentSpeed: number; currentDirection: string; seaTemp: number; visibilityKm: number
  updatedAt: string; source: string; dataStatus: 'SAMPLE' | 'LIVE'; confidence: number
}

export interface FishingZoneInfo {
  id: string; code: string; name: string; centerLat: number; centerLon: number
  distanceKm: number; nearestPort: string; suitability: string; sst: number
  chlorophyll: number; advisoryStatus: string; species: string; updatedAt: string
}

export interface MarineAlertInfo {
  id: string; severity: AlertSeverity; title: string; description: string; region: string
  lat: number | null; lon: number | null; radiusKm: number | null; source: string
  status: string; issuedAt: string; expiresAt: string | null
}

export interface GisZoneInfo {
  id: string; name: string; zoneType: string; centerLat: number; centerLon: number
  radiusKm: number; description: string | null
}

export interface EcosystemData {
  sst: number; chlorophyll: number; anomalies: string[]
  updatedAt: string; source: string; dataStatus: 'SAMPLE' | 'LIVE'; confidence: number
}

export interface RiskFactor {
  key: string          // 'wind' | 'waves' | ...
  labelKey: string     // i18n key
  score: number        // 0-100 raw severity
  weight: number       // percent weight
  contribution: number // weighted points (1 decimal)
  detail: string       // human-readable value e.g. "22 km/h"
}

export interface RiskResult {
  level: RiskLevel
  score: number
  confidence: number
  factors: RiskFactor[]
}

export interface AgentRunInfo {
  name: string; labelKey: string; status: 'completed' | 'degraded' | 'failed'
  confidence: number; executionTimeMs: number; summary: string
  source: string; dataStatus: 'SAMPLE' | 'LIVE'; updatedAt: string
}

export interface ConditionItem { value: string; detail?: string; key?: string }

export interface AssessmentAnswer {
  oneLiner: string
  explanation: string
  recommendation: string
}

export interface MapFocusPoint {
  lat: number; lon: number; zoom?: number
  layer?: 'fishing' | 'alerts' | 'restricted' | 'protected' | 'risk'
  id?: string; title?: string
}

export interface OrchestratorResult {
  queryId: string | null
  type: 'assessment' | 'follow_up' | 'info'
  language: LangCode
  question: string
  parsed: ParsedQuery | null
  followUp: string | null
  answer: AssessmentAnswer | null
  risk: RiskResult | null
  conditions: Record<string, ConditionItem> | null
  agents: AgentRunInfo[]
  dataFreshness: { agent: string; updatedAt: string; minutesAgo: number }[]
  alerts: MarineAlertInfo[]
  fishingZones: FishingZoneInfo[]
  gisZones: GisZoneInfo[]
  mapFocus: MapFocusPoint | null
  locationName: string | null
  requestedWhen: string | null
  createdAt: string
}

export interface AppUser {
  id: string; email: string; fullName: string; phone: string | null
  preferredLanguage: LangCode; themePreference: string; homeLocation: string
  role: string
}
