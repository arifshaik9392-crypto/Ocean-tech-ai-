'use client'
// OceanTech AI — single-page application shell (the only user-visible route)
import { useEffect, useState } from 'react'
import { ThemeProvider } from 'next-themes'
import { Loader2 } from 'lucide-react'
import { LanguageProvider } from '@/lib/i18n/context'
import { useApp } from '@/lib/store'
import { AppHeader } from '@/components/layout/AppHeader'
import { Sidebar } from '@/components/layout/Sidebar'
import { BottomNav } from '@/components/layout/BottomNav'
import { AuthScreen } from '@/components/layout/AuthScreen'
import { OverviewView } from '@/components/views/OverviewView'
import { VoiceView } from '@/components/views/VoiceView'
import { AssistantView } from '@/components/views/AssistantView'
import { MapView } from '@/components/views/MapView'
import { RiskView } from '@/components/views/RiskView'
import { FishingView } from '@/components/views/FishingView'
import { AlertsView } from '@/components/views/AlertsView'
import { OceanView } from '@/components/views/OceanView'
import { ReportsView } from '@/components/views/ReportsView'
import { SettingsView } from '@/components/views/SettingsView'
import type { AppUser } from '@/types/marine'

function Footer() {
  return (
    <footer className="mt-auto border-t border-border/70 px-4 py-3 pb-20 lg:pb-3">
      <div className="mx-auto max-w-6xl space-y-0.5 text-center">
        <p className="text-[11px] leading-snug text-muted-foreground">OceanTech AI · Marine Ecosystem Intelligence & Decision Support</p>
        <p className="text-[10.5px] leading-snug text-muted-foreground/80">
          OceanTech AI is a decision-support system. It does not replace official marine advisories, coast guard instructions or emergency services.
        </p>
      </div>
    </footer>
  )
}

function Splash() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-3 bg-background">
      <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground">
        <svg viewBox="0 0 24 24" className="h-7 w-7 animate-pulse" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden>
          <path d="M2 16c2-2.5 4-2.5 6 0s4 2.5 6 0 4-2.5 6 0" />
          <path d="M12 12V4m0 0l3 3m-3-3l-3 3" />
        </svg>
      </div>
      <p className="text-sm font-semibold tracking-wide">OCEANTECH AI</p>
      <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
    </div>
  )
}

function ViewRouter() {
  const { view } = useApp()
  switch (view) {
    case 'voice': return <VoiceView />
    case 'assistant': return <AssistantView />
    case 'map': return <MapView />
    case 'risk': return <RiskView />
    case 'fishing': return <FishingView />
    case 'alerts': return <AlertsView />
    case 'ocean': return <OceanView />
    case 'reports': return <ReportsView />
    case 'settings': return <SettingsView />
    case 'overview': default: return <OverviewView />
  }
}

export default function OceanTechApp() {
  const { user, setUser, setView } = useApp()
  const [status, setStatus] = useState<'loading' | 'anon' | 'authed'>('loading')

  useEffect(() => {
    let alive = true
    fetch('/api/auth/me')
      .then(async (res) => {
        if (!alive) return
        if (res.ok) {
          const data = await res.json()
          setUser(data.user as AppUser)
          setStatus('authed')
        } else {
          setStatus('anon')
        }
      })
      .catch(() => alive && setStatus('anon'))
    return () => { alive = false }
  }, [setUser])

  // surface shared assessments on the assistant when handed over from voice/risk
  useEffect(() => {
    const unsub = useApp.subscribe((s, prev) => {
      if (s.consumeShared && !prev.consumeShared && s.view !== 'assistant' && s.sharedResult) {
        setView('assistant')
      }
    })
    return unsub
  }, [setView])

  if (status === 'loading') return <Splash />

  return (
    <ThemeProvider attribute="class" defaultTheme={user?.themePreference || 'system'} enableSystem>
      <LanguageProvider initialLang={user?.preferredLanguage ?? 'en'} userId={user?.id ?? null}>
        {!user ? (
          <AuthScreen />
        ) : (
          <div className="flex min-h-screen bg-background">
            <Sidebar />
            <div className="flex min-h-screen w-full min-w-0 flex-col lg:pl-64">
              <AppHeader onMenu={() => useApp.getState().setSidebarOpen(true)} />
              <main className="mx-auto w-full max-w-6xl flex-1 px-3 py-4 sm:px-6 sm:py-6" role="main">
                <ViewRouter />
              </main>
              <Footer />
            </div>
            <BottomNav />
          </div>
        )}
      </LanguageProvider>
    </ThemeProvider>
  )
}
