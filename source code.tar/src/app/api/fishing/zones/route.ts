import { NextRequest, NextResponse } from 'next/server'
import { getFishingZones } from '@/lib/data/providers'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  try {
    const lat = req.nextUrl.searchParams.get('lat')
    const lon = req.nextUrl.searchParams.get('lon')
    const zones = await getFishingZones(lat ? parseFloat(lat) : undefined, lon ? parseFloat(lon) : undefined)
    return NextResponse.json({ zones })
  } catch (e) {
    console.error('fishing zones error', e)
    return NextResponse.json({ zones: [] }, { status: 200 })
  }
}
