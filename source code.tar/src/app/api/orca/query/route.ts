import { NextRequest, NextResponse } from 'next/server'
import { getSessionUser, unauthorized } from '@/lib/auth'
import { runQuery } from '@/lib/orchestrator'
import type { LangCode } from '@/types/marine'

export const dynamic = 'force-dynamic'
export const maxDuration = 30

/**
 * Central orchestration endpoint (equivalent of a Supabase Edge Function):
 * authenticate → parse intent → retrieve marine data → run agents → risk engine → explanation → store → respond
 */
export async function POST(req: NextRequest) {
  try {
    const user = await getSessionUser(req)
    if (!user) return unauthorized()
    const body = await req.json().catch(() => null)
    const query = String(body?.query ?? '').trim()
    if (!query) return NextResponse.json({ error: 'empty query' }, { status: 400 })
    if (query.length > 500) return NextResponse.json({ error: 'query too long' }, { status: 400 })
    const language = (String(body?.language ?? user.preferredLanguage ?? 'en') as LangCode)
    const result = await runQuery({
      query,
      language,
      userId: user.id,
      homeLocation: user.homeLocation,
      pendingField: body?.context?.pendingField ?? null,
      previousActivity: body?.context?.previousActivity,
    })
    return NextResponse.json(result)
  } catch (e) {
    console.error('orca/query error', e)
    return NextResponse.json({ error: 'The marine orchestration service hit an error. Please try again.' }, { status: 500 })
  }
}
