import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser, unauthorized } from '@/lib/auth'

export const dynamic = 'force-dynamic'

/** Query history — scoped to the authenticated user (RLS-equivalent). */
export async function GET(req: NextRequest) {
  const user = await getSessionUser(req)
  if (!user) return unauthorized()
  try {
    const rows = await db.userQuery.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      take: 30,
      include: { assessment: true },
    })
    return NextResponse.json({
      queries: rows.map((q) => ({
        id: q.id, query: q.query, location: q.location, activity: q.activity,
        responseType: q.responseType, createdAt: q.createdAt.toISOString(),
        riskLevel: q.assessment?.riskLevel ?? null, riskScore: q.assessment?.riskScore ?? null,
      })),
    })
  } catch (e) {
    console.error('queries error', e)
    return NextResponse.json({ queries: [] }, { status: 200 })
  }
}
