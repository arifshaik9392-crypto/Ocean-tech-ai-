import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser, unauthorized } from '@/lib/auth'
import type { OrchestratorResult } from '@/types/marine'

export const dynamic = 'force-dynamic'

/** Reopen a past assessment — ownership enforced (RLS-equivalent). */
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await getSessionUser(req)
  if (!user) return unauthorized()
  const { id } = await params
  try {
    const q = await db.userQuery.findFirst({
      where: { id, userId: user.id },
      include: { assessment: true, agentRuns: true },
    })
    if (!q) return NextResponse.json({ error: 'not found' }, { status: 404 })
    let answer: { oneLiner: string; explanation: string; recommendation: string } | null = null
    let conditions: Record<string, { value: string }> | null = null
    if (q.assessment) {
      const a = JSON.parse(q.assessment.answerJson)
      answer = { oneLiner: a.oneLiner ?? '', explanation: a.explanation ?? '', recommendation: a.recommendation ?? '' }
      conditions = JSON.parse(q.assessment.conditionsJson)
    }
    const result: OrchestratorResult = {
      queryId: q.id,
      type: q.responseType as OrchestratorResult['type'],
      language: q.language as OrchestratorResult['language'],
      question: q.query, parsed: null, followUp: null,
      answer,
      risk: q.assessment ? {
        level: q.assessment.riskLevel as 'SAFE' | 'MODERATE' | 'HIGH',
        score: q.assessment.riskScore, confidence: q.assessment.confidence,
        factors: JSON.parse(q.assessment.factorsJson),
      } : null,
      conditions,
      agents: q.agentRuns.map((a) => {
        let summary = '', source = '—', updatedAt = q.createdAt.toISOString()
        try { const o = JSON.parse(a.outputDataJson); summary = o.summary ?? ''; source = o.source ?? '—'; updatedAt = o.updatedAt ?? updatedAt } catch { /* noop */ }
        return {
          name: a.agentName, labelKey: `agents.${a.agentName}`, status: a.status as 'completed',
          confidence: a.confidence ?? 0.9, executionTimeMs: a.executionTimeMs ?? 0,
          summary, source, dataStatus: 'SAMPLE' as const, updatedAt,
        }
      }),
      dataFreshness: [], alerts: [], fishingZones: [], gisZones: [], mapFocus: null,
      locationName: q.location, requestedWhen: q.requestedDate && q.requestedTime ? `${q.requestedDate} ${q.requestedTime}` : null,
      createdAt: q.createdAt.toISOString(),
    }
    return NextResponse.json(result)
  } catch (e) {
    console.error('query detail error', e)
    return NextResponse.json({ error: 'server' }, { status: 500 })
  }
}
