import { NextResponse } from 'next/server'
import { getGisZones } from '@/lib/data/providers'

export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const zones = await getGisZones()
    return NextResponse.json({ zones })
  } catch (e) {
    console.error('gis error', e)
    return NextResponse.json({ zones: [] }, { status: 200 })
  }
}
