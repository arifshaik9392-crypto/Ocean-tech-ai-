import { NextRequest, NextResponse } from 'next/server'
import { getAlerts } from '@/lib/data/providers'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  try {
    const location = req.nextUrl.searchParams.get('location')
    const alerts = await getAlerts(location ?? undefined)
    return NextResponse.json({ alerts })
  } catch (e) {
    console.error('alerts error', e)
    return NextResponse.json({ alerts: [] }, { status: 200 })
  }
}
