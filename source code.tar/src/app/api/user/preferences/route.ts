import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser, publicUser, unauthorized } from '@/lib/auth'

export const dynamic = 'force-dynamic'

export async function PATCH(req: NextRequest) {
  const user = await getSessionUser(req)
  if (!user) return unauthorized()
  const body = await req.json().catch(() => ({}))
  const data: Record<string, string> = {}
  if (typeof body.preferredLanguage === 'string' && body.preferredLanguage.length === 2) data.preferredLanguage = body.preferredLanguage
  if (typeof body.themePreference === 'string' && ['light', 'dark', 'system'].includes(body.themePreference)) data.themePreference = body.themePreference
  if (typeof body.homeLocation === 'string' && body.homeLocation.length > 1) data.homeLocation = body.homeLocation
  if (typeof body.fullName === 'string' && body.fullName.trim().length >= 2) data.fullName = body.fullName.trim()
  if (typeof body.phone === 'string') data.phone = body.phone.trim()
  const updated = await db.user.update({ where: { id: user.id }, data, include: { role: true } })
  return NextResponse.json({ user: publicUser(updated) })
}
