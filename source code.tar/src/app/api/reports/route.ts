import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser, unauthorized } from '@/lib/auth'
import { tf } from '@/lib/i18n/translations'
import type { LangCode, OrchestratorResult, RiskFactor, AssessmentAnswer, ConditionItem } from '@/types/marine'

export const dynamic = 'force-dynamic'

function buildReportContent(q: {
  query: string; location: string | null; requestedDate: string | null; requestedTime: string | null; language: string; createdAt: Date
}, assessment: { riskLevel: string; riskScore: number; confidence: number; factorsJson: string; conditionsJson: string; answerJson: string } | null,
  agents: { agentName: string; status: string; confidence: number | null; executionTimeMs: number | null; outputDataJson: string }[],
  lang: LangCode) {
  const answer = assessment ? (JSON.parse(assessment.answerJson) as AssessmentAnswer) : null
  const factors = assessment ? (JSON.parse(assessment.factorsJson) as RiskFactor[]) : []
  const conditions = assessment ? (JSON.parse(assessment.conditionsJson) as Record<string, ConditionItem>) : null
  return {
    question: q.query,
    location: q.location,
    datetime: q.requestedDate && q.requestedTime ? `${q.requestedDate} ${q.requestedTime}` : null,
    assessedAt: q.createdAt.toISOString(),
    risk: assessment ? { level: assessment.riskLevel, score: assessment.riskScore, confidence: assessment.confidence } : null,
    oneLiner: answer?.oneLiner ?? null,
    explanation: answer?.explanation ?? null,
    recommendation: answer?.recommendation ?? null,
    factors: factors.map((f) => ({ label: tf(lang, f.labelKey as never), contribution: f.contribution, detail: f.detail })),
    conditions: conditions ? Object.entries(conditions).map(([k, v]) => ({ key: k, value: v.value })) : [],
    agents: agents.map((a) => {
      let summary = '', source = '—', updatedAt = q.createdAt.toISOString()
      try { const o = JSON.parse(a.outputDataJson); summary = o.summary ?? ''; source = o.source ?? '—'; updatedAt = o.updatedAt ?? updatedAt } catch { /* noop */ }
      return { name: a.agentName, label: tf(lang, `agents.${a.agentName}` as never), status: a.status, confidence: a.confidence, summary, source, updatedAt }
    }),
    disclaimer: tf(lang, 'footer.disclaimer'),
  }
}

export async function GET(req: NextRequest) {
  const user = await getSessionUser(req)
  if (!user) return unauthorized()
  try {
    const reports = await db.report.findMany({
      where: { userId: user.id }, orderBy: { createdAt: 'desc' }, take: 30,
      include: { query: { include: { assessment: true } } },
    })
    return NextResponse.json({
      reports: reports.map((r) => ({
        id: r.id, title: r.title, createdAt: r.createdAt.toISOString(),
        queryId: r.queryId, question: r.query.query, location: r.query.location,
        riskLevel: r.query.assessment?.riskLevel ?? null, riskScore: r.query.assessment?.riskScore ?? null,
      })),
    })
  } catch (e) {
    console.error('reports list error', e)
    return NextResponse.json({ reports: [] }, { status: 200 })
  }
}

export async function POST(req: NextRequest) {
  const user = await getSessionUser(req)
  if (!user) return unauthorized()
  try {
    const body = await req.json().catch(() => null)
    const queryId = String(body?.queryId ?? '')
    const q = await db.userQuery.findFirst({
      where: { id: queryId, userId: user.id },
      include: { assessment: true, agentRuns: true },
    })
    if (!q) return NextResponse.json({ error: 'not found' }, { status: 404 })
    const lang = (q.language ?? 'en') as LangCode
    const content = buildReportContent(q, q.assessment, q.agentRuns, lang)
    const title = tf(lang, 'reports.reportFor', { q: q.query.slice(0, 80) })
    const report = await db.report.create({ data: { userId: user.id, queryId: q.id, title, contentJson: JSON.stringify(content) } })
    return NextResponse.json({ report: { id: report.id, title: report.title, createdAt: report.createdAt.toISOString(), content } })
  } catch (e) {
    console.error('report create error', e)
    return NextResponse.json({ error: 'server' }, { status: 500 })
  }
}
