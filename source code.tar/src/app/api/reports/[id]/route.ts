import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser, unauthorized } from '@/lib/auth'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await getSessionUser(req)
  if (!user) return unauthorized()
  const { id } = await params
  try {
    const report = await db.report.findFirst({ where: { id, userId: user.id } })
    if (!report) return NextResponse.json({ error: 'not found' }, { status: 404 })
    return NextResponse.json({
      report: { id: report.id, title: report.title, createdAt: report.createdAt.toISOString(), content: JSON.parse(report.contentJson) },
    })
  } catch (e) {
    console.error('report detail error', e)
    return NextResponse.json({ error: 'server' }, { status: 500 })
  }
}
