import { NextRequest, NextResponse } from 'next/server'
import { getSeries } from '@/lib/data/providers'

export const dynamic = 'force-dynamic'

/** Hourly observation series for ocean condition charts (last N hours). */
export async function GET(req: NextRequest) {
  try {
    const slug = req.nextUrl.searchParams.get('location') ?? 'kakinada'
    const hours = Math.min(72, Math.max(6, parseInt(req.nextUrl.searchParams.get('hours') ?? '24', 10) || 24))
    const series = await getSeries(slug, hours)
    return NextResponse.json({ ...series, location: slug })
  } catch (e) {
    console.error('series error', e)
    return NextResponse.json({ weather: [], ocean: [], location: 'unknown' }, { status: 200 })
  }
}
