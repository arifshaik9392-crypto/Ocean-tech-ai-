import { NextRequest, NextResponse } from 'next/server'
import { getAlerts, getFishingZones, getGisZones, getLocation, getLocations, getOcean, getWeather, maxSeverity } from '@/lib/data/providers'
import { assessRisk } from '@/lib/risk-engine'

export const dynamic = 'force-dynamic'

/** Accepts a slug ("kakinada") or a display name ("Kakinada"). */
async function resolveLocation(raw: string) {
  const loc = await getLocation(raw.toLowerCase())
  if (loc) return loc
  const all = await getLocations()
  return all.find((l) => l.name.toLowerCase() === raw.toLowerCase()) ?? null
}

/** Overview snapshot for the dashboard (public marine datasets, read-only). */
export async function GET(req: NextRequest) {
  try {
    const raw = req.nextUrl.searchParams.get('location') ?? 'kakinada'
    const loc = await resolveLocation(raw)
    if (!loc) return NextResponse.json({ error: 'unknown location' }, { status: 404 })
    const now = new Date()
    const [weather, ocean, alerts, zones] = await Promise.all([
      getWeather(loc.slug), getOcean(loc.slug), getAlerts(loc.slug), getFishingZones(loc.latitude, loc.longitude),
    ])
    const risk = assessRisk({
      windKmh: weather.windSpeed, waveHeightM: ocean.waveHeight,
      weatherCondition: weather.condition, stormProbability: weather.stormProbability,
      maxAlertSeverity: maxSeverity(alerts), currentSpeedMs: ocean.currentSpeed,
      gisConflicts: 0, fishingStatus: zones.some((z) => z.advisoryStatus === 'Available') ? 'available' : 'none',
    })
    return NextResponse.json({
      location: loc,
      risk: { level: risk.level, score: risk.score, confidence: risk.confidence },
      weather: { windSpeed: weather.windSpeed, windDirection: weather.windDirection, condition: weather.condition, temperature: weather.temperature, updatedAt: weather.updatedAt, source: weather.source, dataStatus: weather.dataStatus },
      ocean: { waveHeight: ocean.waveHeight, wavePeriod: ocean.wavePeriod, seaTemp: ocean.seaTemp, currentSpeed: ocean.currentSpeed, updatedAt: ocean.updatedAt, source: ocean.source, dataStatus: ocean.dataStatus },
      alertsCount: alerts.length,
      alerts: alerts.slice(0, 3),
      fishingAvailable: zones.filter((z) => z.advisoryStatus === 'Available').length,
      fishingTotal: zones.length,
      updatedAt: now.toISOString(),
    })
  } catch (e) {
    console.error('overview error', e)
    return NextResponse.json({ error: 'server' }, { status: 500 })
  }
}
