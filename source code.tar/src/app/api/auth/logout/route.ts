import { NextRequest, NextResponse } from 'next/server'
import { clearSessionCookie, destroySession } from '@/lib/auth'

export const dynamic = 'force-dynamic'

export async function POST(req: NextRequest) {
  try { await destroySession(req) } catch { /* ignore */ }
  const res = NextResponse.json({ ok: true })
  const c = clearSessionCookie()
  res.cookies.set(c.name, c.value, c)
  return res
}
