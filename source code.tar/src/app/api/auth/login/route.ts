import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { createSession, publicUser, sessionCookie, verifyPassword } from '@/lib/auth'

export const dynamic = 'force-dynamic'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => null)
    const email = String(body?.email ?? '').trim().toLowerCase()
    const password = String(body?.password ?? '')
    if (!email || !password) return NextResponse.json({ error: 'invalid' }, { status: 400 })
    const user = await db.user.findUnique({ where: { email }, include: { role: true } })
    if (!user || !verifyPassword(password, user.passwordHash)) {
      return NextResponse.json({ error: 'credentials' }, { status: 401 })
    }
    const { token, expiresAt } = await createSession(user.id)
    const res = NextResponse.json({ user: publicUser(user) })
    const c = sessionCookie(token, expiresAt)
    res.cookies.set(c.name, c.value, c)
    return res
  } catch (e) {
    console.error('login error', e)
    return NextResponse.json({ error: 'server' }, { status: 500 })
  }
}
