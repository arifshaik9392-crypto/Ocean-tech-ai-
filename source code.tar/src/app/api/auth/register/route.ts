import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { createSession, hashPassword, publicUser, sessionCookie } from '@/lib/auth'

export const dynamic = 'force-dynamic'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => null)
    const email = String(body?.email ?? '').trim().toLowerCase()
    const password = String(body?.password ?? '')
    const fullName = String(body?.fullName ?? '').trim()
    const phone = body?.phone ? String(body.phone).trim() : null
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) || password.length < 6 || fullName.length < 2) {
      return NextResponse.json({ error: 'invalid' }, { status: 400 })
    }
    const existing = await db.user.findUnique({ where: { email } })
    if (existing) return NextResponse.json({ error: 'exists' }, { status: 409 })
    const user = await db.user.create({
      data: { email, passwordHash: hashPassword(password), fullName, phone, homeLocation: 'Kakinada' },
      include: { role: true },
    })
    await db.userRole.create({ data: { userId: user.id, role: 'fisherman' } })
    const { token, expiresAt } = await createSession(user.id)
    const res = NextResponse.json({ user: publicUser(user) })
    const c = sessionCookie(token, expiresAt)
    res.cookies.set(c.name, c.value, c)
    return res
  } catch (e) {
    console.error('register error', e)
    return NextResponse.json({ error: 'server' }, { status: 500 })
  }
}
