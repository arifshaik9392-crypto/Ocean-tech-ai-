import { NextResponse } from 'next/server'
import { getLocations } from '@/lib/data/providers'

export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const locations = await getLocations()
    return NextResponse.json({ locations })
  } catch (e) {
    console.error('locations error', e)
    return NextResponse.json({ locations: [] }, { status: 200 })
  }
}
