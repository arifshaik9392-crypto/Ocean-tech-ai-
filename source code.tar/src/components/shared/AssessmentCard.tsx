'use client'
// OceanTech AI — assessment result card (used by Assistant + Voice + Risk)
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { AgentPipeline, FactorBars, RiskDial, SourceMeta, severityBadgeClass } from '@/components/shared/marine'
import { useLang } from '@/lib/i18n/context'
import type { OrchestratorResult } from '@/types/marine'
import { FileDown, Info } from 'lucide-react'
import { useState } from 'react'
import { useToast } from '@/hooks/use-toast'

export function AssessmentCard({ result, showAgents = false, onReport }: { result: OrchestratorResult; showAgents?: boolean; onReport?: (r: OrchestratorResult) => void }) {
  const { t } = useLang()
  const [generating, setGenerating] = useState(false)
  const { toast } = useToast()

  if (!result.answer && !result.followUp) return null

  async function generateReport() {
    if (!result.queryId || !onReport) return
    setGenerating(true)
    try {
      const res = await fetch('/api/reports', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ queryId: result.queryId }) })
      if (res.ok) {
        toast({ title: t('reports.generated'), description: t('nav.reports') })
        onReport(result)
      }
    } finally { setGenerating(false) }
  }

  const conditions = result.conditions ? Object.entries(result.conditions) : []

  return (
    <Card className="ot-fade-up overflow-hidden">
      {result.risk && (
        <div className="flex flex-col items-center gap-4 border-b bg-gradient-to-b from-primary/8 to-transparent px-6 py-6 sm:flex-row sm:gap-8">
          <RiskDial level={result.risk.level} score={result.risk.score} />
          <div className="min-w-0 flex-1 text-center sm:text-left">
            <div className="flex flex-wrap items-center justify-center gap-2 sm:justify-start">
              <h2 className={`text-2xl font-extrabold tracking-tight ${result.risk.level === 'SAFE' ? 'risk-safe' : result.risk.level === 'MODERATE' ? 'risk-moderate' : 'risk-high'}`}>
                {t(`risk.${result.risk.level.toLowerCase()}` as never)}
              </h2>
            </div>
            <p className="mt-1.5 text-[15px] font-medium leading-snug">{result.answer?.oneLiner}</p>
            <p className="mt-1 text-xs text-muted-foreground">
              {t('assistant.confidence')}: {Math.round(result.risk.confidence * 100)}%
              {result.locationName ? ` · ${result.locationName}` : ''}
              {result.requestedWhen ? ` · ${result.requestedWhen}` : ''}
            </p>
          </div>
        </div>
      )}

      {result.followUp && (
        <div className="flex items-start gap-3 bg-accent/50 px-5 py-4">
          <Info className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
          <p className="text-[15px] font-medium">{result.followUp}</p>
        </div>
      )}

      <CardContent className="space-y-5 p-5">
        {result.answer?.explanation && (
          <div>
            <h3 className="mb-1.5 text-sm font-bold uppercase tracking-wide text-muted-foreground">{t('assistant.whyTitle')}</h3>
            <p className="text-[15px] leading-relaxed">{result.answer.explanation}</p>
          </div>
        )}

        {conditions.length > 0 && (
          <div>
            <h3 className="mb-2 text-sm font-bold uppercase tracking-wide text-muted-foreground">{t('assistant.conditions')}</h3>
            <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
              {conditions.map(([k, v]) => (
                <div key={k} className="rounded-xl border bg-card p-3">
                  <p className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">{t(`cond.${k}` as never)}</p>
                  <p className="mt-0.5 truncate text-[15px] font-semibold" title={v.value}>{v.value}</p>
                  {v.detail && <p className="truncate text-[11px] text-muted-foreground">{v.detail}</p>}
                </div>
              ))}
            </div>
          </div>
        )}

        {result.risk && (
          <div>
            <h3 className="mb-2 text-sm font-bold uppercase tracking-wide text-muted-foreground">{t('assistant.factors')}</h3>
            <FactorBars factors={result.risk.factors} />
          </div>
        )}

        {result.answer?.recommendation && (
          <div className="rounded-xl border border-primary/25 bg-primary/6 p-4">
            <h3 className="mb-1 text-sm font-bold uppercase tracking-wide text-primary">{t('assistant.recommendation')}</h3>
            <p className="text-[14.5px] leading-relaxed">{result.answer.recommendation}</p>
          </div>
        )}

        {showAgents && result.agents.length > 0 && (
          <div>
            <h3 className="mb-2 text-sm font-bold uppercase tracking-wide text-muted-foreground">{t('assistant.agents')}</h3>
            <AgentPipeline agents={result.agents} done />
            <Separator className="my-3" />
            <div className="space-y-2">
              {result.agents.map((a) => (
                <div key={a.name} className="rounded-lg border p-2.5">
                  <p className="text-[13px] font-semibold">{t(a.labelKey as never)}</p>
                  <p className="text-xs text-muted-foreground">{a.summary}</p>
                  <div className="mt-1"><SourceMeta source={a.source} dataStatus={a.dataStatus} updatedAt={a.updatedAt} confidence={a.confidence} /></div>
                </div>
              ))}
            </div>
          </div>
        )}

        {result.dataFreshness.length > 0 && (
          <div>
            <h3 className="mb-1.5 text-sm font-bold uppercase tracking-wide text-muted-foreground">{t('assistant.freshness')}</h3>
            <div className="grid grid-cols-2 gap-2 text-xs sm:grid-cols-4">
              {result.dataFreshness.map((f) => (
                <div key={f.agent} className="rounded-lg bg-muted/60 px-2.5 py-2">
                  <p className="font-semibold capitalize">{t(`agents.${f.agent}` as never)}</p>
                  <p className="text-muted-foreground">{f.minutesAgo < 1 ? t('common.now') : t('common.minAgo', { n: f.minutesAgo })}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {result.alerts.length > 0 && (
          <div>
            <h3 className="mb-2 text-sm font-bold uppercase tracking-wide text-muted-foreground">{t('nav.alerts')}</h3>
            <div className="space-y-2">
              {result.alerts.slice(0, 3).map((a) => (
                <div key={a.id} className="flex items-start gap-2.5 rounded-lg border p-2.5">
                  <span className={`mt-0.5 rounded border px-1.5 py-0.5 text-[10px] font-bold ${severityBadgeClass(a.severity)}`}>{t(`sev.${a.severity}` as never)}</span>
                  <p className="text-[13px] leading-snug">{a.title}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="rounded-xl bg-muted/60 p-3">
          <p className="text-[11.5px] leading-relaxed text-muted-foreground">{t('assistant.limitationsText')} {t('risk.emergency')}</p>
        </div>

        {result.queryId && result.type === 'assessment' && onReport && (
          <Button variant="outline" className="w-full gap-2 sm:w-auto" onClick={generateReport} disabled={generating}>
            <FileDown className="h-4 w-4" />
            {generating ? t('common.loading') : t('reports.generate')}
          </Button>
        )}
      </CardContent>
    </Card>
  )
}
