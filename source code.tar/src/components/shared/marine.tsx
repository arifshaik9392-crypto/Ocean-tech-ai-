'use client'
// OceanTech AI — shared marine UI atoms
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { useLang } from '@/lib/i18n/context'
import type { RiskFactor, RiskLevel } from '@/types/marine'
import { cn } from '@/lib/utils'
import { CheckCircle2, Clock, Database, Loader2 } from 'lucide-react'
import type { AgentRunInfo } from '@/types/marine'

const LEVEL_CLASS: Record<RiskLevel, string> = {
  SAFE: 'risk-safe', MODERATE: 'risk-moderate', HIGH: 'risk-high',
}
const LEVEL_BADGE: Record<RiskLevel, string> = {
  SAFE: 'bg-risk-safe/15 text-[color:var(--ot-safe)] border-risk-safe/40',
  MODERATE: 'bg-risk-moderate/15 text-[color:var(--ot-moderate)] border-risk-moderate/40',
  HIGH: 'bg-risk-high/15 text-[color:var(--ot-high)] border-risk-high/40',
}

export function riskColorClass(level: RiskLevel | string | null | undefined) {
  switch (level) {
    case 'SAFE': return LEVEL_CLASS.SAFE
    case 'MODERATE': return LEVEL_CLASS.MODERATE
    case 'HIGH': return LEVEL_CLASS.HIGH
    default: return ''
  }
}

export function RiskBadge({ level, className }: { level: RiskLevel | string | null | undefined; className?: string }) {
  const { t } = useLang()
  if (!level) return null
  return (
    <Badge variant="outline" className={cn('font-bold tracking-wide', LEVEL_BADGE[level as RiskLevel], className)}>
      {t(`risk.${level.toLowerCase()}` as never)}
    </Badge>
  )
}

export function RiskDial({ level, score, size = 128 }: { level: RiskLevel; score: number; size?: number }) {
  const { t } = useLang()
  const pct = Math.max(0, Math.min(100, score))
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg viewBox="0 0 120 120" className="h-full w-full -rotate-90" aria-hidden>
        <circle cx="60" cy="60" r="52" fill="none" stroke="currentColor" className="text-border" strokeWidth="11" />
        <circle
          cx="60" cy="60" r="52" fill="none" strokeWidth="11" strokeLinecap="round"
          strokeDasharray={`${(pct / 100) * 2 * Math.PI * 52} ${2 * Math.PI * 52}`}
          className={cn('transition-all duration-700', LEVEL_CLASS[level])}
          stroke="currentColor"
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className={cn('text-3xl font-extrabold leading-none', LEVEL_CLASS[level])}>{score}</span>
        <span className="mt-0.5 text-[11px] font-medium text-muted-foreground">{t('risk.outOf100')}</span>
      </div>
    </div>
  )
}

export function FactorBars({ factors }: { factors: RiskFactor[] }) {
  const { t } = useLang()
  return (
    <div className="space-y-2.5">
      {factors.map((f) => (
        <div key={f.key}>
          <div className="mb-1 flex items-baseline justify-between gap-2 text-[13px]">
            <span className="font-medium">{t(f.labelKey as never)}</span>
            <span className="shrink-0 tabular-nums text-muted-foreground">
              {f.detail} · <span className="font-semibold text-foreground">+{f.contribution}</span>
              <span className="ml-1 text-[11px]">({f.weight}%)</span>
            </span>
          </div>
          <Progress value={f.contribution * 2.2} className="h-1.5" />
        </div>
      ))}
    </div>
  )
}

export function AgentPipeline({ agents, done }: { agents: AgentRunInfo[]; done: boolean }) {
  const { t } = useLang()
  const steps: { key: string; label: string }[] = [
    { key: 'understanding', label: t('assistant.understanding') },
    ...agents.map((a) => ({ key: a.name, label: t(a.labelKey as never) })),
    { key: 'risk', label: t('assistant.riskEngine') },
    { key: 'explain', label: t('assistant.generating') },
  ]
  return (
    <ul className="space-y-1.5 text-sm" aria-live="polite">
      {steps.map((s, i) => {
        const complete = done || i < steps.length - 1
        return (
          <li key={s.key} className="flex items-center gap-2.5 ot-fade-up" style={{ animationDelay: `${i * 90}ms` }}>
            {complete ? (
              <CheckCircle2 className="h-4 w-4 shrink-0 text-[color:var(--ot-safe)]" />
            ) : (
              <Loader2 className="h-4 w-4 shrink-0 animate-spin text-primary" />
            )}
            <span className={cn(complete ? 'text-foreground' : 'text-muted-foreground')}>{s.label}</span>
          </li>
        )
      })}
    </ul>
  )
}

export function SourceMeta({ source, dataStatus, updatedAt, confidence }: { source: string; dataStatus: 'SAMPLE' | 'LIVE'; updatedAt: string; confidence?: number }) {
  const { t } = useLang()
  const ago = Math.max(0, Math.round((Date.now() - new Date(updatedAt).getTime()) / 60000))
  return (
    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
      <span className="inline-flex items-center gap-1"><Database className="h-3 w-3" /> {source}</span>
      <span className="inline-flex items-center gap-1"><Clock className="h-3 w-3" /> {t('common.updated')} {ago < 1 ? t('common.now') : t('common.minAgo', { n: ago })}</span>
      {confidence != null && <span>{t('common.confidence')} {Math.round(confidence * 100)}%</span>}
      <span className={cn('rounded px-1.5 py-0.5 font-semibold tracking-wide', dataStatus === 'SAMPLE' ? 'bg-amber-500/12 text-amber-700 dark:text-amber-400' : 'bg-emerald-500/12 text-emerald-700 dark:text-emerald-400')}>
        {dataStatus === 'SAMPLE' ? t('common.sampleData') : t('common.liveData')}
      </span>
    </div>
  )
}

export function severityBadgeClass(sev: string) {
  switch (sev) {
    case 'Severe': return 'bg-risk-high/15 text-[color:var(--ot-high)] border-risk-high/40'
    case 'Warning': return 'bg-orange-500/12 text-orange-700 dark:text-orange-400 border-orange-500/40'
    case 'Advisory': return 'bg-amber-500/12 text-amber-700 dark:text-amber-400 border-amber-500/40'
    default: return 'bg-sky-500/10 text-sky-700 dark:text-sky-400 border-sky-500/30'
  }
}

export function suitabilityBadgeClass(s: string) {
  switch (s) {
    case 'High': return 'bg-risk-safe/15 text-[color:var(--ot-safe)] border-risk-safe/40'
    case 'Medium': return 'bg-amber-500/12 text-amber-700 dark:text-amber-400 border-amber-500/40'
    default: return 'bg-risk-high/15 text-[color:var(--ot-high)] border-risk-high/40'
  }
}

export function ViewHeader({ title, subtitle, children }: { title: string; subtitle?: string; children?: React.ReactNode }) {
  return (
    <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-xl font-bold tracking-tight sm:text-2xl">{title}</h1>
        {subtitle && <p className="mt-0.5 text-sm text-muted-foreground">{subtitle}</p>}
      </div>
      {children}
    </div>
  )
}
