'use client'
// OceanTech AI — Marine intelligence reports (list + print-friendly document + download)
import { useCallback, useEffect, useState } from 'react'
import { Download, FileText, Printer } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'
import { RiskBadge } from '@/components/shared/marine'
import { useLang } from '@/lib/i18n/context'
import { useApp } from '@/lib/store'
import { useToast } from '@/hooks/use-toast'
import type { RiskLevel } from '@/types/marine'
import { cn } from '@/lib/utils'

interface ReportListItem {
  id: string
  title: string
  createdAt: string
  question: string | null
  location: string | null
  riskLevel: string | null
  riskScore: number | null
}

interface ReportContent {
  question: string
  location: string | null
  datetime: string | null
  assessedAt?: string
  risk: { level: string; score: number; confidence: number } | null
  oneLiner: string | null
  explanation: string | null
  recommendation: string | null
  factors: { label: string; contribution: number; detail: string }[]
  conditions: { key: string; value: string }[]
  agents: { name?: string; label: string; status: string; confidence: number | null; summary: string; source: string; updatedAt: string }[]
  disclaimer: string
}

interface ReportDetail {
  id: string
  title: string
  createdAt: string
  content: ReportContent
}

function esc(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
}

export function ReportsView() {
  const { t } = useLang()
  const { setView } = useApp()
  const { toast } = useToast()

  const [reports, setReports] = useState<ReportListItem[]>([])
  const [listLoading, setListLoading] = useState(true)
  const [listError, setListError] = useState(false)
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [detail, setDetail] = useState<ReportDetail | null>(null)
  const [detailLoading, setDetailLoading] = useState(false)

  const loadList = useCallback(async () => {
    setListLoading(true)
    setListError(false)
    try {
      const res = await fetch('/api/reports')
      if (res.status === 401) { window.location.reload(); return }
      if (!res.ok) throw new Error('failed')
      const d = await res.json()
      setReports(d.reports ?? [])
    } catch {
      setListError(true)
    } finally {
      setListLoading(false)
    }
  }, [])

  useEffect(() => { loadList() }, [loadList])

  // auto-select the most recent report once the list arrives
  useEffect(() => {
    if (!selectedId && reports.length > 0) openReport(reports[0].id)
  }, [reports])

  const openReport = useCallback(async (id: string) => {
    setSelectedId(id)
    setDetailLoading(true)
    setDetail(null)
    try {
      const res = await fetch(`/api/reports/${id}`)
      if (res.status === 401) { window.location.reload(); return }
      if (!res.ok) throw new Error('failed')
      const d = await res.json()
      setDetail(d.report ?? null)
    } catch {
      toast({ title: t('common.error'), description: t('common.unavailable') })
      setSelectedId(null)
    } finally {
      setDetailLoading(false)
    }
  }, [t, toast])

  function downloadReport() {
    if (!detail) return
    const c = detail.content
    const agentRows = (c.agents ?? []).map((a) =>
      `<tr><td>${esc(a.label)}</td><td>${esc(a.status)}</td><td>${a.confidence != null ? `${Math.round(a.confidence * 100)}%` : '—'}</td><td>${esc(a.summary)}</td><td>${esc(new Date(a.updatedAt).toLocaleString())}</td></tr>`,
    ).join('')
    const condCells = (c.conditions ?? []).map((k) =>
      `<div class="cond"><span>${esc(t(`cond.${k.key}` as never))}</span><strong>${esc(k.value)}</strong></div>`,
    ).join('')
    const html = `<!doctype html><html><head><meta charset="utf-8"><title>${esc(detail.title)}</title>
<style>
  body{font-family:ui-sans-serif,system-ui,-apple-system,'Segoe UI',sans-serif;margin:40px auto;max-width:800px;color:#111;line-height:1.55}
  .brand{letter-spacing:.25em;font-size:11px;font-weight:700;color:#0f766e;text-transform:uppercase}
  h1{font-size:20px;margin:6px 0 2px} h2{font-size:13px;text-transform:uppercase;letter-spacing:.08em;color:#555;margin:26px 0 8px;border-bottom:1px solid #ddd;padding-bottom:4px}
  .meta{color:#555;font-size:13px} .pill{display:inline-block;border:1px solid #ddd;border-radius:999px;padding:2px 10px;font-size:12px;font-weight:700}
  table{width:100%;border-collapse:collapse;font-size:13px} td,th{border:1px solid #ddd;padding:6px 8px;text-align:left;vertical-align:top} th{background:#f5f5f5}
  .cond{display:inline-block;border:1px solid #ddd;border-radius:10px;padding:6px 10px;margin:0 8px 8px 0;font-size:13px} .cond span{display:block;color:#666;font-size:11px;text-transform:uppercase}
  footer{margin-top:30px;padding-top:10px;border-top:1px solid #ddd;color:#666;font-size:12px}
</style></head><body>
<div class="brand">OCEANTECH AI</div>
<h1>${esc(detail.title)}</h1>
<p class="meta">${esc(c.location ?? '—')} · ${esc(c.datetime ?? detail.createdAt)}</p>
<h2>${esc(t('reports.question'))}</h2><p>${esc(c.question)}</p>
<h2>${esc(t('reports.riskLevel'))}</h2>
<p>${c.risk ? `<span class="pill">${esc(c.risk.level)} — ${esc(t('risk.score'))}: ${c.risk.score} / 100</span>` : '—'}</p>
${c.oneLiner ? `<h2>${esc(t('reports.explanation'))}</h2><p><strong>${esc(c.oneLiner)}</strong></p>${c.explanation ? `<p>${esc(c.explanation)}</p>` : ''}${c.recommendation ? `<p><strong>${esc(t('assistant.recommendation'))}:</strong> ${esc(c.recommendation)}</p>` : ''}` : ''}
<h2>${esc(t('reports.agentFindings'))}</h2>
<table><thead><tr><th>${esc(t('common.source'))}</th><th>Status</th><th>${esc(t('common.confidence'))}</th><th>Summary</th><th>${esc(t('common.updated'))}</th></tr></thead><tbody>${agentRows}</tbody></table>
<h2>${esc(t('nav.overview'))}</h2><div>${condCells}</div>
<footer>${esc(c.disclaimer)}</footer>
</body></html>`
    try {
      const blob = new Blob([html], { type: 'text/html;charset=utf-8' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `oceantech-report-${detail.id}.html`
      document.body.appendChild(a)
      a.click()
      a.remove()
      setTimeout(() => URL.revokeObjectURL(url), 2000)
    } catch {
      toast({ title: t('common.error'), description: t('common.unavailable') })
    }
  }

  const c = detail?.content

  return (
    <div className="space-y-4">
      {/* Print scoping: only the report document is printed */}
      <style>{`@media print { .no-print { display: none !important } body * { visibility: hidden } .print-area, .print-area * { visibility: visible } .print-area { position: absolute; inset-inline: 0; top: 0; margin: 0 auto; max-width: 800px; box-shadow: none !important; border: none !important } }`}</style>

      <div className="no-print">
        <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
          <div>
            <h1 className="text-xl font-bold tracking-tight sm:text-2xl">{t('reports.title')}</h1>
            <p className="mt-0.5 text-sm text-muted-foreground">{t('reports.subtitle')}</p>
          </div>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-[340px_1fr]">
        {/* Left: report list */}
        <div className="no-print min-w-0">
          <Card>
            <CardContent className="p-3">
              {listLoading ? (
                <div className="space-y-2 p-1">
                  {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-20 w-full rounded-lg" />)}
                </div>
              ) : listError ? (
                <div className="flex flex-col items-start gap-3 p-2">
                  <p className="text-sm text-muted-foreground">{t('common.unavailable')}</p>
                  <Button variant="outline" size="sm" onClick={loadList}>{t('common.retry')}</Button>
                </div>
              ) : (reports ?? []).length === 0 ? (
                <div className="flex flex-col items-center gap-2 px-4 py-10 text-center">
                  <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-primary/10 text-primary">
                    <FileText className="h-5 w-5" aria-hidden />
                  </div>
                  <p className="text-sm font-semibold">{t('reports.empty')}</p>
                  <p className="text-xs leading-relaxed text-muted-foreground">{t('reports.emptyDesc')}</p>
                  <Button variant="outline" size="sm" className="mt-2" onClick={() => setView('assistant')}>
                    {t('nav.assistant')}
                  </Button>
                </div>
              ) : (
                <div className="ot-scroll max-h-[70vh] space-y-2 overflow-y-auto p-1">
                  {(reports ?? []).map((r) => (
                    <div
                      key={r.id}
                      className={cn(
                        'rounded-lg border p-3 transition-colors',
                        selectedId === r.id ? 'border-primary/50 bg-primary/5' : 'hover:border-primary/40',
                      )}
                    >
                      <p className="line-clamp-2 text-[13px] font-semibold leading-snug">{r.title}</p>
                      <div className="mt-1.5 flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground">
                        <span className="truncate">{r.location ?? '—'}</span>
                        <span>·</span>
                        <span>{new Date(r.createdAt).toLocaleDateString()}</span>
                        {r.riskLevel && <RiskBadge level={r.riskLevel as RiskLevel} className="px-1.5 py-0 text-[10px]" />}
                      </div>
                      <Button
                        variant="outline" size="sm"
                        className="mt-2.5 h-8 gap-1.5 text-xs"
                        onClick={() => openReport(r.id)}
                      >
                        <FileText className="h-3.5 w-3.5" aria-hidden /> {t('reports.view')}
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Right: report document */}
        <div className="min-w-0">
          {detailLoading ? (
            <Card>
              <CardContent className="space-y-3 p-6">
                <Skeleton className="h-4 w-28" />
                <Skeleton className="h-7 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-32 w-full rounded-xl" />
                <Skeleton className="h-32 w-full rounded-xl" />
              </CardContent>
            </Card>
          ) : detail && c ? (
            <Card className="print-area">
              <CardContent className="p-5 sm:p-7">
                {/* Document header */}
                <div className="border-b pb-4">
                  <p className="text-[11px] font-bold uppercase tracking-[0.25em] text-primary">OCEANTECH AI</p>
                  <h2 className="mt-1.5 text-lg font-extrabold leading-snug tracking-tight sm:text-xl">{detail.title}</h2>
                  <p className="mt-1 text-xs text-muted-foreground">{new Date(detail.createdAt).toLocaleString()}</p>
                </div>

                <div className="no-print mt-4 flex flex-wrap gap-2">
                  <Button variant="outline" size="sm" className="gap-2" onClick={() => window.print()}>
                    <Printer className="h-4 w-4" aria-hidden /> {t('reports.print')}
                  </Button>
                  <Button variant="outline" size="sm" className="gap-2" onClick={downloadReport}>
                    <Download className="h-4 w-4" aria-hidden /> {t('reports.download')}
                  </Button>
                </div>

                <div className="mt-5 space-y-5">
                  {/* Question */}
                  <section>
                    <h3 className="mb-1 text-xs font-bold uppercase tracking-wide text-muted-foreground">{t('reports.question')}</h3>
                    <p className="text-[15px] font-medium leading-relaxed">{c.question ?? t('common.notAvailable')}</p>
                  </section>

                  {/* Meta: location + datetime */}
                  <div className="grid gap-3 sm:grid-cols-2">
                    <section>
                      <h3 className="mb-1 text-xs font-bold uppercase tracking-wide text-muted-foreground">{t('reports.locationLabel')}</h3>
                      <p className="text-sm font-semibold">{c.location ?? t('common.notAvailable')}</p>
                    </section>
                    <section>
                      <h3 className="mb-1 text-xs font-bold uppercase tracking-wide text-muted-foreground">{t('reports.datetime')}</h3>
                      <p className="text-sm font-semibold">{c.datetime ?? detail.createdAt}</p>
                    </section>
                  </div>

                  {/* Risk level */}
                  <section>
                    <h3 className="mb-1.5 text-xs font-bold uppercase tracking-wide text-muted-foreground">{t('reports.riskLevel')}</h3>
                    {c.risk ? (
                      <div className="flex flex-wrap items-center gap-2.5">
                        <RiskBadge level={c.risk.level} />
                        <span className="text-sm font-bold tabular-nums">{c.risk.score} <span className="font-medium text-muted-foreground">{t('risk.outOf100')}</span></span>
                        <span className="text-xs text-muted-foreground">{t('risk.score')}: {c.risk.score}</span>
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground">{t('common.notAvailable')}</p>
                    )}
                  </section>

                  {/* Agent findings */}
                  {(c.agents ?? []).length > 0 && (
                    <section>
                      <h3 className="mb-2 text-xs font-bold uppercase tracking-wide text-muted-foreground">{t('reports.agentFindings')}</h3>
                      <div className="space-y-2">
                        {(c.agents ?? []).map((a, i) => (
                          <div key={`${a.name ?? 'agent'}-${i}`} className="rounded-lg border p-3">
                            <div className="flex flex-wrap items-center justify-between gap-2">
                              <p className="text-[13px] font-bold">{a.label}</p>
                              <div className="flex items-center gap-2">
                                <span className={cn('rounded border px-1.5 py-0.5 text-[10px] font-bold uppercase',
                                  a.status === 'failed' ? 'border-risk-high/40 bg-risk-high/10 text-[color:var(--ot-high)]' : 'border-risk-safe/40 bg-risk-safe/10 text-[color:var(--ot-safe)]')}>
                                  {a.status}
                                </span>
                                {a.confidence != null && <span className="text-[11px] tabular-nums text-muted-foreground">{Math.round(a.confidence * 100)}%</span>}
                              </div>
                            </div>
                            {a.summary && <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{a.summary}</p>}
                            <p className="mt-1 text-[10.5px] text-muted-foreground">{new Date(a.updatedAt).toLocaleString()}</p>
                          </div>
                        ))}
                      </div>
                    </section>
                  )}

                  {/* Explanation */}
                  {c.explanation && (
                    <section>
                      <h3 className="mb-1 text-xs font-bold uppercase tracking-wide text-muted-foreground">{t('reports.explanation')}</h3>
                      {c.oneLiner && <p className="mb-1.5 text-[15px] font-semibold leading-relaxed">{c.oneLiner}</p>}
                      <p className="text-sm leading-relaxed">{c.explanation}</p>
                      {c.recommendation && (
                        <p className="mt-2 rounded-lg border border-primary/25 bg-primary/6 p-3 text-sm font-medium leading-relaxed">{c.recommendation}</p>
                      )}
                    </section>
                  )}

                  {/* Conditions grid */}
                  {(c.conditions ?? []).length > 0 && (
                    <section>
                      <h3 className="mb-2 text-xs font-bold uppercase tracking-wide text-muted-foreground">{t('nav.overview')}</h3>
                      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                        {(c.conditions ?? []).map((k, i) => (
                          <div key={`${k.key}-${i}`} className="rounded-lg border bg-card p-2.5">
                            <p className="text-[10.5px] font-semibold uppercase tracking-wide text-muted-foreground">{t(`cond.${k.key}` as never)}</p>
                            <p className="mt-0.5 truncate text-sm font-semibold" title={k.value}>{k.value}</p>
                          </div>
                        ))}
                      </div>
                    </section>
                  )}

                  {/* Confidence */}
                  {c.risk && (
                    <section>
                      <h3 className="mb-1 text-xs font-bold uppercase tracking-wide text-muted-foreground">{t('reports.confidenceLabel')}</h3>
                      <p className="text-sm font-semibold tabular-nums">{Math.round(c.risk.confidence * 100)}%</p>
                    </section>
                  )}

                  <Separator />

                  {/* Data timestamps */}
                  {(c.agents ?? []).length > 0 && (
                    <section>
                      <h3 className="mb-2 text-xs font-bold uppercase tracking-wide text-muted-foreground">{t('reports.dataTimestamps')}</h3>
                      <ul className="space-y-1">
                        {(c.agents ?? []).map((a, i) => (
                          <li key={`ts-${a.name ?? i}`} className="flex flex-wrap items-baseline justify-between gap-2 text-xs">
                            <span className="font-medium">{a.label}</span>
                            <span className="tabular-nums text-muted-foreground">{new Date(a.updatedAt).toLocaleString()}</span>
                          </li>
                        ))}
                      </ul>
                    </section>
                  )}

                  {/* Disclaimer */}
                  <section className="rounded-lg bg-muted/60 p-3">
                    <h3 className="mb-1 text-xs font-bold uppercase tracking-wide text-muted-foreground">{t('reports.disclaimerLabel')}</h3>
                    <p className="text-[11.5px] leading-relaxed text-muted-foreground">{c.disclaimer ?? ''}</p>
                  </section>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card className="flex h-full items-center justify-center">
              <CardContent className="flex flex-col items-center gap-2 px-6 py-14 text-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10 text-primary">
                  <FileText className="h-6 w-6" aria-hidden />
                </div>
                <p className="text-sm font-semibold">{(reports ?? []).length === 0 && !listError ? t('reports.empty') : t('reports.view')}</p>
                <p className="max-w-xs text-xs leading-relaxed text-muted-foreground">{(reports ?? []).length === 0 && !listError ? t('reports.emptyDesc') : t('reports.subtitle')}</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
