'use client'
// OceanTech AI — Voice Assistance (TOP PRIORITY channel; same backend as the web assistant)
// Guided speech flow: location → time → agent workflow → spoken summary + SMS + details.
import { useCallback, useEffect, useRef, useState } from 'react'
import { Mic, PhoneOff, Send, Sparkles, Square, Volume2, MessageSquareText, Copy, RotateCcw, Keyboard } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { ViewHeader } from '@/components/shared/marine'
import { AssessmentCard } from '@/components/shared/AssessmentCard'
import { useLang } from '@/lib/i18n/context'
import { useApp } from '@/lib/store'
import { useToast } from '@/hooks/use-toast'
import type { OrchestratorResult } from '@/types/marine'
import { cn } from '@/lib/utils'

type SpeechRecognitionLike = {
  lang: string
  interimResults: boolean
  continuous: boolean
  onresult: ((e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null
  onerror: ((e: unknown) => void) | null
  onend: (() => void) | null
  start: () => void
  stop: () => void
}

type VoiceStep = 'idle' | 'listening' | 'heard' | 'processing' | 'result'

export function VoiceView() {
  const { t, lang, speechLang } = useLang()
  const { setSharedResult, setView } = useApp()
  const { toast } = useToast()

  const [step, setStep] = useState<VoiceStep>('idle')
  const [transcript, setTranscript] = useState('')
  const [question, setQuestion] = useState<string | null>(null)
  const [result, setResult] = useState<OrchestratorResult | null>(null)
  const [textInput, setTextInput] = useState('')
  const [micSupported, setMicSupported] = useState(true)
  const [speaking, setSpeaking] = useState(false)
  const recogRef = useRef<SpeechRecognitionLike | null>(null)
  const pendingField = useRef<'location' | 'time' | null>(null)
  const prevActivity = useRef<string | undefined>(undefined)

  useEffect(() => {
    const w = window as unknown as { SpeechRecognition?: new () => SpeechRecognitionLike; webkitSpeechRecognition?: new () => SpeechRecognitionLike }
    setMicSupported(Boolean(w.SpeechRecognition || w.webkitSpeechRecognition))
    return () => { try { recogRef.current?.stop(); window.speechSynthesis?.cancel() } catch { /* noop */ } }
  }, [])

  const speak = useCallback((text: string, onDone?: () => void) => {
    try {
      const synth = window.speechSynthesis
      if (!synth) { onDone?.(); return }
      synth.cancel()
      const utter = new SpeechSynthesisUtterance(text)
      utter.lang = speechLang
      utter.rate = 0.96
      const voices = synth.getVoices()
      const match = voices.find((v) => v.lang === speechLang) ?? voices.find((v) => v.lang?.startsWith(speechLang.split('-')[0]))
      if (match) utter.voice = match
      utter.onstart = () => setSpeaking(true)
      utter.onend = () => { setSpeaking(false); onDone?.() }
      utter.onerror = () => { setSpeaking(false); onDone?.() }
      synth.speak(utter)
    } catch { onDone?.() }
  }, [speechLang])

  const submitQuery = useCallback(async (q: string, context?: { pendingField: 'location' | 'time' | null; previousActivity?: string }) => {
    setStep('processing')
    setQuestion(q)
    try {
      const res = await fetch('/api/orca/query', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: q, language: lang, context: context ?? { pendingField: pendingField.current, previousActivity: prevActivity.current } }),
      })
      if (res.status === 401) { window.location.reload(); return }
      if (!res.ok) throw new Error('failed')
      const data: OrchestratorResult = await res.json()
      if (data.type === 'follow_up') {
        pendingField.current = data.parsed?.location ? 'time' : 'location'
        prevActivity.current = data.parsed?.activity ?? 'fishing'
        setQuestion(data.followUp ?? '')
        setStep('heard')
        speak(data.followUp ?? '', () => startListening())
        return
      }
      pendingField.current = null
      setResult(data)
      setStep('result')
      if (data.answer?.oneLiner) speak(data.answer.oneLiner)
    } catch {
      toast({ title: t('common.error'), description: t('common.unavailable') })
      setStep('heard')
    }  }, [lang, speak, toast, t])

  const startListening = useCallback(() => {
    const w = window as unknown as { SpeechRecognition?: new () => SpeechRecognitionLike; webkitSpeechRecognition?: new () => SpeechRecognitionLike }
    const Ctor = w.SpeechRecognition ?? w.webkitSpeechRecognition
    if (!Ctor) { setMicSupported(false); return }
    try {
      const recog = new Ctor()
      recog.lang = speechLang
      recog.interimResults = false
      recog.continuous = false
      recog.onresult = (e) => {
        const text = e.results?.[0]?.[0]?.transcript ?? ''
        if (!text) return
        setTranscript(text)
        setStep('heard')
        // auto-submit after capture
        setTimeout(() => submitQuery(text), 400)
      }
      recog.onerror = () => { setStep('idle'); setMicSupported(false) }
      recog.onend = () => { /* handled by result/error */ }
      recogRef.current = recog
      setTranscript('')
      setResult(null)
      setStep('listening')
      recog.start()
    } catch {
      setMicSupported(false)
      setStep('idle')
    }
  }, [speechLang, submitQuery])

  function stopListening() {
    try { recogRef.current?.stop() } catch { /* noop */ }
    setStep('idle')
  }

  function reset() {
    try { recogRef.current?.stop() } catch { /* noop */ }
    pendingField.current = null
    prevActivity.current = undefined
    setTranscript(''); setQuestion(null); setResult(null); setTextInput('')
    setStep('idle')
  }

  function openDetails() {
    if (!result) return
    setSharedResult(result)
    setView('assistant')
  }

  function smsHref(): string {
    if (!result) return 'sms:'
    const body = t('voice.smsBody', {
      location: result.locationName ?? '—',
      when: result.requestedWhen ?? '',
      level: result.risk?.level ?? '—',
      score: String(result.risk?.score ?? ''),
      advice: result.answer?.recommendation?.slice(0, 140) ?? '',
    })
    return `sms:?&body=${encodeURIComponent(body)}`
  }

  const prompt = question ?? (step === 'idle' ? null : t('voice.askLocation'))
  const listenPrompt = pendingField.current === 'time' ? t('voice.askTime') : t('voice.askLocation')

  return (
    <div className="mx-auto max-w-3xl">
      <ViewHeader title={t('voice.title')} subtitle={t('voice.subtitle')} />

      <Card className="overflow-hidden">
        {/* Stage area */}
        <div className="relative flex flex-col items-center gap-5 border-b bg-gradient-to-b from-primary/10 via-primary/4 to-transparent px-5 py-8 sm:py-10">
          {step === 'idle' && (
            <>
              <button
                onClick={startListening}
                aria-label={t('voice.start')}
                className="flex h-28 w-28 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-xl shadow-primary/30 transition-transform hover:scale-105 focus-visible:ring-4 focus-visible:ring-ring ot-pulse"
              >
                <Mic className="h-11 w-11" aria-hidden />
              </button>
              <p className="text-[15px] font-semibold">{t('voice.start')}</p>
              <p className="max-w-sm text-center text-sm text-muted-foreground">{t('voice.subtitle')}</p>
              {!micSupported && (
                <p className="max-w-md rounded-lg bg-amber-500/10 px-3 py-2 text-center text-xs font-medium text-amber-700 dark:text-amber-400">{t('voice.micUnavailable')}</p>
              )}
            </>
          )}

          {step === 'listening' && (
            <>
              <button
                onClick={stopListening}
                aria-label={t('voice.stop')}
                className="flex h-28 w-28 items-center justify-center rounded-full bg-destructive text-white shadow-xl transition-transform hover:scale-105 focus-visible:ring-4 focus-visible:ring-ring ot-pulse"
              >
                <Square className="h-9 w-9" aria-hidden />
              </button>
              <p className="flex items-center gap-2 text-[15px] font-semibold" aria-live="polite">
                <span className="inline-flex h-2.5 w-2.5 animate-ping rounded-full bg-destructive" />
                {t('voice.listening')} {listenPrompt}
              </p>
            </>
          )}

          {step === 'heard' && (
            <div className="w-full max-w-md space-y-3 text-center ot-fade-up">
              <Badge variant="outline" className="bg-primary/10 text-primary">{t('voice.heard', { text: transcript || '…' })}</Badge>
              {prompt && <p className="text-lg font-semibold leading-snug">{prompt}</p>}
              {speaking && <p className="text-xs text-muted-foreground">{t('voice.talking')}</p>}
              <form
                className="flex items-center gap-2"
                onSubmit={(e) => { e.preventDefault(); if (textInput.trim()) { const q = textInput.trim(); setTextInput(''); submitQuery(q) } }}
              >
                <Input value={textInput} onChange={(e) => setTextInput(e.target.value)} placeholder={t('voice.typeInstead')} className="h-12 rounded-xl" aria-label={t('voice.typeInstead')} />
                <Button type="submit" size="icon" className="h-12 w-12 rounded-xl" disabled={!textInput.trim()} aria-label={t('voice.submitText')}>
                  <Send className="h-5 w-5" />
                </Button>
              </form>
              <div className="flex justify-center gap-2 pt-1">
                <Button variant="outline" size="sm" onClick={startListening} className="gap-2"><Mic className="h-4 w-4" /> {t('voice.start')}</Button>
                <Button variant="ghost" size="sm" onClick={reset} className="gap-2"><RotateCcw className="h-4 w-4" /> {t('voice.reset')}</Button>
              </div>
            </div>
          )}

          {step === 'processing' && (
            <div className="flex flex-col items-center gap-4 py-4 text-center">
              <div className="relative flex h-24 w-24 items-center justify-center">
                <span className="absolute inset-0 animate-ping rounded-full bg-primary/25" />
                <span className="flex h-20 w-20 items-center justify-center rounded-full bg-primary text-primary-foreground">
                  <Sparkles className="h-8 w-8 animate-pulse" aria-hidden />
                </span>
              </div>
              <p className="text-[15px] font-semibold" aria-live="polite">{t('voice.checking')}</p>
              {question && <p className="max-w-md text-sm text-muted-foreground">“{question}”</p>}
            </div>
          )}

          {step === 'result' && result && (
            <div className="w-full max-w-xl space-y-3 text-center ot-fade-up">
              <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">{t('voice.result')}</p>
              {result.risk && (
                <div className="flex items-center justify-center gap-3">
                  <p className={`text-3xl font-extrabold tracking-tight ${result.risk.level === 'SAFE' ? 'risk-safe' : result.risk.level === 'MODERATE' ? 'risk-moderate' : 'risk-high'}`}>
                    {t(`risk.${result.risk.level.toLowerCase()}` as never)}
                  </p>
                </div>
              )}
              <p className="text-[16px] font-semibold leading-snug">{result.answer?.oneLiner}</p>
              {result.answer?.recommendation && <p className="mx-auto max-w-md text-sm leading-relaxed text-muted-foreground">{result.answer.recommendation}</p>}
            </div>
          )}
        </div>

        {/* Actions */}
        <CardContent className="space-y-4 p-4 sm:p-5">
          {step === 'result' && result && (
            <>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                <Button variant="outline" className="h-11 gap-2" onClick={() => speak(result.answer?.oneLiner ?? '')}>
                  <Volume2 className="h-4 w-4" /> {t('voice.hearSummary')}
                </Button>
                <Button variant="outline" className="h-11 gap-2" asChild>
                  <a href={smsHref()} onClick={(e) => {
                    if (!(/Mobi|Android/i.test(navigator.userAgent))) {
                      e.preventDefault()
                      navigator.clipboard?.writeText(result.answer?.oneLiner ?? '').then(() => toast({ title: t('common.copied') })).catch(() => undefined)
                    }
                  }}>
                    <Send className="h-4 w-4" /> {t('voice.sendSms')}
                  </a>
                </Button>
                <Button variant="outline" className="h-11 gap-2" onClick={openDetails}>
                  <MessageSquareText className="h-4 w-4" /> {t('common.moreDetails')}
                </Button>
                <Button variant="secondary" className="h-11 gap-2" onClick={reset}>
                  <RotateCcw className="h-4 w-4" /> {t('voice.reset')}
                </Button>
              </div>
              <p className="text-[11px] text-muted-foreground">{t('voice.smsHint')}</p>
              <div className="hidden">
                <Copy />
              </div>
              <AssessmentCard result={result} showAgents onReport={() => setView('reports')} />
            </>
          )}

          {step !== 'result' && (
            <div className="space-y-3">
              {/* Text simulation mode — always available, identical backend */}
              <div className="rounded-xl border border-dashed p-3">
                <p className="mb-2 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-muted-foreground">
                  <Keyboard className="h-3.5 w-3.5" /> {t('voice.textMode')}
                </p>
                <form className="flex items-center gap-2" onSubmit={(e) => { e.preventDefault(); if (textInput.trim()) { const q = textInput.trim(); setTextInput(''); submitQuery(q) } }}>
                  <Input value={textInput} onChange={(e) => setTextInput(e.target.value)} placeholder={t('voice.typeInstead')} className="h-12 rounded-xl" aria-label={t('voice.typeInstead')} />
                  <Button type="submit" size="icon" className="h-12 w-12 shrink-0 rounded-xl" disabled={!textInput.trim()} aria-label={t('voice.submitText')}>
                    <Send className="h-5 w-5" />
                  </Button>
                </form>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {['Kakinada', 'Tomorrow 6 AM', 'Visakhapatnam', 'Chennai'].map((s) => (
                    <button key={s} onClick={() => setTextInput(s)} className="rounded-full bg-muted px-2.5 py-1 text-xs font-medium text-muted-foreground hover:text-foreground">
                      {s}
                    </button>
                  ))}
                </div>
              </div>
              {!micSupported && (
                <p className="rounded-lg bg-amber-500/10 px-3 py-2 text-center text-xs font-medium text-amber-700 dark:text-amber-400">{t('voice.micUnavailable')}</p>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick-action card: quick dial to assistant if voice unavailable */}
      {step === 'idle' && (
        <Card className="mt-4 border-dashed">
          <CardContent className="flex items-center gap-3 p-4">
            <PhoneOff className="h-4 w-4 shrink-0 text-muted-foreground" aria-hidden />
            <p className="text-xs leading-relaxed text-muted-foreground">{t('voice.speechUnavailable')}</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
