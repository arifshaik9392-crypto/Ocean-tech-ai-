'use client'
// OceanTech AI — Marine Assistant (chat with agent pipeline + explainable assessment)
import { useCallback, useEffect, useRef, useState } from 'react'
import { History, SendHorizonal, Waves } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area'
import { AgentPipeline, RiskBadge, ViewHeader } from '@/components/shared/marine'
import { AssessmentCard } from '@/components/shared/AssessmentCard'
import { useLang } from '@/lib/i18n/context'
import { useApp } from '@/lib/store'
import { useToast } from '@/hooks/use-toast'
import type { OrchestratorResult } from '@/types/marine'
import { cn } from '@/lib/utils'

interface ChatMessage {
  role: 'user' | 'assistant'
  text?: string
  result?: OrchestratorResult
}

export function AssistantView() {
  const { t, lang } = useLang()
  const { sharedResult, consumeShared, markConsumed, setView, setSharedResult } = useApp()
  const { toast } = useToast()
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const [stage, setStage] = useState(0)
  const [history, setHistory] = useState<{ id: string; query: string; location: string | null; riskLevel: string | null; riskScore: number | null; createdAt: string; responseType: string }[]>([])
  const [historyOpen, setHistoryOpen] = useState(false)
  const pendingField = useRef<'location' | 'time' | null>(null)
  const previousActivity = useRef<string | undefined>(undefined)
  const bottomRef = useRef<HTMLDivElement>(null)

  const refreshHistory = useCallback(() => {
    fetch('/api/queries').then(async (r) => {
      if (r.ok) { const d = await r.json(); setHistory(d.queries ?? []) }
    }).catch(() => undefined)
  }, [])

  useEffect(() => { refreshHistory() }, [refreshHistory])

  // receive a result shared from Voice / Risk views
  useEffect(() => {
    if (consumeShared && sharedResult) {
      setMessages((m) => [...m, { role: 'user', text: sharedResult.question }, { role: 'assistant', result: sharedResult }])
      markConsumed()
      useApp.getState().setSharedResult(null)
      bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
    }
  }, [consumeShared, sharedResult, markConsumed])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, busy])

  async function ask(text: string, context?: { pendingField: 'location' | 'time' | null; previousActivity?: string }) {
    const q = text.trim()
    if (!q || busy) return
    setMessages((m) => [...m, { role: 'user', text: q }])
    setInput('')
    setBusy(true)
    setStage(0)
    const timers = [
      setTimeout(() => setStage(1), 350),
      setTimeout(() => setStage(2), 900),
      setTimeout(() => setStage(3), 1600),
    ]
    try {
      const res = await fetch('/api/orca/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: q, language: lang, context: context ?? { pendingField: pendingField.current, previousActivity: previousActivity.current } }),
      })
      if (res.status === 401) { window.location.reload(); return }
      if (!res.ok) throw new Error('bad response')
      const result: OrchestratorResult = await res.json()
      if (result.type === 'follow_up') {
        pendingField.current = result.followUp === '' ? null : (result.parsed?.location ? 'time' : 'location')
        if (result.parsed?.location || result.followUp?.includes('time') || result.followUp?.includes('ఎప్పుడు') || result.followUp?.includes('कब')) pendingField.current = 'time'
        previousActivity.current = result.parsed?.activity ?? 'fishing'
        setMessages((m) => [...m, { role: 'assistant', text: result.followUp ?? '' }])
      } else {
        pendingField.current = null
        setMessages((m) => [...m, { role: 'assistant', result }])
        refreshHistory()
      }
    } catch {
      toast({ title: t('common.error'), description: t('common.unavailable') })
      setMessages((m) => [...m, { role: 'assistant', text: t('common.unavailable') }])
    } finally {
      timers.forEach(clearTimeout)
      setBusy(false)
    }
  }

  async function openHistoryItem(id: string) {
    setHistoryOpen(false)
    try {
      const res = await fetch(`/api/queries/${id}`)
      if (!res.ok) return
      const result: OrchestratorResult = await res.json()
      setMessages((m) => [...m, { role: 'user', text: result.question }, { role: 'assistant', result }])
    } catch { /* ignore */ }
  }

  const suggestions = [t('assistant.s1'), t('assistant.s2'), t('assistant.s3'), t('assistant.s4'), t('assistant.s5')]

  return (
    <div className="flex gap-4">
      <div className="flex min-w-0 flex-1 flex-col">
        <ViewHeader
          title={t('assistant.title')}
          subtitle={t('assistant.subtitle')}
        >
          <Button variant="outline" size="sm" className="gap-2 lg:hidden" onClick={() => setHistoryOpen(true)}>
            <History className="h-4 w-4" /> {t('assistant.openHistory')}
          </Button>
        </ViewHeader>

        <Card className="flex min-h-[60vh] flex-1 flex-col">
          <CardContent className="flex min-h-[55vh] flex-1 flex-col gap-4 p-4">
            {messages.length === 0 && (
              <div className="flex flex-1 flex-col items-center justify-center gap-4 py-8 text-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10 text-primary">
                  <Waves className="h-6 w-6" aria-hidden />
                </div>
                <p className="max-w-sm text-sm text-muted-foreground">{t('assistant.subtitle')}</p>
              </div>
            )}

            <div className="ot-scroll flex-1 space-y-4 overflow-y-auto pr-1" role="log" aria-live="polite">
              {messages.map((m, i) => (
                <div key={i} className={cn('flex', m.role === 'user' ? 'justify-end' : 'justify-start')}>
                  {m.role === 'user' ? (
                    <div className="max-w-[85%] rounded-2xl rounded-br-md bg-primary px-4 py-2.5 text-[15px] leading-relaxed text-primary-foreground shadow-sm">
                      {m.text}
                    </div>
                  ) : m.result ? (
                    <div className="w-full max-w-full">
                      {m.result.answer?.oneLiner && !m.result.risk && (
                        <p className="mb-2 rounded-2xl rounded-bl-md border bg-card px-4 py-2.5 text-[15px] font-semibold leading-relaxed shadow-sm">
                          {m.result.answer.oneLiner}
                        </p>
                      )}
                      <AssessmentCard result={m.result} showAgents onReport={() => setView('reports')} />
                    </div>
                  ) : (
                    <div className="max-w-[85%] rounded-2xl rounded-bl-md border bg-card px-4 py-2.5 text-[15px] leading-relaxed shadow-sm ot-fade-up">
                      {m.text}
                    </div>
                  )}
                </div>
              ))}
              {busy && (
                <div className="rounded-2xl border bg-card p-4 shadow-sm ot-fade-up">
                  <AgentPipeline agents={[
                    { name: 'weather', labelKey: 'agents.weather', status: 'completed', confidence: 1, executionTimeMs: 0, summary: '', source: '', dataStatus: 'SAMPLE', updatedAt: new Date().toISOString() },
                    { name: 'ocean', labelKey: 'agents.ocean', status: 'completed', confidence: 1, executionTimeMs: 0, summary: '', source: '', dataStatus: 'SAMPLE', updatedAt: new Date().toISOString() },
                    { name: 'fishing', labelKey: 'agents.fishing', status: 'completed', confidence: 1, executionTimeMs: 0, summary: '', source: '', dataStatus: 'SAMPLE', updatedAt: new Date().toISOString() },
                  ]} done={stage >= 3} />
                </div>
              )}
              <div ref={bottomRef} />
            </div>

            {messages.length === 0 && (
              <div className="flex flex-wrap gap-2">
                {suggestions.map((s) => (
                  <button
                    key={s}
                    onClick={() => ask(s, { pendingField: null })}
                    className="rounded-full border bg-card px-3.5 py-2 text-[13px] font-medium text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    {s}
                  </button>
                ))}
              </div>
            )}

            <form
              className="flex items-center gap-2"
              onSubmit={(e) => { e.preventDefault(); if (busy) return; const ctx = { pendingField: pendingField.current, previousActivity: previousActivity.current }; ask(input, ctx) }}
            >
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={t('assistant.placeholder')}
                className="h-12 flex-1 rounded-xl text-[15px]"
                aria-label={t('assistant.placeholder')}
              />
              <Button type="submit" size="icon" className="h-12 w-12 shrink-0 rounded-xl" disabled={busy || !input.trim()} aria-label={t('common.send')}>
                <SendHorizonal className="h-5 w-5" />
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>

      {/* History — desktop side panel */}
      <aside className="hidden w-72 shrink-0 lg:block">
        <Card className="sticky top-20">
          <CardContent className="p-4">
            <h2 className="mb-3 flex items-center gap-2 text-sm font-bold uppercase tracking-wide text-muted-foreground">
              <History className="h-4 w-4" /> {t('assistant.history')}
            </h2>
            {history.length === 0 ? (
              <p className="text-xs text-muted-foreground">{t('assistant.historyEmpty')}</p>
            ) : (
              <div className="ot-scroll max-h-[64vh] space-y-2 overflow-y-auto pr-1">
                {history.map((h) => (
                  <button key={h.id} onClick={() => openHistoryItem(h.id)} className="w-full rounded-lg border p-2.5 text-left transition-colors hover:border-primary/40 focus-visible:ring-2 focus-visible:ring-ring">
                    <p className="line-clamp-2 text-[13px] font-medium leading-snug">{h.query}</p>
                    <div className="mt-1 flex items-center justify-between gap-2">
                      <span className="truncate text-[11px] text-muted-foreground">{h.location ?? '—'}</span>
                      {h.riskLevel ? <RiskBadge level={h.riskLevel} className="px-1.5 py-0 text-[10px]" /> : <span className="text-[10px] text-muted-foreground">{t('assistant.info')}</span>}
                    </div>
                    <p className="mt-0.5 text-[10.5px] text-muted-foreground">{new Date(h.createdAt).toLocaleString()}</p>
                  </button>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </aside>

      {/* History — mobile sheet */}
      {historyOpen && (
        <div className="fixed inset-0 z-50 flex items-end bg-black/40 lg:hidden" onClick={() => setHistoryOpen(false)} role="dialog" aria-modal="true">
          <div className="max-h-[70vh] w-full rounded-t-2xl border bg-background p-4 pb-8" onClick={(e) => e.stopPropagation()}>
            <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-muted-foreground">{t('assistant.history')}</h2>
            {history.length === 0 ? (
              <p className="text-xs text-muted-foreground">{t('assistant.historyEmpty')}</p>
            ) : (
              <div className="ot-scroll max-h-[54vh] space-y-2 overflow-y-auto">
                {history.map((h) => (
                  <button key={h.id} onClick={() => openHistoryItem(h.id)} className="w-full rounded-lg border p-2.5 text-left">
                    <p className="line-clamp-2 text-[13px] font-medium">{h.query}</p>
                    <div className="mt-1 flex items-center justify-between">
                      <span className="text-[11px] text-muted-foreground">{h.location ?? '—'}</span>
                      {h.riskLevel && <RiskBadge level={h.riskLevel} className="px-1.5 py-0 text-[10px]" />}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
