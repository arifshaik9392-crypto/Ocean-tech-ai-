'use client'
// OceanTech AI — Fishing Intelligence (potential fishing zones table)
import { useCallback, useEffect, useMemo, useState } from 'react'
import { CheckCircle2, Fish, MapPin, RefreshCw, Star, X } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { SourceMeta, ViewHeader, suitabilityBadgeClass } from '@/components/shared/marine'
import { useLang } from '@/lib/i18n/context'
import { focusMap, useApp } from '@/lib/store'
import type { FishingZoneInfo, MarinePoint } from '@/types/marine'
import { cn } from '@/lib/utils'

type TFn = ReturnType<typeof useLang>['t']

interface OverviewCoordsResponse {
  location: { name: string; slug: string; latitude: number; longitude: number }
}

const SUIT_RANK: Record<string, number> = { High: 0, Medium: 1, Low: 2 }

function statusBadgeClass(s: string): string {
  switch (s) {
    case 'Available': return 'bg-risk-safe/15 text-[color:var(--ot-safe)] border-risk-safe/40'
    case 'Restricted': return 'bg-amber-500/12 text-amber-700 dark:text-amber-400 border-amber-500/40'
    case 'Closed': return 'bg-risk-high/15 text-[color:var(--ot-high)] border-risk-high/40'
    default: return ''
  }
}

function relMinutes(iso: string, t: TFn): string {
  const m = Math.round((Date.now() - new Date(iso).getTime()) / 60000)
  if (!Number.isFinite(m) || m < 1) return t('common.now')
  return t('common.minAgo', { n: m })
}

export function FishingView() {
  const { t } = useLang()
  const { homeLocation } = useApp()
  const slug = homeLocation.trim().toLowerCase() || 'kakinada'

  const [zones, setZones] = useState<FishingZoneInfo[]>([])
  const [locationName, setLocationName] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [failed, setFailed] = useState(false)
  const [selected, setSelected] = useState<FishingZoneInfo | null>(null)
  const [reload, setReload] = useState(0)

  const retry = useCallback(() => setReload((n) => n + 1), [])

  useEffect(() => {
    let alive = true
    setLoading(true)
    setFailed(false)
    void (async () => {
      try {
        // 1) resolve home location coordinates via overview (locations list as fallback)
        let coords: { lat: number; lon: number } | null = null
        try {
          const r = await fetch(`/api/marine/overview?location=${encodeURIComponent(slug)}`)
          if (r.ok) {
            const d = (await r.json()) as OverviewCoordsResponse
            if (d?.location) {
              coords = { lat: d.location.latitude, lon: d.location.longitude }
              if (alive) setLocationName(d.location.name)
            }
          }
        } catch {
          /* fall through to the locations list */
        }
        if (!coords) {
          try {
            const r = await fetch('/api/locations')
            if (r.ok) {
              const d = (await r.json()) as { locations: MarinePoint[] }
              const match = d.locations?.find((l) => l.slug === slug)
              if (match) coords = { lat: match.latitude, lon: match.longitude }
            }
          } catch {
            /* proceed without coordinates */
          }
        }

        // 2) fetch PFZ feed scoped to the home coordinates when known
        const qs = coords ? `?lat=${encodeURIComponent(String(coords.lat))}&lon=${encodeURIComponent(String(coords.lon))}` : ''
        const r = await fetch(`/api/fishing/zones${qs}`)
        if (!r.ok) throw new Error('zones unavailable')
        const d = (await r.json()) as { zones: FishingZoneInfo[] }
        if (!alive) return
        setZones(d.zones ?? [])
      } catch {
        if (!alive) return
        setFailed(true)
        setZones([])
      } finally {
        if (alive) setLoading(false)
      }
    })()
    return () => {
      alive = false
    }
  }, [slug, reload])

  const availableCount = useMemo(() => zones.filter((z) => z.advisoryStatus === 'Available').length, [zones])

  const best = useMemo<FishingZoneInfo | null>(() => {
    if (zones.length === 0) return null
    return [...zones].sort(
      (a, b) => (SUIT_RANK[a.suitability] ?? 3) - (SUIT_RANK[b.suitability] ?? 3) || a.distanceKm - b.distanceKm
    )[0]
  }, [zones])

  function focusZone(z: FishingZoneInfo) {
    focusMap({ lat: z.centerLat, lon: z.centerLon, zoom: 10, layer: 'fishing', id: z.id, title: z.code })
  }

  return (
    <div className="space-y-4">
      <ViewHeader title={t('fishing.title')} subtitle={t('fishing.subtitle')} />

      {/* Summary strip */}
      {loading ? (
        <Skeleton className="h-14 w-full rounded-xl" />
      ) : zones.length > 0 ? (
        <Card className="gap-0 py-0">
          <CardContent className="flex flex-wrap items-center gap-x-6 gap-y-2 px-4 py-3 text-sm">
            <span className="inline-flex items-center gap-2 font-semibold">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 text-primary" aria-hidden>
                <Fish className="h-4 w-4" />
              </span>
              <span className="tabular-nums">{zones.length}</span>
              <span className="font-normal text-muted-foreground">{t('overview.fishingZones')}</span>
            </span>
            <span className="inline-flex items-center gap-2 font-semibold text-[color:var(--ot-safe)]">
              <CheckCircle2 className="h-4 w-4" aria-hidden />
              {t('overview.available', { n: availableCount })}
            </span>
            {best && (
              <span className="ml-auto inline-flex items-center gap-2 rounded-lg border bg-muted/40 px-2.5 py-1">
                <Star className="h-3.5 w-3.5 text-amber-500" aria-hidden />
                <span className="text-[13px] font-semibold">{best.code}</span>
                <span className="hidden text-xs text-muted-foreground sm:inline">{best.name}</span>
                <Badge variant="outline" className={cn('px-1.5 py-0 text-[10px]', suitabilityBadgeClass(best.suitability))}>
                  {t(`suit.${best.suitability}` as never)}
                </Badge>
              </span>
            )}
          </CardContent>
        </Card>
      ) : null}

      {/* Loading skeleton — 4 rows */}
      {loading && (
        <Card className="gap-0 py-0">
          <CardContent className="space-y-3 p-4">
            <Skeleton className="h-9 w-full" />
            <Skeleton className="h-9 w-full" />
            <Skeleton className="h-9 w-full" />
            <Skeleton className="h-9 w-full" />
          </CardContent>
        </Card>
      )}

      {/* Empty / error state */}
      {!loading && (failed || zones.length === 0) && (
        <Card>
          <CardContent className="flex flex-col items-center gap-3 p-8 text-center">
            <Fish className="h-8 w-8 text-muted-foreground/50" aria-hidden />
            <p className="max-w-md text-sm text-muted-foreground">
              {failed ? t('common.unavailable') : t('fishing.empty')}
            </p>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={retry}>
              <RefreshCw className="h-3.5 w-3.5" aria-hidden /> {t('common.retry')}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Zones table */}
      {!loading && zones.length > 0 && (
        <Card className="overflow-hidden py-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t('fishing.zone')}</TableHead>
                  <TableHead className="hidden sm:table-cell">{t('fishing.distance')}</TableHead>
                  <TableHead>{t('fishing.suitability')}</TableHead>
                  <TableHead className="hidden md:table-cell">{t('fishing.sst')}</TableHead>
                  <TableHead className="hidden md:table-cell">{t('fishing.chlorophyll')}</TableHead>
                  <TableHead>{t('fishing.risk')}</TableHead>
                  <TableHead className="hidden lg:table-cell">{t('fishing.advisory')}</TableHead>
                  <TableHead className="text-right">
                    <span className="sr-only">{t('common.viewOnMap')}</span>
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {zones.map((z) => (
                  <TableRow
                    key={z.id}
                    tabIndex={0}
                    onClick={() => setSelected(z)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault()
                        setSelected(z)
                      }
                    }}
                    className={cn('cursor-pointer', selected?.id === z.id && 'bg-accent/60')}
                  >
                    <TableCell>
                      <div className="font-semibold">{z.code}</div>
                      <div className="text-xs text-muted-foreground">{z.name}</div>
                      <div className="mt-0.5 text-xs text-muted-foreground sm:hidden">{z.distanceKm} km</div>
                    </TableCell>
                    <TableCell className="hidden tabular-nums sm:table-cell">{z.distanceKm} km</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={suitabilityBadgeClass(z.suitability)}>
                        {t(`suit.${z.suitability}` as never)}
                      </Badge>
                    </TableCell>
                    <TableCell className="hidden tabular-nums md:table-cell">{z.sst}°C</TableCell>
                    <TableCell className="hidden tabular-nums md:table-cell">{z.chlorophyll} mg/m³</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={statusBadgeClass(z.advisoryStatus)}>
                        {t(`st.${z.advisoryStatus}` as never)}
                      </Badge>
                    </TableCell>
                    <TableCell className="hidden text-[13px] text-muted-foreground lg:table-cell">
                      {t(`st.${z.advisoryStatus}` as never)}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-1.5"
                        onClick={(e) => {
                          e.stopPropagation()
                          focusZone(z)
                        }}
                      >
                        <MapPin className="h-3.5 w-3.5" aria-hidden />
                        <span className="hidden xl:inline">{t('common.viewOnMap')}</span>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </Card>
      )}

      {/* Selected zone details */}
      {selected && (
        <Card className="ot-fade-up">
          <CardContent className="p-4 sm:p-5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-base font-bold">{selected.code}</h2>
                  <Badge variant="outline" className={suitabilityBadgeClass(selected.suitability)}>
                    {t(`suit.${selected.suitability}` as never)}
                  </Badge>
                  <Badge variant="outline" className={statusBadgeClass(selected.advisoryStatus)}>
                    {t(`st.${selected.advisoryStatus}` as never)}
                  </Badge>
                </div>
                <p className="mt-0.5 text-sm text-muted-foreground">{selected.name}</p>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <Button variant="outline" size="sm" className="gap-1.5" onClick={() => focusZone(selected)}>
                  <MapPin className="h-3.5 w-3.5" aria-hidden /> {t('common.viewOnMap')}
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => setSelected(null)}
                  aria-label={t('common.close')}
                >
                  <X className="h-4 w-4" aria-hidden />
                </Button>
              </div>
            </div>

            <div className="mt-4 grid gap-3 sm:grid-cols-3">
              <div className="rounded-lg border bg-muted/40 p-3">
                <p className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground">{t('fishing.species')}</p>
                <p className="mt-1 text-sm font-medium leading-snug">{selected.species}</p>
              </div>
              <div className="rounded-lg border bg-muted/40 p-3">
                <p className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground">{t('map.homePort')}</p>
                <p className="mt-1 text-sm font-medium leading-snug">{selected.nearestPort}</p>
              </div>
              <div className="rounded-lg border bg-muted/40 p-3">
                <p className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground">{t('fishing.updated')}</p>
                <p className="mt-1 text-sm font-medium leading-snug">{relMinutes(selected.updatedAt, t)}</p>
              </div>
            </div>

            <div className="mt-3 border-t pt-3">
              <SourceMeta source="OceanTech Structured PFZ Feed" dataStatus="SAMPLE" updatedAt={selected.updatedAt} />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Context footer line (location scope) */}
      {!loading && !failed && zones.length > 0 && locationName && (
        <p className="text-xs text-muted-foreground">
          {t('overview.sub', { location: locationName })}
        </p>
      )}
    </div>
  )
}
