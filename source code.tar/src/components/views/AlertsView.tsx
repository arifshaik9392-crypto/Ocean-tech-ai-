'use client'
// OceanTech AI — Marine Alerts feed
import { useCallback, useEffect, useMemo, useState } from 'react'
import { CalendarClock, Clock, MapPin, RefreshCw, ShieldAlert } from 'lucide-react'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { Skeleton } from '@/components/ui/skeleton'
import { SourceMeta, ViewHeader, severityBadgeClass } from '@/components/shared/marine'
import { useLang } from '@/lib/i18n/context'
import { focusMap } from '@/lib/store'
import type { MarineAlertInfo, MarinePoint } from '@/types/marine'
import { cn } from '@/lib/utils'

type TFn = ReturnType<typeof useLang>['t']

const SEV_RANK: Record<string, number> = { Severe: 0, Warning: 1, Advisory: 2, Information: 3 }

function relMinutes(iso: string, t: TFn): string {
  const m = Math.round((Date.now() - new Date(iso).getTime()) / 60000)
  if (!Number.isFinite(m) || m < 1) return t('common.now')
  if (m < 60) return t('common.minAgo', { n: m })
  return t('common.hrAgo', { n: Math.round(m / 60) })
}

export function AlertsView() {
  const { t, lang } = useLang()
  const [alerts, setAlerts] = useState<MarineAlertInfo[]>([])
  const [locations, setLocations] = useState<MarinePoint[]>([])
  const [filter, setFilter] = useState<string>('all')
  const [loading, setLoading] = useState(true)
  const [failed, setFailed] = useState(false)
  const [reload, setReload] = useState(0)

  const retry = useCallback(() => setReload((n) => n + 1), [])

  // Location list for the filter (fetched once)
  useEffect(() => {
    let alive = true
    void (async () => {
      try {
        const r = await fetch('/api/locations')
        if (!r.ok) return
        const d = (await r.json()) as { locations: MarinePoint[] }
        if (alive) setLocations(d.locations ?? [])
      } catch {
        /* filter stays empty — list still renders */
      }
    })()
    return () => {
      alive = false
    }
  }, [])

  // Alerts (refetch on filter change)
  useEffect(() => {
    let alive = true
    setLoading(true)
    setFailed(false)
    void (async () => {
      try {
        const qs = filter === 'all' ? '' : `?location=${encodeURIComponent(filter)}`
        const r = await fetch(`/api/alerts${qs}`)
        if (!r.ok) throw new Error('alerts unavailable')
        const d = (await r.json()) as { alerts: MarineAlertInfo[] }
        if (!alive) return
        setAlerts(d.alerts ?? [])
      } catch {
        if (!alive) return
        setFailed(true)
        setAlerts([])
      } finally {
        if (alive) setLoading(false)
      }
    })()
    return () => {
      alive = false
    }
  }, [filter, reload])

  const sorted = useMemo(
    () =>
      [...alerts].sort(
        (a, b) =>
          (SEV_RANK[a.severity] ?? 9) - (SEV_RANK[b.severity] ?? 9) ||
          new Date(b.issuedAt).getTime() - new Date(a.issuedAt).getTime()
      ),
    [alerts]
  )

  const hasHigh = sorted.some((a) => a.severity === 'Warning' || a.severity === 'Severe')

  return (
    <div className="space-y-4">
      <ViewHeader title={t('alerts.title')} subtitle={t('alerts.subtitle')}>
        <div className="flex items-center gap-2">
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-44" aria-label={t('alerts.region')}>
              <SelectValue placeholder={t('overview.viewAll')} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t('overview.viewAll')}</SelectItem>
              {locations.map((l) => (
                <SelectItem key={l.slug} value={l.slug}>
                  {l.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            variant="outline"
            size="icon"
            className="h-9 w-9 shrink-0"
            onClick={retry}
            aria-label={t('common.retry')}
          >
            <RefreshCw className="h-4 w-4" aria-hidden />
          </Button>
        </div>
      </ViewHeader>

      {/* High-risk strip */}
      {hasHigh && !loading && (
        <Alert role="alert" className="border-risk-high/40 bg-risk-high/10">
          <ShieldAlert className="h-4 w-4 text-[color:var(--ot-high)]" aria-hidden />
          <AlertDescription className="text-[13px] font-medium text-[color:var(--ot-high)]">
            {t('risk.rec.high')}
          </AlertDescription>
        </Alert>
      )}

      {/* Loading skeletons */}
      {loading && (
        <div className="space-y-3">
          <Skeleton className="h-32 w-full rounded-xl" />
          <Skeleton className="h-32 w-full rounded-xl" />
          <Skeleton className="h-32 w-full rounded-xl" />
        </div>
      )}

      {/* Error state */}
      {!loading && failed && (
        <Card>
          <CardContent className="flex flex-col items-center gap-3 p-8 text-center">
            <ShieldAlert className="h-8 w-8 text-muted-foreground/50" aria-hidden />
            <p className="max-w-md text-sm text-muted-foreground">{t('common.unavailable')}</p>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={retry}>
              <RefreshCw className="h-3.5 w-3.5" aria-hidden /> {t('common.retry')}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Empty state */}
      {!loading && !failed && sorted.length === 0 && (
        <Card>
          <CardContent className="flex flex-col items-center gap-3 p-8 text-center">
            <ShieldAlert className="h-8 w-8 text-muted-foreground/50" aria-hidden />
            <p className="max-w-md text-sm text-muted-foreground">{t('alerts.empty')}</p>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={retry}>
              <RefreshCw className="h-3.5 w-3.5" aria-hidden /> {t('common.retry')}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Alert list */}
      {!loading && sorted.length > 0 && (
        <div className="space-y-3" aria-live="polite">
          {sorted.map((a) => {
            const lat = a.lat
            const lon = a.lon
            const canFocus = lat != null && lon != null
            return (
              <Card key={a.id} className="ot-fade-up">
                <CardContent className="p-4 sm:p-5">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <Badge
                          variant="outline"
                          className={cn('font-bold tracking-wide', severityBadgeClass(a.severity))}
                        >
                          {t(`sev.${a.severity}` as never)}
                        </Badge>
                        <h2 className="text-[15px] font-semibold leading-snug">{a.title}</h2>
                      </div>
                      <p className="mt-1.5 text-sm text-muted-foreground">{a.description}</p>
                    </div>
                    {canFocus && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="shrink-0 gap-1.5 text-muted-foreground"
                        onClick={() => focusMap({ lat, lon, zoom: 9, layer: 'alerts', id: a.id })}
                      >
                        <MapPin className="h-3.5 w-3.5" aria-hidden /> {t('common.viewOnMap')}
                      </Button>
                    )}
                  </div>

                  <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-muted-foreground">
                    <span className="inline-flex items-center gap-1">
                      <MapPin className="h-3 w-3" aria-hidden />
                      {t('alerts.region')}: <b className="font-semibold text-foreground">{a.region}</b>
                    </span>
                    <span className="inline-flex items-center gap-1">
                      <Clock className="h-3 w-3" aria-hidden />
                      {t('alerts.issued')} {relMinutes(a.issuedAt, t)}
                    </span>
                    <span className="inline-flex items-center gap-1">
                      <CalendarClock className="h-3 w-3" aria-hidden />
                      {a.expiresAt
                        ? `${t('alerts.expires')} ${new Date(a.expiresAt).toLocaleString(lang)}`
                        : t('alerts.noExpiry')}
                    </span>
                  </div>

                  <div className="mt-3 border-t pt-2.5">
                    <SourceMeta source={a.source} dataStatus="SAMPLE" updatedAt={a.issuedAt} />
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}

      {/* Sample-data note */}
      {!loading && sorted.length > 0 && (
        <Card className="border-dashed bg-transparent shadow-none">
          <CardContent className="p-4">
            <p className="text-xs leading-relaxed text-muted-foreground">{t('alerts.sampleNote')}</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
