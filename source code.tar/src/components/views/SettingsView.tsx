'use client'
// OceanTech AI — Settings (account, language, appearance, notifications, privacy, sign out)
// NOTE: no role selector anywhere — authorization is backend-managed.
import { useEffect, useState } from 'react'
import { useTheme } from 'next-themes'
import { Check, Lock, LogOut, Monitor, Moon, ShieldCheck, Sun } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Switch } from '@/components/ui/switch'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { ViewHeader } from '@/components/shared/marine'
import { useLang } from '@/lib/i18n/context'
import { LANGUAGES } from '@/lib/i18n/translations'
import { useApp } from '@/lib/store'
import { useToast } from '@/hooks/use-toast'
import type { LangCode } from '@/types/marine'
import { cn } from '@/lib/utils'

const NOTIFY_KEY = 'oceantech.notify'

interface LocationInfo { name: string; slug: string; state: string; latitude: number; longitude: number; type: string }

const THEME_TILES = [
  { value: 'light', icon: Sun, labelKey: 'settings.light' },
  { value: 'dark', icon: Moon, labelKey: 'settings.dark' },
  { value: 'system', icon: Monitor, labelKey: 'settings.system' },
] as const

export function SettingsView() {
  const { t, lang, setLang } = useLang()
  const { user, setUser } = useApp()
  const { theme, setTheme } = useTheme()
  const { toast } = useToast()

  const [fullName, setFullName] = useState(user?.fullName ?? '')
  const [phone, setPhone] = useState(user?.phone ?? '')
  const [homeLocation, setHomeLocation] = useState(user?.homeLocation ?? '')
  const [locations, setLocations] = useState<LocationInfo[]>([])
  const [saving, setSaving] = useState(false)
  const [notify, setNotify] = useState(false)

  // keep local fields in sync when the profile loads/changes
  useEffect(() => {
    if (!user) return
    setFullName(user.fullName ?? '')
    setPhone(user.phone ?? '')
    setHomeLocation(user.homeLocation ?? '')
  }, [user])

  useEffect(() => {
    fetch('/api/locations').then(async (r) => {
      if (r.ok) { const d = await r.json(); setLocations(d.locations ?? []) }
    }).catch(() => undefined)
  }, [])

  // notifications preference persisted locally
  useEffect(() => {
    try { setNotify(localStorage.getItem(NOTIFY_KEY) === '1') } catch { /* ignore */ }
  }, [])

  // DB may store the display name ("Kakinada") while Select options use slugs — resolve safely
  const effectiveSlug =
    (locations ?? []).find((l) => l.slug === homeLocation)?.slug ??
    (locations ?? []).find((l) => l.slug.toLowerCase() === homeLocation.toLowerCase())?.slug ??
    (locations ?? []).find((l) => l.name.toLowerCase() === homeLocation.toLowerCase())?.slug ??
    homeLocation

  function onNotifyChange(v: boolean) {
    setNotify(v)
    try { localStorage.setItem(NOTIFY_KEY, v ? '1' : '0') } catch { /* ignore */ }
  }

  async function saveAccount() {
    if (saving) return
    setSaving(true)
    try {
      const res = await fetch('/api/user/preferences', {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fullName: fullName.trim(), phone: phone.trim(), homeLocation: effectiveSlug }),
      })
      if (res.status === 401) { window.location.reload(); return }
      if (!res.ok) throw new Error('failed')
      const d = await res.json()
      if (d.user) setUser(d.user)
      toast({ title: t('settings.saved') })
    } catch {
      toast({ title: t('common.error'), description: t('common.unavailable') })
    } finally {
      setSaving(false)
    }
  }

  async function onThemeChange(value: string) {
    setTheme(value)
    try {
      await fetch('/api/user/preferences', {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ themePreference: value }),
      })
    } catch { /* theme still applied locally */ }
  }

  async function signOut() {
    try { await fetch('/api/auth/logout', { method: 'POST' }) } catch { /* reload anyway */ }
    window.location.reload()
  }

  return (
    <div className="mx-auto max-w-3xl space-y-5">
      <ViewHeader title={t('settings.title')} />

      {/* Account */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-bold">{t('settings.account')}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="acc-name">{t('settings.fullName')}</Label>
              <Input id="acc-name" value={fullName} onChange={(e) => setFullName(e.target.value)} className="h-10 rounded-xl" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="acc-phone">{t('settings.phone')}</Label>
              <Input id="acc-phone" value={phone} onChange={(e) => setPhone(e.target.value)} className="h-10 rounded-xl" inputMode="tel" />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="acc-email">{t('auth.email')}</Label>
            <Input id="acc-email" value={user?.email ?? ''} readOnly disabled className="h-10 rounded-xl opacity-80" aria-readonly />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="acc-port">{t('settings.homePort')}</Label>
            <Select value={effectiveSlug || undefined} onValueChange={setHomeLocation}>
              <SelectTrigger id="acc-port" className="w-full rounded-xl sm:w-[280px]">
                <SelectValue placeholder={t('common.notAvailable')} />
              </SelectTrigger>
              <SelectContent className="max-h-72 ot-scroll">
                {(locations ?? []).map((l) => (
                  <SelectItem key={l.slug} value={l.slug}>{l.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs leading-relaxed text-muted-foreground">{t('settings.homePortDesc')}</p>
          </div>

          <Button onClick={saveAccount} disabled={saving} className="h-10 rounded-xl px-6 font-semibold">
            {saving ? t('common.loading') : t('settings.save')}
          </Button>
        </CardContent>
      </Card>

      {/* Language */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-bold">{t('settings.language')}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-1.5">
          <p className="text-xs leading-relaxed text-muted-foreground">{t('settings.languageDesc')}</p>
          <Select value={lang} onValueChange={(v) => setLang(v as LangCode)}>
            <SelectTrigger className="w-full rounded-xl sm:w-[280px]" aria-label={t('settings.language')}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="max-h-72 ot-scroll">
              {LANGUAGES.map((l) => (
                <SelectItem key={l.code} value={l.code}>
                  <span className="flex items-center gap-2">
                    {l.label}
                    {l.code === lang && <Check className="h-3.5 w-3.5 text-primary" aria-hidden />}
                  </span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Appearance */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-bold">{t('settings.appearance')}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-3" role="radiogroup" aria-label={t('settings.appearance')}>
            {THEME_TILES.map((tile) => {
              const active = theme === tile.value
              const Icon = tile.icon
              return (
                <button
                  key={tile.value}
                  type="button"
                  role="radio"
                  aria-checked={active}
                  onClick={() => onThemeChange(tile.value)}
                  className={cn(
                    'flex flex-col items-center gap-2 rounded-xl border bg-card px-3 py-4 text-sm font-semibold transition-all focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none',
                    active ? 'border-primary ring-2 ring-primary' : 'hover:border-primary/40 text-muted-foreground',
                  )}
                >
                  <Icon className={cn('h-5 w-5', active && 'text-primary')} aria-hidden />
                  {t(tile.labelKey as never)}
                </button>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Notifications */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-bold">{t('settings.notifications')}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between gap-4">
            <p className="max-w-md text-xs leading-relaxed text-muted-foreground">{t('settings.notificationsDesc')}</p>
            <Switch checked={notify} onCheckedChange={onNotifyChange} aria-label={t('settings.notifications')} />
          </div>
        </CardContent>
      </Card>

      {/* Privacy */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-bold">{t('settings.privacy')}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-start gap-3">
            <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-primary" aria-hidden />
            <p className="text-xs leading-relaxed text-muted-foreground">{t('settings.privacyDesc')}</p>
          </div>
        </CardContent>
      </Card>

      {/* Sign out */}
      <Card>
        <CardContent className="flex flex-wrap items-center justify-between gap-3 p-4 sm:p-5">
          <p className="text-sm font-semibold">{t('settings.signOut')}</p>
          <Button variant="destructive" onClick={signOut} className="gap-2 rounded-xl">
            <LogOut className="h-4 w-4" aria-hidden /> {t('settings.signOut')}
          </Button>
        </CardContent>
      </Card>

      <Separator />

      {/* Footnote */}
      <p className="flex items-start gap-2 pb-2 text-[11.5px] leading-relaxed text-muted-foreground">
        <Lock className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden />
        {t('settings.accountNote')}
      </p>
    </div>
  )
}
