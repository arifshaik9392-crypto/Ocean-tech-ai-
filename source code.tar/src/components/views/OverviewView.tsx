'use client'
// OceanTech AI — Overview dashboard (hero ask, voice priority, stat grid, alerts, quick links)
import { useCallback, useEffect, useState } from 'react'
import {
  Activity, AlertTriangle, ArrowRight, Fish, Map as MapIcon, Mic, SendHorizonal,
  Waves, Wind,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { RiskBadge, severityBadgeClass } from '@/components/shared/marine'
import { useLang } from '@/lib/i18n/context'
import { useApp } from '@/lib/store'
import { useToast } from '@/hooks/use-toast'
import type { MarinePoint, MarineAlertInfo, OrchestratorResult } from '@/types/marine'
import { cn } from '@/lib/utils'

interface OverviewData {
  location: { name: string; slug: string; state: string; latitude: number; longitude: number }
  risk: { level: 'SAFE' | 'MODERATE' | 'HIGH'; score: number; confidence: number } | null
  weather: { windSpeed: number; windDirection: string; condition: string; temperature: number; updatedAt: string; source: string; dataStatus: 'SAMPLE' | 'LIVE' }
  ocean: { waveHeight: number; wavePeriod: number; seaTemp: number; currentSpeed: number; updatedAt: string; source: string; dataStatus: 'SAMPLE' | 'LIVE' }
  alertsCount: number
  alerts: MarineAlertInfo[]
  fishingAvailable: number
  fishingTotal: number
  updatedAt: string
}

function UpdatedAgo({ updatedAt }: { updatedAt: string | null }) {
  const { t } = useLang()
  if (!updatedAt) return <p className="text-[10.5px] text-muted-foreground">{t('common.notAvailable')}</p>
  const mins = Math.max(0, Math.round((Date.now() - new Date(updatedAt).getTime()) / 60000))
  const ago = mins < 60 ? t('common.minAgo', { n: mins }) : t('common.hrAgo', { n: Math.round(mins / 60) })
  return <p className="text-[10.5px] text-muted-foreground">{t('common.updated')} {mins < 1 ? t('common.now') : ago}</p>
}

function StatCardSkeleton() {
  return (
    <Card>
      <CardContent className="space-y-2 p-4">
        <Skeleton className="h-3 w-24" />
        <Skeleton className="h-7 w-16" />
        <Skeleton className="h-3 w-20" />
      </CardContent>
    </Card>
  )
}

export function OverviewView() {
  const { t, lang } = useLang()
  const { user, homeLocation, setHomeLocation, setUser, setView, setSharedResult } = useApp()
  const { toast } = useToast()

  const [locations, setLocations] = useState<MarinePoint[]>([])
  const [data, setData] = useState<OverviewData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)
  const [ask, setAsk] = useState('')
  const [asking, setAsking] = useState(false)

  const loadOverview = useCallback(async (slug: string) => {
    if (!slug) return
    setLoading(true)
    setError(false)
    try {
      const res = await fetch(`/api/marine/overview?location=${encodeURIComponent(slug)}`)
      if (!res.ok) throw new Error('failed')
      const d: OverviewData = await res.json()
      setData(d)
    } catch {
      setError(true)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetch('/api/locations').then(async (r) => {
      if (r.ok) { const d = await r.json(); setLocations(d.locations ?? []) }
    }).catch(() => undefined)
  }, [])

  async function onLocationChange(slug: string) {
    setHomeLocation(slug)
    try {
      const res = await fetch('/api/user/preferences', {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ homeLocation: slug }),
      })
      if (res.ok) { const d = await res.json(); if (d.user) setUser(d.user) }
    } catch { /* keep local selection anyway */ }
  }

  async function submitAsk(e: React.FormEvent) {
    e.preventDefault()
    const q = ask.trim()
    if (!q || asking) return
    setAsking(true)
    try {
      const res = await fetch('/api/orca/query', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: q, language: lang }),
      })
      if (res.status === 401) { window.location.reload(); return }
      if (!res.ok) throw new Error('failed')
      const result: OrchestratorResult = await res.json()
      setAsk('')
      setSharedResult(result)
      setView('assistant')
    } catch {
      toast({ title: t('common.error'), description: t('common.unavailable') })
    } finally {
      setAsking(false)
    }
  }

  const firstName = user?.fullName?.split(' ')[0] ?? ''
  // DB may store the display name ("Kakinada") while APIs expect slugs ("kakinada") — resolve safely
  const effectiveSlug =
    (locations ?? []).find((l) => l.slug === homeLocation)?.slug ??
    (locations ?? []).find((l) => l.slug.toLowerCase() === homeLocation.toLowerCase())?.slug ??
    (locations ?? []).find((l) => l.name.toLowerCase() === homeLocation.toLowerCase())?.slug ??
    homeLocation

  // refetch once the slug is (re)resolved against the loaded locations
  useEffect(() => { loadOverview(effectiveSlug) }, [effectiveSlug, loadOverview])
  const riskLevel = data?.risk?.level
  const riskScore = data?.risk?.score
  const riskClass = riskLevel === 'SAFE' ? 'risk-safe' : riskLevel === 'MODERATE' ? 'risk-moderate' : 'risk-high'

  return (
    <div className="space-y-5">
      {/* Greeting + home port selector */}
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold tracking-tight sm:text-2xl">{t('overview.hello', { name: firstName })}</h1>
          <p className="mt-0.5 text-sm text-muted-foreground">
            {data ? t('overview.sub', { location: data.location.name }) : t('overview.title')}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="sr-only">{t('risk.location')}</span>
          <Select value={effectiveSlug || undefined} onValueChange={(v) => onLocationChange(v)}>
            <SelectTrigger className="w-[190px] rounded-xl" aria-label={t('risk.location')}>
              <SelectValue placeholder={t('common.notAvailable')} />
            </SelectTrigger>
            <SelectContent className="max-h-72 ot-scroll">
              {(locations ?? []).map((l) => (
                <SelectItem key={l.slug} value={l.slug}>{l.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Hero ask card — voice has visual priority */}
      <Card className="overflow-hidden border-primary/25 bg-gradient-to-b from-primary/8 to-transparent">
        <CardContent className="space-y-4 p-5 sm:p-6">
          <h2 className="flex items-center gap-2 text-base font-bold tracking-tight">
            <Activity className="h-4.5 w-4.5 text-primary" aria-hidden /> {t('overview.askTitle')}
          </h2>
          <form className="flex flex-col gap-2 sm:flex-row" onSubmit={submitAsk}>
            <Input
              value={ask}
              onChange={(e) => setAsk(e.target.value)}
              placeholder={t('overview.askPlaceholder')}
              className="h-12 flex-1 rounded-xl text-[15px]"
              aria-label={t('overview.askPlaceholder')}
            />
            <Button
              type="submit" variant="outline" disabled={asking || !ask.trim()}
              className="h-12 gap-2 rounded-xl px-6 font-semibold"
            >
              <SendHorizonal className="h-4 w-4" aria-hidden /> {t('overview.askBtn')}
            </Button>
          </form>

          <div className="flex flex-col gap-3 rounded-xl border bg-card/80 p-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="min-w-0">
              <p className="flex items-center gap-1.5 text-sm font-semibold">
                <Mic className="h-4 w-4 text-primary" aria-hidden /> {t('overview.voiceTitle')}
              </p>
              <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">{t('overview.voiceDesc')}</p>
            </div>
            <Button
              onClick={() => setView('voice')}
              className="h-11 w-full gap-2 rounded-xl px-5 font-semibold bg-primary text-primary-foreground sm:w-auto"
            >
              <Mic className="h-4 w-4" aria-hidden /> {t('overview.openVoice')}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Stat cards */}
      {loading ? (
        <div className="grid grid-cols-2 gap-3 xl:grid-cols-5">
          {Array.from({ length: 5 }).map((_, i) => <StatCardSkeleton key={i} />)}
        </div>
      ) : error ? (
        <Card>
          <CardContent className="flex flex-col items-start gap-3 p-5">
            <p className="text-sm text-muted-foreground">{t('common.unavailable')}</p>
            <Button variant="outline" size="sm" onClick={() => loadOverview(effectiveSlug)}>{t('common.retry')}</Button>
          </CardContent>
        </Card>
      ) : data ? (
        <div className="grid grid-cols-2 gap-3 xl:grid-cols-5">
          <Card>
            <CardContent className="p-4">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">{t('overview.currentRisk')}</p>
              {riskLevel ? (
                <>
                  <div className="mt-2 flex items-baseline gap-2">
                    <span className={cn('text-3xl font-extrabold leading-none tabular-nums', riskClass)}>{riskScore ?? '—'}</span>
                    <RiskBadge level={riskLevel} className="px-1.5 py-0 text-[10px]" />
                  </div>
                </>
              ) : (
                <p className="mt-2 text-lg font-semibold text-muted-foreground">{t('common.notAvailable')}</p>
              )}
              <div className="mt-2"><UpdatedAgo updatedAt={data.updatedAt} /></div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">{t('overview.waveConditions')}</p>
              <p className="mt-2 text-3xl font-extrabold leading-none tabular-nums">
                {data.ocean ? data.ocean.waveHeight : '—'} <span className="text-sm font-semibold text-muted-foreground">m</span>
              </p>
              <div className="mt-2"><UpdatedAgo updatedAt={data.ocean?.updatedAt ?? null} /></div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                <Wind className="h-3 w-3" aria-hidden /> {t('overview.wind')}
              </p>
              <p className="mt-2 text-3xl font-extrabold leading-none tabular-nums">
                {data.weather ? data.weather.windSpeed : '—'} <span className="text-sm font-semibold text-muted-foreground">km/h</span>
              </p>
              <p className="mt-1 text-xs font-medium text-muted-foreground">{data.weather?.windDirection ?? ''}</p>
              <div className="mt-1"><UpdatedAgo updatedAt={data.weather?.updatedAt ?? null} /></div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                <AlertTriangle className="h-3 w-3" aria-hidden /> {t('overview.marineAlerts')}
              </p>
              <p className="mt-2 text-3xl font-extrabold leading-none tabular-nums">{data.alertsCount}</p>
              <p className="mt-1 text-xs font-medium text-muted-foreground">{t('overview.activeNow', { n: data.alertsCount })}</p>
              <div className="mt-1"><UpdatedAgo updatedAt={data.updatedAt} /></div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                <Fish className="h-3 w-3" aria-hidden /> {t('overview.fishingZones')}
              </p>
              <p className="mt-2 text-3xl font-extrabold leading-none tabular-nums">{data.fishingAvailable}</p>
              <p className="mt-1 text-xs font-medium text-muted-foreground">{t('overview.available', { n: data.fishingAvailable })}</p>
              <div className="mt-1"><UpdatedAgo updatedAt={data.updatedAt} /></div>
            </CardContent>
          </Card>
        </div>
      ) : null}

      {/* Latest alerts */}
      {data && (data.alerts ?? []).length > 0 && (
        <Card>
          <CardContent className="p-4 sm:p-5">
            <div className="mb-3 flex items-center justify-between gap-2">
              <h2 className="text-sm font-bold uppercase tracking-wide text-muted-foreground">{t('overview.recentAlerts')}</h2>
              <Button variant="ghost" size="sm" className="gap-1.5" onClick={() => setView('alerts')}>
                {t('overview.viewAll')} <ArrowRight className="h-3.5 w-3.5" aria-hidden />
              </Button>
            </div>
            <div className="space-y-2">
              {(data.alerts ?? []).slice(0, 3).map((a) => (
                <div key={a.id} className="flex items-start gap-2.5 rounded-lg border p-2.5">
                  <span className={cn('mt-0.5 shrink-0 rounded border px-1.5 py-0.5 text-[10px] font-bold', severityBadgeClass(a.severity))}>
                    {t(`sev.${a.severity}` as never)}
                  </span>
                  <div className="min-w-0">
                    <p className="text-[13px] font-medium leading-snug">{a.title}</p>
                    <p className="truncate text-[11px] text-muted-foreground">{a.region}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Quick links */}
      <div className="grid gap-3 sm:grid-cols-2">
        <Card className="transition-colors hover:border-primary/40">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <MapIcon className="h-5 w-5" aria-hidden />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold">{t('overview.mapCard')}</p>
              <p className="mt-0.5 line-clamp-2 text-xs leading-relaxed text-muted-foreground">{t('overview.mapDesc')}</p>
            </div>
            <Button variant="ghost" size="sm" className="gap-1.5" onClick={() => setView('map')}>
              {t('overview.open')} <ArrowRight className="h-3.5 w-3.5" aria-hidden />
            </Button>
          </CardContent>
        </Card>

        <Card className="transition-colors hover:border-primary/40">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <Waves className="h-5 w-5" aria-hidden />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold">{t('overview.fishingCard')}</p>
              <p className="mt-0.5 line-clamp-2 text-xs leading-relaxed text-muted-foreground">{t('overview.fishingDesc')}</p>
            </div>
            <Button variant="ghost" size="sm" className="gap-1.5" onClick={() => setView('fishing')}>
              {t('overview.open')} <ArrowRight className="h-3.5 w-3.5" aria-hidden />
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
