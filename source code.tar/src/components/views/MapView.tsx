'use client'
// OceanTech AI — Interactive marine map (Leaflet + OpenStreetMap tiles)
import 'leaflet/dist/leaflet.css'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type { Layer, LayerGroup, Map as LeafletMap } from 'leaflet'
import { AlertTriangle, Layers, Loader2, RefreshCw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { ViewHeader } from '@/components/shared/marine'
import { useLang } from '@/lib/i18n/context'
import { useApp } from '@/lib/store'
import type { FishingZoneInfo, GisZoneInfo, MapFocusPoint, MarineAlertInfo, MarinePoint } from '@/types/marine'

type TFn = ReturnType<typeof useLang>['t']
type LayerKey = 'fishing' | 'alerts' | 'restricted' | 'protected' | 'risk'
type LeafletModule = typeof import('leaflet')

interface OverviewResponse {
  location: MarinePoint
  risk: { level: string; score: number; confidence: number } | null
}

const LAYER_KEYS: LayerKey[] = ['fishing', 'alerts', 'restricted', 'protected', 'risk']

const FISHING_HEX = '#0d9488'
const RESTRICTED_HEX = '#dc2626'
const PROTECTED_HEX = '#0d9488'
const SEV_HEX: Record<string, string> = {
  Severe: '#dc2626', Warning: '#ea580c', Advisory: '#d97706', Information: '#0284c7',
}
const RISK_HEX: Record<string, string> = { SAFE: '#16a34a', MODERATE: '#d97706', HIGH: '#dc2626' }

const HOME_PIN_SVG =
  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="5" r="3"/><path d="M12 22V8"/><path d="M5 12H2a10 10 0 0 0 20 0h-3"/></svg>'

const PIN_CSS = `
.ot-alert-dot{display:block;width:14px;height:14px;border-radius:9999px;border:2px solid #fff;box-shadow:0 1px 4px rgb(0 0 0/0.35);position:relative}
.ot-alert-dot::before{content:'';position:absolute;inset:-7px;border-radius:9999px;background:inherit;opacity:.45;animation:ot-alert-ping 1.9s ease-out infinite}
@keyframes ot-alert-ping{0%{transform:scale(.45);opacity:.5}75%,100%{transform:scale(1.55);opacity:0}}
.ot-home-pin{display:flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:9999px;background:#0d9488;color:#fff;border:2px solid #fff;box-shadow:0 2px 8px rgb(0 0 0/0.35)}
.ot-home-pin svg{width:15px;height:15px}
.ot-legend-dot{display:inline-block;width:9px;height:9px;border-radius:9999px}
`

function esc(s: string): string {
  return s.replace(/[&<>"']/g, (c) =>
    c === '&' ? '&amp;' : c === '<' ? '&lt;' : c === '>' ? '&gt;' : c === '"' ? '&quot;' : '&#39;'
  )
}

function relMinutes(iso: string, t: TFn): string {
  const m = Math.round((Date.now() - new Date(iso).getTime()) / 60000)
  if (!Number.isFinite(m) || m < 1) return t('common.now')
  return t('common.minAgo', { n: m })
}

function riskKey(level: string): string {
  return level === 'SAFE' || level === 'MODERATE' || level === 'HIGH' ? level.toLowerCase() : 'moderate'
}

function statusChip(status: string, t: TFn): string {
  const hex = status === 'Available' ? '#16a34a' : status === 'Restricted' ? '#d97706' : '#dc2626'
  return `<span class="inline-flex items-center rounded border px-1.5 py-0.5 text-[10.5px] font-semibold" style="border-color:${hex}55;color:${hex};background:${hex}14">${esc(t(`st.${status}` as never))}</span>`
}

function pfzPopupHtml(z: FishingZoneInfo, t: TFn): string {
  return `<div class="space-y-1.5 text-[13px] leading-snug">
    <p class="text-[10.5px] font-bold uppercase tracking-widest" style="color:${FISHING_HEX}">${esc(t('map.pfzPopup'))}</p>
    <p class="text-sm font-bold leading-tight">${esc(z.code)} · ${esc(z.name)}</p>
    <p class="text-muted-foreground">${esc(t('map.distance'))}: <b class="text-foreground">${z.distanceKm} km</b> · ${esc(t('map.suitability'))}: <b class="text-foreground">${esc(t(`suit.${z.suitability}` as never))}</b></p>
    <p class="text-muted-foreground">${esc(t('map.sst'))}: <b class="text-foreground">${z.sst}°C</b> · ${esc(t('map.chlorophyll'))}: <b class="text-foreground">${z.chlorophyll} mg/m³</b></p>
    <p>${statusChip(z.advisoryStatus, t)}</p>
    <p class="mt-1.5 border-t pt-1.5 text-[11px] text-muted-foreground">${esc(t('common.viewDetails'))} →</p>
  </div>`
}

function alertPopupHtml(a: MarineAlertInfo, t: TFn): string {
  const hex = SEV_HEX[a.severity] ?? '#0284c7'
  return `<div class="space-y-1.5 text-[13px] leading-snug">
    <p class="text-[10.5px] font-bold uppercase tracking-widest" style="color:${hex}">${esc(t('map.alertPopup'))}</p>
    <p class="text-sm font-bold leading-tight">${esc(a.title)}</p>
    <p class="text-muted-foreground">${esc(t('map.severity'))}: <b style="color:${hex}">${esc(t(`sev.${a.severity}` as never))}</b> · ${esc(t('map.region'))}: <b class="text-foreground">${esc(a.region)}</b></p>
    <p class="text-muted-foreground">${esc(a.source)} · ${esc(t('common.updated'))} ${esc(relMinutes(a.issuedAt, t))}</p>
  </div>`
}

function gisPopupHtml(g: GisZoneInfo, t: TFn): string {
  const restricted = g.zoneType === 'restricted'
  const color = restricted ? RESTRICTED_HEX : PROTECTED_HEX
  return `<div class="space-y-1.5 text-[13px] leading-snug">
    <p class="text-[10.5px] font-bold uppercase tracking-widest" style="color:${color}">${esc(t(restricted ? 'map.layerRestricted' : 'map.layerProtected'))}</p>
    <p class="text-sm font-bold leading-tight">${esc(g.name)}</p>
    ${g.description ? `<p class="text-muted-foreground">${esc(g.description)}</p>` : ''}
  </div>`
}

function riskPopupHtml(level: string, score: number, t: TFn): string {
  const hex = RISK_HEX[level] ?? '#d97706'
  return `<div class="space-y-1 text-[13px] leading-snug">
    <p class="text-[10.5px] font-bold uppercase tracking-widest" style="color:${hex}">${esc(t('overview.currentRisk'))}</p>
    <p class="text-sm font-bold">${esc(t(`risk.${riskKey(level)}` as never))} · ${score} ${esc(t('risk.outOf100'))}</p>
  </div>`
}

export function MapView() {
  const { t } = useLang()
  const { homeLocation, mapFocus } = useApp()

  const containerRef = useRef<HTMLDivElement | null>(null)
  const mapRef = useRef<LeafletMap | null>(null)
  const LRef = useRef<LeafletModule | null>(null)
  const layersRef = useRef<Record<LayerKey, LayerGroup | null>>({
    fishing: null, alerts: null, restricted: null, protected: null, risk: null,
  })
  const markersRef = useRef<Map<string, Layer>>(new Map())
  const focusRef = useRef<MapFocusPoint | null>(useApp.getState().mapFocus)
  const visibleRef = useRef<Record<LayerKey, boolean>>({
    fishing: true, alerts: true, restricted: true, protected: true, risk: true,
  })

  const [ready, setReady] = useState(false)
  const [mapFailed, setMapFailed] = useState(false)
  const [loading, setLoading] = useState(true)
  const [failed, setFailed] = useState(false)
  const [reload, setReload] = useState(0)
  const [zones, setZones] = useState<FishingZoneInfo[]>([])
  const [alerts, setAlerts] = useState<MarineAlertInfo[]>([])
  const [gis, setGis] = useState<GisZoneInfo[]>([])
  const [overview, setOverview] = useState<OverviewResponse | null>(null)
  const [locations, setLocations] = useState<MarinePoint[]>([])
  const [visible, setVisible] = useState<Record<LayerKey, boolean>>({
    fishing: true, alerts: true, restricted: true, protected: true, risk: true,
  })

  const slug = homeLocation.trim().toLowerCase() || 'kakinada'

  // Home port coordinates: overview first, locations list as fallback
  const home = useMemo<MarinePoint | null>(
    () => overview?.location ?? locations.find((l) => l.slug === slug) ?? null,
    [overview, locations, slug]
  )
  const risk = useMemo(() => overview?.risk ?? null, [overview])

  const retry = useCallback(() => setReload((n) => n + 1), [])

  // --- Init Leaflet imperatively (never during SSR) -------------------------
  useEffect(() => {
    let cancelled = false
    let map: LeafletMap | null = null
    void (async () => {
      try {
        const L = await import('leaflet')
        const el = containerRef.current
        if (cancelled || !el) return
        LRef.current = L
        const f = focusRef.current
        map = L.map(el, {
          center: f ? [f.lat, f.lon] : [16.5, 82.3],
          zoom: f ? f.zoom ?? 9 : 8,
          scrollWheelZoom: true,
        })
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a> contributors',
          maxZoom: 18,
        }).addTo(map)
        mapRef.current = map
        setReady(true)
      } catch {
        if (!cancelled) setMapFailed(true)
      }
    })()
    return () => {
      cancelled = true
      map?.remove()
      mapRef.current = null
    }
  }, [])

  // --- Fetch all datasets in parallel --------------------------------------
  useEffect(() => {
    let alive = true
    setLoading(true)
    setFailed(false)
    async function getJson<T>(url: string): Promise<T | null> {
      try {
        const r = await fetch(url)
        if (!r.ok) return null
        return (await r.json()) as T
      } catch {
        return null
      }
    }
    void Promise.all([
      getJson<{ zones: FishingZoneInfo[] }>('/api/fishing/zones'),
      getJson<{ alerts: MarineAlertInfo[] }>('/api/alerts'),
      getJson<{ zones: GisZoneInfo[] }>('/api/gis/zones'),
      getJson<OverviewResponse>(`/api/marine/overview?location=${encodeURIComponent(slug)}`),
      getJson<{ locations: MarinePoint[] }>('/api/locations'),
    ]).then(([z, a, g, o, l]) => {
      if (!alive) return
      setZones(z?.zones ?? [])
      setAlerts(a?.alerts ?? [])
      setGis(g?.zones ?? [])
      setOverview(o)
      setLocations(l?.locations ?? [])
      setFailed(!o && !z && !g)
      setLoading(false)
    })
    return () => {
      alive = false
    }
  }, [slug, reload])

  // --- Layer visibility -----------------------------------------------------
  const applyVisible = useCallback(() => {
    const map = mapRef.current
    if (!map) return
    for (const k of LAYER_KEYS) {
      const g = layersRef.current[k]
      if (!g) continue
      const on = visibleRef.current[k]
      if (on && !map.hasLayer(g)) g.addTo(map)
      else if (!on && map.hasLayer(g)) map.removeLayer(g)
    }
  }, [])

  useEffect(() => {
    visibleRef.current = visible
    applyVisible()
  }, [visible, applyVisible])

  // --- mapFocus: fly + open popup ------------------------------------------
  const applyFocus = useCallback(() => {
    const f = focusRef.current
    const map = mapRef.current
    if (!map || !f) return
    map.flyTo([f.lat, f.lon], f.zoom ?? 9, { duration: 1.1 })
    const target = f.id && f.layer ? markersRef.current.get(`${f.layer}:${f.id}`) : undefined
    if (target) target.openPopup()
    focusRef.current = null // local ref only — store value is left untouched
  }, [])

  useEffect(() => {
    if (!mapFocus) return
    focusRef.current = mapFocus
    if (mapRef.current) applyFocus()
  }, [mapFocus, ready, applyFocus])

  // --- Build map layers from data -------------------------------------------
  useEffect(() => {
    const L = LRef.current
    const map = mapRef.current
    if (!L || !map || !ready) return

    for (const k of LAYER_KEYS) {
      const g = layersRef.current[k]
      if (g) map.removeLayer(g)
    }
    markersRef.current.clear()

    // Fishing zones
    const fishingGroup = L.layerGroup()
    for (const z of zones) {
      const m = L.circleMarker([z.centerLat, z.centerLon], {
        radius: 9,
        color: FISHING_HEX,
        weight: 2,
        fillColor: FISHING_HEX,
        fillOpacity: 0.4,
      })
        .bindPopup(pfzPopupHtml(z, t), { maxWidth: 260 })
      fishingGroup.addLayer(m)
      markersRef.current.set(`fishing:${z.id}`, m)
    }

    // Marine alerts (pulsing severity-colored pins)
    const alertGroup = L.layerGroup()
    for (const a of alerts) {
      if (a.lat == null || a.lon == null) continue
      const hex = SEV_HEX[a.severity] ?? '#0284c7'
      const icon = L.divIcon({
        className: 'ot-alert-pin',
        html: `<span class="ot-alert-dot" style="background:${hex}"></span>`,
        iconSize: [14, 14],
        iconAnchor: [7, 7],
      })
      const m = L.marker([a.lat, a.lon], { icon, title: a.title })
        .bindPopup(alertPopupHtml(a, t), { maxWidth: 260 })
      alertGroup.addLayer(m)
      markersRef.current.set(`alerts:${a.id}`, m)
    }

    // GIS zones — restricted (dashed red) / protected (teal)
    const restrictedGroup = L.layerGroup()
    const protectedGroup = L.layerGroup()
    for (const g of gis) {
      if (g.zoneType !== 'restricted' && g.zoneType !== 'protected') continue
      const isRestricted = g.zoneType === 'restricted'
      const circle = L.circle([g.centerLat, g.centerLon], {
        radius: Math.max(500, g.radiusKm * 1000),
        color: isRestricted ? RESTRICTED_HEX : PROTECTED_HEX,
        weight: isRestricted ? 2 : 1.5,
        dashArray: isRestricted ? '6 6' : undefined,
        fillColor: isRestricted ? RESTRICTED_HEX : PROTECTED_HEX,
        fillOpacity: isRestricted ? 0.08 : 0.12,
      })
        .bindPopup(gisPopupHtml(g, t), { maxWidth: 260 })
      ;(isRestricted ? restrictedGroup : protectedGroup).addLayer(circle)
      markersRef.current.set(`${g.zoneType}:${g.id}`, circle)
    }

    // Home port marker + risk ring
    const riskGroup = L.layerGroup()
    if (home) {
      const homeMarker = L.marker([home.latitude, home.longitude], {
        icon: L.divIcon({ className: 'ot-home-pin', html: HOME_PIN_SVG, iconSize: [30, 30], iconAnchor: [15, 15] }),
        title: home.name,
        zIndexOffset: 500,
      }).bindTooltip(`${t('map.homePort')} · ${home.name}`, { direction: 'top', offset: [0, -14] })
      riskGroup.addLayer(homeMarker)
    }
    if (home && risk) {
      const hex = RISK_HEX[risk.level] ?? '#d97706'
      const ring = L.circle([home.latitude, home.longitude], {
        radius: 30000,
        color: hex,
        weight: 2,
        fillColor: hex,
        fillOpacity: 0.08,
      })
        .bindPopup(riskPopupHtml(risk.level, risk.score, t), { maxWidth: 260 })
      riskGroup.addLayer(ring)
      markersRef.current.set('risk:home', ring)
    }

    layersRef.current = {
      fishing: fishingGroup, alerts: alertGroup,
      restricted: restrictedGroup, protected: protectedGroup, risk: riskGroup,
    }
    applyVisible()
    applyFocus()
  }, [ready, zones, alerts, gis, home, risk, t, applyVisible, applyFocus])

  const layerLabels = useMemo<Record<LayerKey, string>>(() => ({
    fishing: t('map.layerFishing'),
    alerts: t('map.layerAlerts'),
    restricted: t('map.layerRestricted'),
    protected: t('map.layerProtected'),
    risk: t('map.layerRisk'),
  }), [t])

  const legend = useMemo(() => ([
    { color: FISHING_HEX, label: t('map.layerFishing') },
    { color: '#ea580c', label: t('map.layerAlerts') },
    { color: RESTRICTED_HEX, label: t('map.layerRestricted') },
    { color: PROTECTED_HEX, label: t('map.layerProtected') },
  ]), [t])

  return (
    <div>
      <ViewHeader title={t('map.title')} subtitle={t('map.subtitle')} />
      <style>{PIN_CSS}</style>

      <div
        className="relative z-0 h-[calc(100vh-190px)] min-h-[480px] w-full overflow-hidden rounded-xl border bg-card"
        role="application"
        aria-label={t('map.title')}
      >
        <div ref={containerRef} className="absolute inset-0" />

        {loading && !mapFailed && (
          <div className="absolute left-3 top-3 z-[1100] flex items-center gap-2 rounded-lg border bg-card/90 px-3 py-1.5 text-xs text-muted-foreground shadow-sm backdrop-blur">
            <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden /> {t('common.loading')}
          </div>
        )}

        {(mapFailed || (!loading && failed)) && (
          <div
            className={`absolute z-[1100] flex items-center gap-2 rounded-lg border border-risk-high/40 bg-card/95 px-3 py-1.5 text-xs text-muted-foreground shadow-sm backdrop-blur ${mapFailed ? 'inset-0 justify-center' : 'left-3 top-3'}`}
          >
            <AlertTriangle className="h-3.5 w-3.5 shrink-0 text-[color:var(--ot-high)]" aria-hidden />
            {t('common.unavailable')}
            {!mapFailed && (
              <Button variant="outline" size="sm" className="h-7 gap-1 px-2 text-[11px]" onClick={retry}>
                <RefreshCw className="h-3 w-3" aria-hidden /> {t('common.retry')}
              </Button>
            )}
          </div>
        )}

        {/* Layer panel */}
        <Card className="absolute right-3 top-3 z-[1100] w-48 gap-0 py-0 shadow-md">
          <CardContent className="p-3">
            <p className="mb-2 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-widest text-muted-foreground">
              <Layers className="h-3.5 w-3.5" aria-hidden /> {t('map.layers')}
            </p>
            <div className="space-y-2">
              {LAYER_KEYS.map((k) => (
                <label key={k} className="flex cursor-pointer items-center gap-2 text-[13px] font-medium">
                  <Checkbox
                    checked={visible[k]}
                    onCheckedChange={(v) => setVisible((s) => ({ ...s, [k]: v === true }))}
                    aria-label={layerLabels[k]}
                  />
                  {layerLabels[k]}
                </label>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Legend */}
        <div className="absolute bottom-3 left-3 z-[1100] flex flex-wrap items-center gap-x-3 gap-y-1 rounded-lg border bg-card/90 px-3 py-2 text-[11px] font-medium text-muted-foreground shadow-sm backdrop-blur">
          {legend.map((l) => (
            <span key={l.label} className="inline-flex items-center gap-1.5">
              <span className="ot-legend-dot" style={{ background: l.color }} aria-hidden />
              {l.label}
            </span>
          ))}
        </div>
      </div>

      <p className="mt-2 text-center text-xs text-muted-foreground">{t('map.zoomHint')}</p>
    </div>
  )
}
