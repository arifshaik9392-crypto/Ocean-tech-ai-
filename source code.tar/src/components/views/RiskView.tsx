'use client'
// OceanTech AI — Risk & Safety (transparent, explainable trip check)
import { useEffect, useState } from 'react'
import { LifeBuoy, ShieldCheck } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { AgentPipeline, ViewHeader } from '@/components/shared/marine'
import { AssessmentCard } from '@/components/shared/AssessmentCard'
import { useLang } from '@/lib/i18n/context'
import { useApp } from '@/lib/store'
import { useToast } from '@/hooks/use-toast'
import type { AgentRunInfo, OrchestratorResult } from '@/types/marine'

interface LocationInfo { name: string; slug: string; state: string; latitude: number; longitude: number; type: string }

const STATIC_AGENTS: AgentRunInfo[] = [
  { name: 'weather', labelKey: 'agents.weather', status: 'completed', confidence: 1, executionTimeMs: 0, summary: '', source: '', dataStatus: 'SAMPLE', updatedAt: new Date().toISOString() },
  { name: 'ocean', labelKey: 'agents.ocean', status: 'completed', confidence: 1, executionTimeMs: 0, summary: '', source: '', dataStatus: 'SAMPLE', updatedAt: new Date().toISOString() },
  { name: 'fishing', labelKey: 'agents.fishing', status: 'completed', confidence: 1, executionTimeMs: 0, summary: '', source: '', dataStatus: 'SAMPLE', updatedAt: new Date().toISOString() },
]

export function RiskView() {
  const { t, lang } = useLang()
  const { sharedResult, setView } = useApp()
  const { toast } = useToast()

  const [locations, setLocations] = useState<LocationInfo[]>([])
  const [loc, setLoc] = useState<string>('')
  const [when, setWhen] = useState<'today' | 'tomorrow'>('tomorrow')
  const [busy, setBusy] = useState(false)
  const [result, setResult] = useState<OrchestratorResult | null>(null)
  const [followUp, setFollowUp] = useState<string | null>(null)

  useEffect(() => {
    fetch('/api/locations').then(async (r) => {
      if (r.ok) {
        const d = await r.json()
        const list: LocationInfo[] = d.locations ?? []
        setLocations(list)
        setLoc((cur) => cur || list[0]?.slug || '')
      }
    }).catch(() => undefined)
  }, [])

  async function check() {
    if (busy || !loc) return
    const locationName = (locations ?? []).find((l) => l.slug === loc)?.name ?? loc
    // deterministic English query — the orchestrator parses it reliably in every language
    const query = `Can I go fishing ${when === 'today' ? 'today' : 'tomorrow'} morning from ${locationName}?`
    setBusy(true)
    setResult(null)
    setFollowUp(null)
    try {
      const res = await fetch('/api/orca/query', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query, language: lang, context: { pendingField: null } }),
      })
      if (res.status === 401) { window.location.reload(); return }
      if (!res.ok) throw new Error('failed')
      const data: OrchestratorResult = await res.json()
      if (data.type === 'follow_up') {
        setFollowUp(data.followUp ?? t('common.unavailable'))
      } else {
        setResult(data)
      }
    } catch {
      toast({ title: t('common.error'), description: t('common.unavailable') })
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="mx-auto max-w-3xl space-y-5">
      <ViewHeader title={t('risk.title')} subtitle={t('risk.subtitle')} />

      {/* Plan a trip check */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base font-bold">
            <ShieldCheck className="h-4.5 w-4.5 text-primary" aria-hidden /> {t('risk.checkTitle')}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="risk-location">{t('risk.location')}</Label>
              <Select value={loc || undefined} onValueChange={setLoc}>
                <SelectTrigger id="risk-location" className="w-full rounded-xl">
                  <SelectValue placeholder={t('common.notAvailable')} />
                </SelectTrigger>
                <SelectContent className="max-h-72 ot-scroll">
                  {(locations ?? []).map((l) => (
                    <SelectItem key={l.slug} value={l.slug}>{l.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="risk-when">{t('risk.when')}</Label>
              <Select value={when} onValueChange={(v) => setWhen(v as 'today' | 'tomorrow')}>
                <SelectTrigger id="risk-when" className="w-full rounded-xl">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="today">{t('risk.today')}</SelectItem>
                  <SelectItem value="tomorrow">{t('risk.tomorrow')}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <Button onClick={check} disabled={busy || !loc} className="h-11 w-full gap-2 rounded-xl font-semibold sm:w-auto sm:px-8">
            <ShieldCheck className="h-4 w-4" aria-hidden /> {t('risk.checkNow')}
          </Button>

          {busy && (
            <Card>
              <CardContent className="p-4">
                <AgentPipeline agents={STATIC_AGENTS} done={false} />
              </CardContent>
            </Card>
          )}

          {!busy && result && <AssessmentCard result={result} showAgents onReport={() => setView('reports')} />}

          {!busy && followUp && (
            <p className="rounded-xl border border-primary/25 bg-primary/6 p-4 text-sm font-medium leading-relaxed">{followUp}</p>
          )}
        </CardContent>
      </Card>

      {/* Result shared from another view (assistant / voice) */}
      {!busy && sharedResult?.risk && (
        <div className="space-y-2">
          <h2 className="text-sm font-bold uppercase tracking-wide text-muted-foreground">{t('assistant.title')}</h2>
          <AssessmentCard result={sharedResult} showAgents onReport={() => setView('reports')} />
        </div>
      )}

      {/* Emergency notice */}
      <div className="flex items-start gap-3 rounded-xl border border-risk-high/40 bg-risk-high/10 p-4 text-[color:var(--ot-high)]">
        <LifeBuoy className="mt-0.5 h-5 w-5 shrink-0" aria-hidden />
        <p className="text-sm font-semibold leading-relaxed">{t('risk.emergency')}</p>
      </div>
    </div>
  )
}
