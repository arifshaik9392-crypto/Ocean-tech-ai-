'use client'
// OceanTech AI — Ocean conditions (24h wave / sea temperature / current trends)
import { useCallback, useEffect, useState } from 'react'
import {
  Area, AreaChart, CartesianGrid, Line, LineChart, ResponsiveContainer,
  Tooltip, XAxis, YAxis,
} from 'recharts'
import { Waves } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { SourceMeta, ViewHeader } from '@/components/shared/marine'
import { useLang } from '@/lib/i18n/context'

interface LocationInfo { name: string; slug: string; state: string; latitude: number; longitude: number; type: string }

interface OverviewPayload {
  location: { name: string; slug: string }
  ocean: { waveHeight: number; wavePeriod: number; seaTemp: number; currentSpeed: number; updatedAt: string; source: string; dataStatus: 'SAMPLE' | 'LIVE' }
}

interface SeriesPayload {
  weather: { t: string; wind: number; temp: number; rain: number }[]
  ocean: { t: string; wave: number; period: number; current: number; seaTemp: number }[]
  location: { name: string }
}

interface ChartPoint { time: string; wave: number; seaTemp: number; current: number }

const TOOLTIP_STYLE = {
  background: 'var(--card)',
  border: '1px solid var(--border)',
  borderRadius: 12,
  color: 'var(--card-foreground)',
  fontSize: 12,
} as const

const TICK = { fontSize: 11, fill: 'var(--muted-foreground)' } as const

function seaStateKey(waveHeight: number): string {
  if (waveHeight < 0.5) return 'calm'
  if (waveHeight < 1.25) return 'slight'
  if (waveHeight < 2.5) return 'moderate'
  if (waveHeight < 4) return 'rough'
  return 'very_rough'
}

function toChartPoints(rows: { t: string; wave: number; current: number; seaTemp: number }[] | undefined): ChartPoint[] {
  return (rows ?? []).map((r) => ({
    time: `${new Date(r.t).getHours()}:00`,
    wave: r.wave,
    seaTemp: r.seaTemp,
    current: r.current,
  }))
}

function StatSkeleton() {
  return (
    <Card>
      <CardContent className="space-y-2 p-4">
        <Skeleton className="h-3 w-24" />
        <Skeleton className="h-7 w-16" />
      </CardContent>
    </Card>
  )
}

function ChartSkeleton() {
  return (
    <Card>
      <CardHeader className="pb-2"><Skeleton className="h-4 w-52" /></CardHeader>
      <CardContent><Skeleton className="h-[240px] w-full rounded-xl" /></CardContent>
    </Card>
  )
}

export function OceanView() {
  const { t } = useLang()
  const [locations, setLocations] = useState<LocationInfo[]>([])
  const [sel, setSel] = useState<string>('')
  const [overview, setOverview] = useState<OverviewPayload | null>(null)
  const [series, setSeries] = useState<SeriesPayload | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)

  useEffect(() => {
    fetch('/api/locations').then(async (r) => {
      if (r.ok) {
        const d = await r.json()
        const list: LocationInfo[] = d.locations ?? []
        setLocations(list)
        setSel((cur) => cur || list[0]?.slug || '')
      }
    }).catch(() => setError(true))
  }, [])

  const load = useCallback(async (slug: string) => {
    if (!slug) return
    setLoading(true)
    setError(false)
    try {
      const [ovRes, seRes] = await Promise.all([
        fetch(`/api/marine/overview?location=${encodeURIComponent(slug)}`),
        fetch(`/api/marine/series?location=${encodeURIComponent(slug)}&hours=24`),
      ])
      if (!ovRes.ok || !seRes.ok) throw new Error('failed')
      setOverview(await ovRes.json())
      setSeries(await seRes.json())
    } catch {
      setError(true)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load(sel) }, [sel, load])

  const ocean = overview?.ocean ?? null
  const points = toChartPoints(series?.ocean)
  // at most 8 x ticks (every 3rd hour)
  const ticks = points.filter((_, i) => i % 3 === 0).map((p) => p.time)
  const source = ocean?.source ?? '—'
  const updatedAt = ocean?.updatedAt ?? new Date().toISOString()
  const dataStatus: 'SAMPLE' | 'LIVE' = ocean?.dataStatus ?? 'SAMPLE'

  const axisProps = { tick: TICK, tickLine: false, axisLine: false } as const

  return (
    <div className="space-y-5">
      <ViewHeader title={t('ocean.title')} subtitle={t('ocean.subtitle')}>
        <Select value={sel || undefined} onValueChange={setSel}>
          <SelectTrigger className="w-[190px] rounded-xl" aria-label={t('risk.location')}>
            <SelectValue placeholder={t('common.notAvailable')} />
          </SelectTrigger>
          <SelectContent className="max-h-72 ot-scroll">
            {(locations ?? []).map((l) => (
              <SelectItem key={l.slug} value={l.slug}>{l.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </ViewHeader>

      {error && !loading ? (
        <Card>
          <CardContent className="flex flex-col items-start gap-3 p-5">
            <p className="text-sm text-muted-foreground">{t('common.unavailable')}</p>
            <Button variant="outline" size="sm" onClick={() => load(sel)}>{t('common.retry')}</Button>
          </CardContent>
        </Card>
      ) : loading ? (
        <>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            {Array.from({ length: 4 }).map((_, i) => <StatSkeleton key={i} />)}
          </div>
          <div className="grid gap-4 xl:grid-cols-3">
            {Array.from({ length: 3 }).map((_, i) => <ChartSkeleton key={i} />)}
          </div>
        </>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Card>
              <CardContent className="p-4">
                <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">{t('ocean.waveHeight')}</p>
                <p className="mt-2 text-3xl font-extrabold leading-none tabular-nums">
                  {ocean ? ocean.waveHeight : '—'} <span className="text-sm font-semibold text-muted-foreground">m</span>
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">{t('ocean.wavePeriod')}</p>
                <p className="mt-2 text-3xl font-extrabold leading-none tabular-nums">
                  {ocean ? ocean.wavePeriod : '—'} <span className="text-sm font-semibold text-muted-foreground">s</span>
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">{t('ocean.currentSpeed')}</p>
                <p className="mt-2 text-3xl font-extrabold leading-none tabular-nums">
                  {ocean ? ocean.currentSpeed : '—'} <span className="text-sm font-semibold text-muted-foreground">m/s</span>
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">{t('ocean.seaTemperature')}</p>
                <p className="mt-2 text-3xl font-extrabold leading-none tabular-nums">
                  {ocean ? ocean.seaTemp : '—'} <span className="text-sm font-semibold text-muted-foreground">°C</span>
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="flex items-center gap-2">
            <Badge variant="outline" className="gap-1.5 border-primary/40 bg-primary/10 font-semibold text-primary">
              <Waves className="h-3.5 w-3.5" aria-hidden />
              {t('ocean.seaState')}: {ocean ? t(`sea.${seaStateKey(ocean.waveHeight)}` as never) : t('common.notAvailable')}
            </Badge>
          </div>

          <div className="grid gap-4 xl:grid-cols-3">
            {/* Wave trend */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-bold">{t('ocean.waveTrend')}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {points.length > 0 ? (
                  <ResponsiveContainer width="100%" height={240}>
                    <AreaChart data={points} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
                      <defs>
                        <linearGradient id="waveFill" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.35} />
                          <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0.04} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                      <XAxis dataKey="time" ticks={ticks} {...axisProps} />
                      <YAxis domain={['auto', 'auto']} {...axisProps} width={40} />
                      <Tooltip contentStyle={TOOLTIP_STYLE} labelStyle={{ color: 'var(--muted-foreground)' }} />
                      <Area type="monotone" dataKey="wave" name={t('ocean.waveHeight')} stroke="var(--chart-1)" strokeWidth={2} fill="url(#waveFill)" fillOpacity={0.2} dot={false} />
                    </AreaChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex h-[240px] items-center justify-center text-sm text-muted-foreground">{t('common.notAvailable')}</div>
                )}
                <SourceMeta source={source} dataStatus={dataStatus} updatedAt={updatedAt} />
              </CardContent>
            </Card>

            {/* Sea temperature trend */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-bold">{t('ocean.tempTrend')}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {points.length > 0 ? (
                  <ResponsiveContainer width="100%" height={240}>
                    <LineChart data={points} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                      <XAxis dataKey="time" ticks={ticks} {...axisProps} />
                      <YAxis domain={['auto', 'auto']} {...axisProps} width={40} />
                      <Tooltip contentStyle={TOOLTIP_STYLE} labelStyle={{ color: 'var(--muted-foreground)' }} />
                      <Line type="monotone" dataKey="seaTemp" name={t('ocean.seaTemperature')} stroke="#b45309" strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex h-[240px] items-center justify-center text-sm text-muted-foreground">{t('common.notAvailable')}</div>
                )}
                <SourceMeta source={source} dataStatus={dataStatus} updatedAt={updatedAt} />
              </CardContent>
            </Card>

            {/* Current speed trend */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-bold">{t('ocean.currentTrend')}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {points.length > 0 ? (
                  <ResponsiveContainer width="100%" height={240}>
                    <LineChart data={points} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                      <XAxis dataKey="time" ticks={ticks} {...axisProps} />
                      <YAxis domain={['auto', 'auto']} {...axisProps} width={40} />
                      <Tooltip contentStyle={TOOLTIP_STYLE} labelStyle={{ color: 'var(--muted-foreground)' }} />
                      <Line type="monotone" dataKey="current" name={t('ocean.currentSpeed')} stroke="#0f766e" strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex h-[240px] items-center justify-center text-sm text-muted-foreground">{t('common.notAvailable')}</div>
                )}
                <SourceMeta source={source} dataStatus={dataStatus} updatedAt={updatedAt} />
              </CardContent>
            </Card>
          </div>
        </>
      )}
    </div>
  )
}
