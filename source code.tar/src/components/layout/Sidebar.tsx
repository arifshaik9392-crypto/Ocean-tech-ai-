'use client'
// OceanTech AI — sidebar: VOICE ASSISTANCE FIRST (top priority per product direction)
import { Anchor, Bell, FileText, LifeBuoy, Map, MessageSquareText, Mic, Settings, ShieldAlert, Waves, Fish } from 'lucide-react'
import { useLang } from '@/lib/i18n/context'
import { useApp } from '@/lib/store'
import type { ViewKey } from '@/types/marine'
import { cn } from '@/lib/utils'
import { Badge } from '@/components/ui/badge'
import { Sheet, SheetContent, SheetTitle } from '@/components/ui/sheet'

function NavButton({ view, icon, label, active, onClick, emphasized }: {
  view: ViewKey; icon: React.ReactNode; label: string; active: boolean; onClick: () => void; emphasized?: boolean
}) {
  return (
    <button
      onClick={onClick}
      aria-current={active ? 'page' : undefined}
      className={cn(
        'flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm font-medium outline-none transition-colors focus-visible:ring-2 focus-visible:ring-ring',
        active ? 'bg-primary/12 text-primary' : 'text-sidebar-foreground/85 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground',
        emphasized && !active && 'text-primary',
      )}
      data-nav={view}
    >
      <span className={cn('flex h-8 w-8 shrink-0 items-center justify-center rounded-lg', emphasized ? 'bg-primary text-primary-foreground shadow-sm' : active ? 'bg-primary/15 text-primary' : 'bg-muted text-muted-foreground')}>
        {icon}
      </span>
      <span className="truncate">{label}</span>
    </button>
  )
}

function SidebarContent() {
  const { view, setView } = useApp()
  const { t } = useLang()
  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2.5 px-4 pb-4 pt-5">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm">
          <Anchor className="h-5 w-5" aria-hidden />
        </div>
        <div className="min-w-0">
          <p className="truncate text-[15px] font-extrabold leading-tight tracking-tight">OCEANTECH AI</p>
          <p className="truncate text-[10.5px] leading-tight text-muted-foreground">{t('brand.tagline')}</p>
        </div>
      </div>

      <nav className="ot-scroll flex-1 space-y-5 overflow-y-auto px-3 pb-4" aria-label="Primary">
        <div className="space-y-1">
          <p className="px-3 pb-1 text-[10.5px] font-bold uppercase tracking-widest text-muted-foreground/80">{t('nav.section.primary')}</p>
          <NavButton view="voice" emphasized icon={<Mic className="h-4 w-4" />} label={t('nav.voice')} active={view === 'voice'} onClick={() => setView('voice')} />
          <NavButton view="overview" icon={<Waves className="h-4 w-4" />} label={t('nav.overview')} active={view === 'overview'} onClick={() => setView('overview')} />
          <NavButton view="assistant" icon={<MessageSquareText className="h-4 w-4" />} label={t('nav.assistant')} active={view === 'assistant'} onClick={() => setView('assistant')} />
        </div>
        <div className="space-y-1">
          <p className="px-3 pb-1 text-[10.5px] font-bold uppercase tracking-widest text-muted-foreground/80">{t('nav.section.explore')}</p>
          <NavButton view="map" icon={<Map className="h-4 w-4" />} label={t('nav.map')} active={view === 'map'} onClick={() => setView('map')} />
          <NavButton view="risk" icon={<ShieldAlert className="h-4 w-4" />} label={t('nav.risk')} active={view === 'risk'} onClick={() => setView('risk')} />
          <NavButton view="fishing" icon={<Fish className="h-4 w-4" />} label={t('nav.fishing')} active={view === 'fishing'} onClick={() => setView('fishing')} />
          <NavButton view="alerts" icon={<Bell className="h-4 w-4" />} label={t('nav.alerts')} active={view === 'alerts'} onClick={() => setView('alerts')} />
          <NavButton view="ocean" icon={<Waves className="h-4 w-4" />} label={t('nav.ocean')} active={view === 'ocean'} onClick={() => setView('ocean')} />
          <NavButton view="reports" icon={<FileText className="h-4 w-4" />} label={t('nav.reports')} active={view === 'reports'} onClick={() => setView('reports')} />
        </div>
        <div className="space-y-1">
          <p className="px-3 pb-1 text-[10.5px] font-bold uppercase tracking-widest text-muted-foreground/80">{t('nav.section.system')}</p>
          <NavButton view="settings" icon={<Settings className="h-4 w-4" />} label={t('nav.settings')} active={view === 'settings'} onClick={() => setView('settings')} />
        </div>
      </nav>

      <div className="border-t border-sidebar-border px-4 py-3">
        <div className="flex items-center gap-2">
          <LifeBuoy className="h-3.5 w-3.5 text-muted-foreground" />
          <p className="text-[11px] leading-snug text-muted-foreground">{t('assistant.limitationsText')}</p>
        </div>
        <Badge variant="outline" className="mt-2 w-full justify-center border-amber-600/40 bg-amber-500/10 text-[10px] font-semibold tracking-wide text-amber-700 dark:text-amber-400">
          {t('common.sampleData')}
        </Badge>
      </div>
    </div>
  )
}

export function Sidebar() {
  const { sidebarOpen, setSidebarOpen } = useApp()
  return (
    <>
      {/* Desktop */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 border-r border-sidebar-border bg-sidebar lg:block">
        <SidebarContent />
      </aside>
      {/* Mobile / tablet */}
      <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
        <SheetContent side="left" className="w-72 bg-sidebar p-0">
          <SheetTitle className="sr-only">Navigation</SheetTitle>
          <SidebarContent />
        </SheetContent>
      </Sheet>
    </>
  )
}
