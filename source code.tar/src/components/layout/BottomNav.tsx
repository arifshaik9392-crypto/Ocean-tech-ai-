'use client'
// OceanTech AI — mobile bottom navigation (voice first)
import { Bell, FileText, Fish, Map, MessageSquareText, Mic, MoreHorizontal, Settings, ShieldAlert, Waves } from 'lucide-react'
import { useState } from 'react'
import { useLang } from '@/lib/i18n/context'
import { useApp } from '@/lib/store'
import { cn } from '@/lib/utils'
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet'

function Item({ icon, label, active, onClick, primary }: { icon: React.ReactNode; label: string; active: boolean; onClick: () => void; primary?: boolean }) {
  return (
    <button
      onClick={onClick}
      aria-current={active ? 'page' : undefined}
      className={cn(
        'flex min-h-[52px] flex-1 flex-col items-center justify-center gap-0.5 rounded-lg px-1 py-1 text-[10px] font-medium outline-none transition-colors focus-visible:ring-2 focus-visible:ring-ring',
        active ? 'text-primary' : 'text-muted-foreground',
      )}
    >
      <span className={cn('flex h-8 w-8 items-center justify-center rounded-lg', primary ? 'bg-primary text-primary-foreground' : active ? 'bg-primary/12' : '')}>
        {icon}
      </span>
      <span className="max-w-full truncate">{label}</span>
    </button>
  )
}

export function BottomNav() {
  const { view, setView } = useApp()
  const { t } = useLang()
  const [moreOpen, setMoreOpen] = useState(false)
  return (
    <>
      <nav className="fixed inset-x-0 bottom-0 z-40 flex items-stretch gap-1 border-t border-border bg-background/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md lg:hidden" aria-label="Mobile navigation">
        <Item primary icon={<Mic className="h-[18px] w-[18px]" />} label={t('nav.voice')} active={view === 'voice'} onClick={() => setView('voice')} />
        <Item icon={<MessageSquareText className="h-[18px] w-[18px]" />} label={t('nav.assistant')} active={view === 'assistant'} onClick={() => setView('assistant')} />
        <Item icon={<Map className="h-[18px] w-[18px]" />} label={t('nav.map')} active={view === 'map'} onClick={() => setView('map')} />
        <Item icon={<Bell className="h-[18px] w-[18px]" />} label={t('nav.alerts')} active={view === 'alerts'} onClick={() => setView('alerts')} />
        <Item icon={<MoreHorizontal className="h-[18px] w-[18px]" />} label={t('nav.more')} active={false} onClick={() => setMoreOpen(true)} />
      </nav>
      <Sheet open={moreOpen} onOpenChange={setMoreOpen}>
        <SheetContent side="bottom" className="rounded-t-2xl">
          <SheetHeader>
            <SheetTitle>{t('nav.more')}</SheetTitle>
          </SheetHeader>
          <div className="grid grid-cols-3 gap-2 pb-6">
            {([
              ['overview', <Waves key="o" className="h-5 w-5" />, t('nav.overview')],
              ['risk', <ShieldAlert key="r" className="h-5 w-5" />, t('nav.risk')],
              ['fishing', <Fish key="f" className="h-5 w-5" />, t('nav.fishing')],
              ['ocean', <Waves key="w" className="h-5 w-5" />, t('nav.ocean')],
              ['reports', <FileText key="p" className="h-5 w-5" />, t('nav.reports')],
              ['settings', <Settings key="s" className="h-5 w-5" />, t('nav.settings')],
            ] as const).map(([v, icon, label]) => (
              <button key={v} onClick={() => setView(v as never)} className={cn('flex min-h-20 flex-col items-center justify-center gap-1.5 rounded-xl border bg-card p-3 text-xs font-medium', view === v && 'border-primary/50 bg-primary/8 text-primary')}>
                {icon}
                {label}
              </button>
            ))}
          </div>
        </SheetContent>
      </Sheet>
    </>
  )
}
