'use client'
// OceanTech AI — sign in / create account (email + password, sessions via httpOnly cookie)
import { useState } from 'react'
import { Anchor, Loader2, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useLang } from '@/lib/i18n/context'
import { useApp } from '@/lib/store'
import type { AppUser } from '@/types/marine'
import type { DictKey } from '@/lib/i18n/translations'

export function AuthScreen() {
  const { t } = useLang()
  const { setUser } = useApp()
  const [busy, setBusy] = useState<'in' | 'up' | 'demo' | null>(null)
  const [error, setError] = useState<string | null>(null)

  async function authenticate(url: string, payload: Record<string, string>, kind: 'in' | 'up' | 'demo') {
    setBusy(kind); setError(null)
    try {
      const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) {
        const key: DictKey = data.error === 'exists' ? 'auth.err.exists' : data.error === 'credentials' ? 'auth.err.credentials' : data.error === 'invalid' ? 'auth.err.invalid' : 'auth.err.server'
        setError(t(key))
        setBusy(null)
        return
      }
      setUser(data.user as AppUser)
    } catch {
      setError(t('auth.err.server'))
      setBusy(null)
    }
  }

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [fullName, setFullName] = useState('')
  const [phone, setPhone] = useState('')

  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-background px-4 py-10">
      {/* subtle ocean gradient backdrop */}
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div className="absolute inset-x-0 top-0 h-72 bg-gradient-to-b from-primary/14 to-transparent" />
        <svg className="absolute inset-x-0 bottom-0 h-40 w-full text-primary/16" viewBox="0 0 1440 160" fill="none" preserveAspectRatio="none" aria-hidden>
          <path d="M0 80c120-32 240-32 360 0s240 32 360 0 240-32 360 0 240 32 360 0v80H0V80z" fill="currentColor" />
        </svg>
      </div>

      <div className="relative z-10 w-full max-w-md space-y-6">
        <div className="flex flex-col items-center text-center">
          <div className="mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg shadow-primary/25">
            <Anchor className="h-7 w-7" aria-hidden />
          </div>
          <h1 className="text-2xl font-extrabold tracking-tight">OCEANTECH AI</h1>
          <p className="mt-1 text-sm text-muted-foreground">{t('brand.tagline')}</p>
        </div>

        <Card className="ot-fade-up">
          <CardHeader className="pb-3">
            <CardTitle className="text-base">{t('auth.welcome')}</CardTitle>
            <CardDescription>{t('auth.subtitle')}</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="signin">
              <TabsList className="mb-4 grid w-full grid-cols-2">
                <TabsTrigger value="signin">{t('auth.signIn')}</TabsTrigger>
                <TabsTrigger value="signup">{t('auth.signUp')}</TabsTrigger>
              </TabsList>

              <TabsContent value="signin">
                <form
                  className="space-y-3"
                  onSubmit={(e) => { e.preventDefault(); authenticate('/api/auth/login', { email, password }, 'in') }}
                >
                  <div className="space-y-1.5">
                    <Label htmlFor="si-email">{t('auth.email')}</Label>
                    <Input id="si-email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" className="h-11" />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="si-password">{t('auth.password')}</Label>
                    <Input id="si-password" type="password" autoComplete="current-password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} className="h-11" />
                  </div>
                  {error && <p className="text-sm font-medium text-destructive">{error}</p>}
                  <Button type="submit" disabled={busy !== null} className="h-11 w-full gap-2 text-[15px]">
                    {busy === 'in' && <Loader2 className="h-4 w-4 animate-spin" />}
                    {busy === 'in' ? t('auth.signingIn') : t('auth.signIn')}
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="signup">
                <form
                  className="space-y-3"
                  onSubmit={(e) => { e.preventDefault(); authenticate('/api/auth/register', { email, password, fullName, phone }, 'up') }}
                >
                  <div className="space-y-1.5">
                    <Label htmlFor="su-name">{t('auth.fullName')}</Label>
                    <Input id="su-name" required minLength={2} value={fullName} onChange={(e) => setFullName(e.target.value)} className="h-11" />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="su-email">{t('auth.email')}</Label>
                    <Input id="su-email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="h-11" />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="su-password">{t('auth.password')}</Label>
                    <Input id="su-password" type="password" autoComplete="new-password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} className="h-11" />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="su-phone">{t('auth.phone')}</Label>
                    <Input id="su-phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} className="h-11" />
                  </div>
                  {error && <p className="text-sm font-medium text-destructive">{error}</p>}
                  <Button type="submit" disabled={busy !== null} className="h-11 w-full gap-2 text-[15px]">
                    {busy === 'up' && <Loader2 className="h-4 w-4 animate-spin" />}
                    {busy === 'up' ? t('auth.creating') : t('auth.signUp')}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <Card className="ot-fade-up border-dashed">
          <CardContent className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-accent text-accent-foreground">
              <Sparkles className="h-5 w-5" aria-hidden />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold">{t('auth.demoTitle')}</p>
              <p className="text-xs leading-snug text-muted-foreground">{t('auth.demoDesc')}</p>
              <p className="mt-0.5 font-mono text-[11px] text-muted-foreground">{t('auth.demoHint')}</p>
            </div>
            <Button
              variant="secondary"
              disabled={busy !== null}
              className="h-10 shrink-0 gap-2"
              onClick={() => authenticate('/api/auth/login', { email: 'demo@oceantech.ai', password: 'ocean1234' }, 'demo')}
            >
              {busy === 'demo' ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
              {t('auth.useDemo')}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
