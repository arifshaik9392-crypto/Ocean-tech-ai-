'use client'
// OceanTech AI — top header: brand, WORKING language switcher, theme toggle, account menu
import { useTheme } from 'next-themes'
import { Check, Languages, LogOut, Menu, Moon, Settings, Sun, UserRound } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { useLang } from '@/lib/i18n/context'
import { LANGUAGES } from '@/lib/i18n/translations'
import { useApp } from '@/lib/store'
import { cn } from '@/lib/utils'

function ThemeIcon() {
  // CSS-driven icon: sun in light mode, moon in dark mode (no hydration mismatch)
  return (
    <span className="inline-flex">
      <Sun className="h-[1.1rem] w-[1.1rem] dark:hidden" />
      <Moon className="hidden h-[1.1rem] w-[1.1rem] dark:block" />
    </span>
  )
}

export function AppHeader({ onMenu }: { onMenu?: () => void }) {
  const { lang, setLang, t } = useLang()
  const { theme, setTheme } = useTheme()
  const { user, setView, setUser } = useApp()

  async function signOut() {
    try { await fetch('/api/auth/logout', { method: 'POST' }) } catch { /* ignore */ }
    setUser(null)
    setView('overview')
    window.location.reload()
  }

  return (
    <header className="sticky top-0 z-40 flex h-14 items-center gap-2 border-b border-border/70 bg-background/80 px-3 backdrop-blur-md sm:px-5">
      {onMenu && (
        <Button variant="ghost" size="icon" className="lg:hidden" onClick={onMenu} aria-label="Open navigation">
          <Menu className="h-5 w-5" />
        </Button>
      )}
      <div className="flex min-w-0 items-center gap-2 lg:hidden">
        <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary text-primary-foreground">
          <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden>
            <path d="M2 16c2 -2.5 4 -2.5 6 0s4 2.5 6 0 4 -2.5 6 0" />
            <path d="M12 12V4m0 0l3 3m-3 -3l-3 3" />
          </svg>
        </div>
        <span className="truncate text-sm font-bold tracking-tight">OceanTech AI</span>
      </div>

      <div className="ml-auto flex items-center gap-1.5">
        {/* Language switcher — fully working */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-9 gap-1.5 px-2.5" aria-label={t('common.language')}>
              <Languages className="h-[1.1rem] w-[1.1rem]" />
              <span className="hidden max-w-24 truncate text-sm sm:inline">{LANGUAGES.find((l) => l.code === lang)?.label}</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-44 max-h-72 overflow-y-auto ot-scroll">
            <DropdownMenuLabel>{t('common.language')}</DropdownMenuLabel>
            <DropdownMenuSeparator />
            {LANGUAGES.map((l) => (
              <DropdownMenuItem key={l.code} onClick={() => setLang(l.code)} className="justify-between">
                <span className={cn(l.code === lang && 'font-semibold')}>{l.label}</span>
                {l.code === lang && <Check className="h-4 w-4 text-primary" />}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Theme toggle */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-9 w-9" aria-label={t('common.theme')}>
              <ThemeIcon />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => setTheme('light')} className="gap-2">
              <Sun className="h-4 w-4" /> {t('settings.light')} {theme === 'light' && <Check className="ml-auto h-4 w-4 text-primary" />}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setTheme('dark')} className="gap-2">
              <Moon className="h-4 w-4" /> {t('settings.dark')} {theme === 'dark' && <Check className="ml-auto h-4 w-4 text-primary" />}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setTheme('system')} className="gap-2">
              <UserRound className="h-4 w-4" /> {t('settings.system')} {theme === 'system' && <Check className="ml-auto h-4 w-4 text-primary" />}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <Badge variant="outline" className="hidden h-6 items-center border-amber-600/40 bg-amber-500/10 px-2 text-[10px] font-semibold tracking-wide text-amber-700 dark:text-amber-400 md:flex">
          {t('common.sampleData')}
        </Badge>

        {/* Account menu — no role selector, authorization is backend-managed */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="ml-1 rounded-full outline-none ring-ring focus-visible:ring-2" aria-label={t('account.account')}>
              <Avatar className="h-9 w-9 border border-border">
                <AvatarFallback className="bg-primary/10 text-sm font-semibold text-primary">
                  {(user?.fullName ?? 'U').slice(0, 1).toUpperCase()}
                </AvatarFallback>
              </Avatar>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel className="space-y-0.5">
              <p className="text-sm font-semibold">{user?.fullName}</p>
              <p className="truncate text-xs font-normal text-muted-foreground">{user?.email}</p>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => setView('settings')} className="gap-2">
              <Settings className="h-4 w-4" /> {t('account.settings')}
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={signOut} className="gap-2 text-destructive focus:text-destructive">
              <LogOut className="h-4 w-4" /> {t('account.signOut')}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}
