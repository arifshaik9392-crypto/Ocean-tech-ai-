/**
 * OceanTech AI — structured marine data seeder.
 * Deterministic (seeded PRNG) so charts/forecasts stay stable across restarts.
 * Run: bun prisma/seed.ts
 */
import { PrismaClient } from '@prisma/client'
import { scryptSync, randomBytes } from 'crypto'

const db = new PrismaClient({ log: ['error'] })

function mulberry32(a: number) {
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}
function hashStr(s: string): number {
  let h = 2166136261
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) }
  return h >>> 0
}
const round = (v: number, d = 1) => Math.round(v * 10 ** d) / 10 ** d

const LOCATIONS = [
  { slug: 'kakinada', name: 'Kakinada', state: 'Andhra Pradesh', lat: 16.9891, lon: 82.2475, type: 'port' },
  { slug: 'visakhapatnam', name: 'Visakhapatnam', state: 'Andhra Pradesh', lat: 17.6868, lon: 83.2185, type: 'port' },
  { slug: 'chennai', name: 'Chennai', state: 'Tamil Nadu', lat: 13.0827, lon: 80.2707, type: 'port' },
  { slug: 'tuticorin', name: 'Tuticorin', state: 'Tamil Nadu', lat: 8.7642, lon: 78.1348, type: 'harbour' },
  { slug: 'kochi', name: 'Kochi', state: 'Kerala', lat: 9.9312, lon: 76.2673, type: 'port' },
  { slug: 'mangaluru', name: 'Mangaluru', state: 'Karnataka', lat: 12.9148, lon: 74.8560, type: 'port' },
  { slug: 'mumbai', name: 'Mumbai', state: 'Maharashtra', lat: 18.9220, lon: 72.8347, type: 'port' },
  { slug: 'goa', name: 'Panaji (Goa)', state: 'Goa', lat: 15.4909, lon: 73.8278, type: 'coast' },
  { slug: 'paradip', name: 'Paradip', state: 'Odisha', lat: 20.3167, lon: 86.6085, type: 'port' },
  { slug: 'sagar', name: 'Sagar Island', state: 'West Bengal', lat: 21.7266, lon: 88.0901, type: 'coast' },
]

// Baseline climate per location: [tempC, windKmh, waveM, currentMs, seaTempC]
const BASELINES: Record<string, [number, number, number, number, number]> = {
  kakinada: [29.5, 16, 1.5, 0.6, 28.2], visakhapatnam: [30, 17, 1.6, 0.65, 28.4],
  chennai: [30.5, 15, 1.4, 0.55, 28.6], tuticorin: [29, 14, 1.1, 0.5, 28.0],
  kochi: [28.5, 13, 1.2, 0.5, 28.1], mangaluru: [29, 14, 1.3, 0.55, 28.2],
  mumbai: [29.5, 15, 1.4, 0.55, 28.3], goa: [29.5, 12, 1.2, 0.5, 28.3],
  paradip: [29, 18, 1.7, 0.7, 28.5], sagar: [28.5, 19, 1.8, 0.75, 28.4],
}
const WIND_DIRS = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW']
const CONDITIONS = ['clear', 'partly_cloudy', 'cloudy', 'rain'] as const

function synthWeather(slug: string, t: Date) {
  const [temp, wind] = BASELINES[slug]
  const r = mulberry32(hashStr(`w:${slug}:${t.toISOString().slice(0, 13)}`))
  const hour = t.getHours()
  const diurnal = Math.sin(((hour - 6) / 24) * Math.PI * 2) // peak mid-afternoon
  const windSpeed = round(Math.max(4, wind + diurnal * 4 + (r() - 0.5) * 9), 1)
  const gust = round(windSpeed * (1.3 + r() * 0.35), 1)
  const temperature = round(temp + diurnal * 2.2 + (r() - 0.5) * 1.6, 1)
  const condPick = r()
  const monsoonish = hour >= 14 && hour <= 22 ? 0.15 : 0.05
  const condition = condPick < 0.42 ? 'clear' : condPick < 0.72 ? 'partly_cloudy' : condPick < 0.92 - monsoonish ? 'cloudy' : 'rain'
  const rainfallMm = condition === 'rain' ? round(r() * 6, 1) : 0
  const stormProbability = condition === 'rain' ? round(8 + r() * 22, 0) : round(r() * 6, 0)
  return {
    temperature, humidity: round(62 + r() * 26, 0), windSpeed,
    windDirection: WIND_DIRS[Math.floor(r() * 16)], windGust: gust,
    rainfallMm, condition, stormProbability,
  }
}

function synthOcean(slug: string, t: Date) {
  const [, wind, wave, current, seaT] = BASELINES[slug]
  const r = mulberry32(hashStr(`o:${slug}:${t.toISOString().slice(0, 13)}`))
  const hour = t.getHours()
  const tide = Math.sin((hour / 24) * Math.PI * 2 * 2)
  const waveHeight = round(Math.max(0.4, wave + tide * 0.25 + (r() - 0.5) * 0.7), 1)
  return {
    waveHeight, wavePeriod: round(5.5 + waveHeight * 1.6 + r() * 1.5, 1),
    waveDirection: WIND_DIRS[Math.floor(r() * 16)],
    currentSpeed: round(Math.max(0.15, current + tide * 0.15 + (r() - 0.5) * 0.25), 2),
    currentDirection: WIND_DIRS[Math.floor(r() * 16)],
    seaTemp: round(seaT + (r() - 0.5) * 0.5, 1),
    visibilityKm: round(6 + r() * 8, 1),
  }
}

async function main() {
  console.log('Seeding OceanTech AI structured data…')
  const now = new Date(); const hourAgo = (n: number) => new Date(now.getTime() - n * 3600_000)

  // Wipe datasets (idempotent reseed)
  await db.weatherObservation.deleteMany(); await db.oceanObservation.deleteMany()
  await db.ecosystemObservation.deleteMany(); await db.fishingZone.deleteMany()
  await db.marineAlert.deleteMany(); await db.gisZone.deleteMany(); await db.marineLocation.deleteMany()

  for (const l of LOCATIONS) {
    await db.marineLocation.create({ data: { slug: l.slug, name: l.name, state: l.state, latitude: l.lat, longitude: l.lon, type: l.type } })
    const wRows = []; const oRows = []
    for (let h = 71; h >= 0; h--) {
      const t = hourAgo(h)
      const w = synthWeather(l.slug, t); const o = synthOcean(l.slug, t)
      wRows.push({ locationSlug: l.slug, ...w, recordedAt: t })
      oRows.push({ locationSlug: l.slug, ...o, recordedAt: t })
    }
    await db.weatherObservation.createMany({ data: wRows })
    await db.oceanObservation.createMany({ data: oRows })
    const eRows = []
    for (let d = 13; d >= 0; d--) {
      const t = hourAgo(d * 24)
      const r = mulberry32(hashStr(`e:${l.slug}:${t.toISOString().slice(0, 10)}`))
      const [, , , , seaT] = BASELINES[l.slug]
      eRows.push({
        locationSlug: l.slug,
        sst: round(seaT + (r() - 0.5) * 1.2, 1),
        chlorophyll: round(0.6 + r() * 1.6, 2),
        anomaly: r() > 0.86 ? 'warm_core_eddy' : r() > 0.94 ? 'chlorophyll_bloom' : null,
        recordedAt: t,
      })
    }
    await db.ecosystemObservation.createMany({ data: eRows })
  }

  // Potential Fishing Zones (structured sample dataset)
  const pfzs = [
    { code: 'PFZ-01', name: 'Kakinada Deep Sea Front', lat: 16.62, lon: 82.68, dist: 38.2, port: 'Kakinada', suit: 'High', sst: 28.1, chl: 1.42, status: 'Available', species: 'Indian mackerel, Yellowfin tuna' },
    { code: 'PFZ-02', name: 'Kakinada Nearshore Grounds', lat: 16.86, lon: 82.45, dist: 18.4, port: 'Kakinada', suit: 'High', sst: 28.4, chl: 1.18, status: 'Available', species: 'Ribbonfish, Croaker' },
    { code: 'PFZ-03', name: 'Vizag Shelf Edge', lat: 17.38, lon: 83.62, dist: 36.9, port: 'Visakhapatnam', suit: 'Medium', sst: 28.0, chl: 0.92, status: 'Available', species: 'Tuna, Billfish' },
    { code: 'PFZ-04', name: 'Vizag Coastal Belt', lat: 17.74, lon: 83.44, dist: 17.6, port: 'Visakhapatnam', suit: 'Medium', sst: 28.3, chl: 1.05, status: 'Available', species: 'Sardine, Mackerel' },
    { code: 'PFZ-05', name: 'Chennai Offshore Basin', lat: 12.78, lon: 80.62, dist: 40.1, port: 'Chennai', suit: 'Medium', sst: 28.7, chl: 0.78, status: 'Available', species: 'Seer fish, Snapper' },
    { code: 'PFZ-06', name: 'Gulf of Mannar Front', lat: 8.62, lon: 78.42, dist: 15.2, port: 'Tuticorin', suit: 'High', sst: 27.9, chl: 1.66, status: 'Restricted', species: 'Coastal pelagics' },
    { code: 'PFZ-07', name: 'Kochi Upwelling Zone', lat: 9.62, lon: 76.05, dist: 24.8, port: 'Kochi', suit: 'High', sst: 27.6, chl: 1.88, status: 'Available', species: 'Oil sardine, Anchovy' },
    { code: 'PFZ-08', name: 'Mumbai Outer Waters', lat: 18.55, lon: 72.42, dist: 41.3, port: 'Mumbai', suit: 'Medium', sst: 28.2, chl: 0.98, status: 'Available', species: 'Pomfret, Bombay duck' },
  ]
  for (const z of pfzs) {
    await db.fishingZone.create({
      data: { code: z.code, name: z.name, centerLat: z.lat, centerLon: z.lon, distanceKm: z.dist, nearestPort: z.port, suitability: z.suit, sst: z.sst, chlorophyll: z.chl, advisoryStatus: z.status, species: z.species, updatedAt: hourAgo(1) },
    })
  }

  // Marine alerts — clearly labelled structured sample data
  const alerts = [
    { severity: 'Warning', title: 'Squally wind warning — North coastal Andhra Pradesh', desc: 'Wind speed reaching 40–50 km/h likely along and off North coastal Andhra Pradesh. Sea condition rough. Fishermen are advised not to venture into sea. (SAMPLE DATA — structured feed for evaluation)', region: 'Kakinada — Visakhapatnam coast', lat: 17.1, lon: 82.6, radiusKm: 90, issued: 3, expires: 45, source: 'OceanTech Structured Alert Feed (SAMPLE)' },
    { severity: 'Advisory', title: 'Moderate swells near Kakinada harbor mouth', desc: 'Wave heights of 1.8–2.2 m expected near harbor approach channels during early morning hours. Exercise caution while crossing sandbar. (SAMPLE DATA)', region: 'Kakinada Coast', lat: 16.98, lon: 82.33, radiusKm: 35, issued: 5, expires: 30, source: 'OceanTech Structured Alert Feed (SAMPLE)' },
    { severity: 'Advisory', title: 'Reduced visibility due to morning haze — Odisha coast', desc: 'Visibility may drop below 4 km during early hours near Paradip. Navigation lights recommended. (SAMPLE DATA)', region: 'Paradip Coast', lat: 20.32, lon: 86.75, radiusKm: 40, issued: 8, expires: 20, source: 'OceanTech Structured Alert Feed (SAMPLE)' },
    { severity: 'Information', title: 'Routine PFZ advisory published', desc: 'New potential fishing zone advisories are available for the Bay of Bengal sector. Check Fishing Intelligence for details. (SAMPLE DATA)', region: 'Bay of Bengal', lat: 15.5, lon: 83.0, radiusKm: 220, issued: 10, expires: null, source: 'OceanTech Structured Alert Feed (SAMPLE)' },
    { severity: 'Information', title: 'Fair weather outlook for Kerala coast', desc: 'Generally fair weather with light to moderate winds expected along Kerala coast over next 24 hours. (SAMPLE DATA)', region: 'Kochi Coast', lat: 9.93, lon: 76.05, radiusKm: 60, issued: 12, expires: null, source: 'OceanTech Structured Alert Feed (SAMPLE)' },
  ]
  for (const a of alerts) {
    await db.marineAlert.create({
      data: { severity: a.severity, title: a.title, description: a.desc, region: a.region, lat: a.lat, lon: a.lon, radiusKm: a.radiusKm, source: a.source, status: 'active', issuedAt: hourAgo(a.issued), expiresAt: a.expires ? hourAgo(-a.expires) : null },
    })
  }

  // GIS zones — restricted / protected areas
  const gis = [
    { name: 'Coringa Wildlife Sanctuary (Estuarine)', type: 'protected', lat: 16.85, lon: 82.27, r: 11, desc: 'Protected mangrove & estuarine ecosystem. Fishing regulated inside sanctuary boundary.' },
    { name: 'Kakinada Shipping Fairway', type: 'shipping_lane', lat: 16.75, lon: 82.55, r: 8, desc: 'Active cargo vessel corridor. Small craft should avoid crossing during convoy windows.' },
    { name: 'Visakhapatnam Naval Restricted Area', type: 'restricted', lat: 17.69, lon: 83.30, r: 9, desc: 'Entry prohibited without authorization.' },
    { name: 'Gahirmatha Marine Sanctuary', type: 'protected', lat: 20.70, lon: 86.90, r: 20, desc: 'Olive ridley turtle nesting habitat — seasonal fishing restrictions apply.' },
    { name: 'Gulf of Mannar Biosphere Reserve', type: 'protected', lat: 8.90, lon: 78.20, r: 25, desc: 'UNESCO biosphere reserve — core zones closed to fishing.' },
    { name: 'Malvan Marine Sanctuary', type: 'protected', lat: 15.96, lon: 73.55, r: 14, desc: 'Coral and seagrass protection area near Goa coast.' },
  ]
  for (const g of gis) {
    await db.gisZone.create({ data: { name: g.name, zoneType: g.type, centerLat: g.lat, centerLon: g.lon, radiusKm: g.r, description: g.desc } })
  }

  // Demo account so the platform is immediately usable
  const email = 'demo@oceantech.ai'
  const existing = await db.user.findUnique({ where: { email } })
  if (!existing) {
    const salt = randomBytes(16).toString('hex')
    const passwordHash = `${salt}:${scryptSync('ocean1234', salt, 64).toString('hex')}`
    const user = await db.user.create({
      data: { email, passwordHash, fullName: 'Ravi Kumar', phone: '+91 90000 00000', preferredLanguage: 'en', homeLocation: 'Kakinada' },
    })
    await db.userRole.create({ data: { userId: user.id, role: 'fisherman' } })
    console.log('Demo account ready → demo@oceantech.ai / ocean1234')
  }

  const counts = {
    locations: await db.marineLocation.count(),
    weather: await db.weatherObservation.count(),
    ocean: await db.oceanObservation.count(),
    ecosystem: await db.ecosystemObservation.count(),
    pfz: await db.fishingZone.count(),
    alerts: await db.marineAlert.count(),
    gis: await db.gisZone.count(),
  }
  console.log('Seed complete:', JSON.stringify(counts))
  await db.$disconnect()
}

main().catch(async (e) => { console.error(e); await db.$disconnect(); process.exit(1) })
