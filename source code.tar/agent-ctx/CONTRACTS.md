# OceanTech AI — Agent Contracts (read this before writing any view code)

You are working on **OceanTech AI**, a production-style marine intelligence platform (Next.js 16 App Router, TypeScript, Tailwind 4, shadcn/ui New York, React 19). The app is a SINGLE-PAGE app: the only route is `src/app/page.tsx`, which switches between views via zustand. All backend data comes from API routes (already implemented and working).

## STRICT RULES
1. Only MODIFY the view files you are assigned (listed in your task). Do not change `page.tsx`, layout files, lib/, api/, prisma/, or other views.
2. Use ONLY the i18n system for user-visible strings: `const { t } = useLang()` from `@/lib/i18n/context`, keys from `@/lib/i18n/translations` (`t('fishing.title') as never` casts are fine, follow existing view examples). Do NOT hardcode English UI strings except proper nouns / units.
3. Dark/light theme: use standard tokens (`bg-card`, `text-muted-foreground`, `border`, `bg-primary/10`, etc.). Risk colors: classes `risk-safe`, `risk-moderate`, `risk-high` (text) and `bg-risk-safe/15`, `bg-risk-moderate/15`, `bg-risk-high/15`, `severityBadgeClass()` helper. NEVER hardcode indigo/blue.
4. Icons: lucide-react. Charts: recharts (already installed). Tables: shadcn `Table` components. Wrapping: shadcn `Card`, `Badge`, `Button`, `Select`, `Skeleton`, `Tabs`.
5. Long lists: wrap in `max-h-96 overflow-y-auto ot-scroll` or use the table container pattern shown below.
6. Loading states: skeleton or spinner; error states: retry button + `t('common.unavailable')`. Never crash on empty data.
7. Footer/nav are handled by the shell — views render content only (start with `<ViewHeader title subtitle>` from `@/components/shared/marine`).
8. Run nothing; do not start servers; after finishing, append your section to `/home/z/my-project/worklog.md` (read it first; follow the existing template: `---`, `Task ID:`, `Agent:`, `Task:`, `Work Log:`, `Stage Summary:`).

## App state (zustand) — `@/lib/store`
```ts
const { view, setView, user, homeLocation, mapFocus, setMapFocus, sharedResult, setSharedResult, consumeShared, markConsumed } = useApp()
user: { id, email, fullName, phone, preferredLanguage, themePreference, homeLocation, role } | null
```
Cross-view navigation: `setView('map')` etc. To focus the map: `setMapFocus({ lat, lon, zoom: 9, layer: 'fishing', id, title })` then `setView('map')`.

## Language
`const { t, lang } = useLang()` — `t('key', { params })`. Available keys are in `src/lib/i18n/translations.ts` (read that file). Important: `cond.*`, `sev.*`, `suit.*`, `st.*`, `agents.*`, `risk.*`, `answer.*`, `map.*`, `fishing.*`, `alerts.*`, `ocean.*`, `reports.*`, `settings.*`, `overview.*`, `common.*`, `wx.*`, `sea.*`, `time.*`.

## Shared UI atoms — `@/components/shared/marine`
```tsx
<ViewHeader title subtitle />                       // page header
<RiskBadge level={'SAFE'|'MODERATE'|'HIGH'} />      // localized badge
<riskColorClass(level)/> severityBadgeClass(sev) suitabilityBadgeClass(suit)
<AgentPipeline agents={AgentRunInfo[]} done />      // animated checklist
<SourceMeta source dataStatus updatedAt confidence /> // source + updated + SAMPLE DATA tag
```

## API CONTRACTS (all implemented — fetch directly)
All responses are JSON. Errors: non-200 or graceful 200-with-empty-arrays for public datasets.

### GET /api/locations
`{ locations: [{ name, slug, state, latitude, longitude, type }] }` (10 Indian coastal locations)

### GET /api/marine/overview?location=<slug>
`{ location: {name, slug, state, latitude, longitude}, risk: { level: 'SAFE'|'MODERATE'|'HIGH', score, confidence }, weather: { windSpeed, windDirection, condition: 'clear'|'partly_cloudy'|'cloudy'|'rain', temperature, updatedAt, source, dataStatus: 'SAMPLE' }, ocean: { waveHeight, wavePeriod, seaTemp, currentSpeed, updatedAt, source, dataStatus }, alertsCount, alerts: MarineAlertInfo[≤3], fishingAvailable, fishingTotal, updatedAt }`

### GET /api/marine/series?location=<slug>&hours=24
`{ weather: [{ t, wind, temp, rain }], ocean: [{ t, wave, period, current, seaTemp }], location }` (hourly, oldest→newest)

### GET /api/fishing/zones[?lat&lon]
`{ zones: [{ id, code: 'PFZ-01', name, centerLat, centerLon, distanceKm, nearestPort, suitability: 'High'|'Medium'|'Low', sst, chlorophyll, advisoryStatus: 'Available'|'Restricted'|'Closed', species, updatedAt }] }`

### GET /api/alerts[?location=<slug>]
`{ alerts: [{ id, severity: 'Information'|'Advisory'|'Warning'|'Severe', title, description, region, lat, lon, radiusKm, source, status, issuedAt, expiresAt }] }`

### GET /api/gis/zones
`{ zones: [{ id, name, zoneType: 'restricted'|'protected'|'shipping_lane', centerLat, centerLon, radiusKm, description }] }`

### POST /api/orca/query  { query: string, language: 'en', context?: { pendingField?: 'location'|'time'|null, previousActivity?: string } }
Returns OrchestratorResult:
```ts
{
  queryId: string|null, type: 'assessment'|'follow_up'|'info', language, question,
  parsed: { location, locationSlug, activity, datePhrase, dateISO, time, intent } | null,
  followUp: string|null,                       // when type==='follow_up'
  answer: { oneLiner, explanation, recommendation } | null,
  risk: { level: 'SAFE'|'MODERATE'|'HIGH', score: 0-100, confidence: 0-1, factors: [{ key, labelKey, score, weight, contribution, detail }] } | null,
  conditions: Record<string, { value: string, detail?: string }> | null,  // keys: wind, waves, weather, marineAlert, fishingZone, temperature...
  agents: [{ name, labelKey, status, confidence, executionTimeMs, summary, source, dataStatus, updatedAt }],
  dataFreshness: [{ agent, updatedAt, minutesAgo }],
  alerts: MarineAlertInfo[], fishingZones: FishingZoneInfo[], gisZones: GisZoneInfo[],
  mapFocus: { lat, lon, zoom } | null, locationName, requestedWhen, createdAt
}
```
Requires auth (401 otherwise). The PRIMARY test: query "Can I go fishing tomorrow morning from Kakinada?" → type 'assessment', risk level present (likely MODERATE).

### GET /api/queries  (auth)  → `{ queries: [{ id, query, location, responseType, riskLevel, riskScore, createdAt }] }`
### GET /api/queries/:id  (auth)  → OrchestratorResult (same shape, partial: no parsed/mapFocus)

### GET /api/reports (auth) → `{ reports: [{ id, title, createdAt, question, location, riskLevel, riskScore }] }`
### POST /api/reports { queryId } (auth) → `{ report: { id, title, createdAt, content } }` where content:
`{ question, location, datetime, risk: {level, score, confidence}|null, oneLiner, explanation, recommendation, factors: [{label, contribution, detail}], conditions: [{key, value}], agents: [{label, status, confidence, summary, source, updatedAt}], disclaimer }`
### GET /api/reports/:id (auth) → same report shape

### PATCH /api/user/preferences { preferredLanguage?, themePreference?, homeLocation?, fullName?, phone? } (auth) → `{ user }`

## View files & registration
Each view is a NAMED export in `src/components/views/<Name>.tsx` and is already registered in page.tsx. Current files are placeholder stubs — replace the whole file content.

## Existing full views to imitate (style/structure reference)
- `src/components/views/AssistantView.tsx`, `src/components/views/VoiceView.tsx`, `src/components/shared/AssessmentCard.tsx`
